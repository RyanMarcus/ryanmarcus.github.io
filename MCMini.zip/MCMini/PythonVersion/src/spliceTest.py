import exascale
exascale.init()
p = exascale.get_impl()

a = p.create_array([[1,2,3],[2,3,1],[7,9,2]])
b = p.create_array([0,0,1])
c = p.zeros_like(b)
print c.shape
p.adv_array_splice(c, a, b)
print c
