import inspect
import re

command_parse = re.compile('\.(.+?)\((.*)\)')
func_parse = re.compile('.*?\((.*)\)')

def get_aio_function(func):
	params = inspect.getargspec(func)[0]
	assert len(params) != 0, "no parameters: "

	source = inspect.getsourcelines(func)[0]
	params = func_parse.search(source.pop(0)).group(1)
	params = [s.strip() for s in params.split(",")]

	# create a dictionary that maps all of our parameters to "a", for array.
	paramDict = dict()
	for s in params:
		paramDict[s] = "a"
	

	assert len(source) != 0, "no source code!"

	# remove tabs and any of that business...
	source = [b.replace('\t', "").replace('\n', "") for b in source]
	
	# remove blank lines and comments
	source = filter(lambda x: len(x) > 0 and x[0] != "#", source)

	commands = []
	for i in source:
		match = command_parse.search(i)

		assert match, "Error parsing source line: " + i
		assert len(match.groups()) == 2, "Error parsing source line: " + i

		toAdd = []
		toAdd.append(match.group(1))
		toAdd.extend([s.strip() for s in match.group(2).split(",")])
		# see what this single command tells us about our arguments...
		# the first parameter is always an array -- all values are init'd to "a"
	
		if toAdd[0][0:2] == "s_":
			# the 3rd parameter must be a scaler
			if toAdd[3] in paramDict:
				paramDict[toAdd[3]] = "s"
		
		elif toAdd[0] == "positive_negative_filter":
			# the 3rd and 4th parameters must be scalar
			if toAdd[3] in paramDict:
				paramDict[toAdd[3]] = "s"
			if toAdd[4] in paramDict:
				paramDict[toAdd[4]] = "s"

		elif toAdd[0] == "replace_val":
			# 3rd parameter must be scalar, must add 1st parameter again
			if toAdd[3] in paramDict:
				paramDict[toAdd[3]] = "s"

			toAdd.append(toAdd[1])

		elif toAdd[0] == "in_bounds":
			# the 3rd and 4th parameters must be scalar
			if toAdd[3] in paramDict:
				paramDict[toAdd[3]] = "s"
			if toAdd[4] in paramDict:
				paramDict[toAdd[4]] = "s"

			# parameter order is 1 2 4 2 3
			toAdd.extend([toAdd[1], toAdd[2], toAdd[4], toAdd[2], toAdd[3]])
			for i in range(0, 4):
				toAdd.pop(1)
			
		commands.append(toAdd)
	
	paramListToUse = []
	for i in params:
		paramListToUse.append((i, paramDict[i]))

	commands.insert(0, paramListToUse)
	return commands
		
