import exascale
import numpy
import numpy.random
import angle_sample
import timemark

tk = timemark.timemark()
DEBUG = False
STATUS = True
OUTPUT_ZONES = True
OUTPUT_PATH_LENGTHS= False
MAKE_IMAGES = False
TIMES = True

def debugPrint(*toPrint):
	if not DEBUG: return
	for i in toPrint:
		print i,
	print

def statusPrint(*toPrint):
	if not STATUS: return
	for i in toPrint:
		print i,
	print

class MCMini_Problem_Def:
	__max_dim = 1000

	def __init__(self, inpFile):
		"""
		Constructs a new MCMini_Problem_Def from the specified input file
		"""

	def get_num_particles(self):
		"""
		Returns the number of particles to run
		"""
		return 10000

	def load_geometry(self, axis):
		"""
		Loads a list of axis itercepts for X(0), Y(1), or Z(2)
		"""
		return range(0, self.__max_dim)

	def load_mfp_table(self):
		to_r = []
		for i in range(0, (self.__max_dim - 1)**3):
			to_r.append(0.25)

def create_particle():
	"""
	Creates a particle in the form of (x, y, z, xa, ya, za)
	"""
	# pick a random x, y, and z
	#toReturn = list(rand.random_sample(3))
	toReturn = [49.5,49.5,49.5]
	
	# grab some angles
	toReturn.extend(angle_sample.direct_sample_angle())
	return tuple(toReturn)

def run(cycles=1):
	# configure geometry, same for all runs
	pdef = MCMini_Problem_Def(open("input.mcm", "r"))
	global XBounds, YBounds, ZBounds
	XBounds = pdef.load_geometry(0)
	YBounds = pdef.load_geometry(1)
	ZBounds = pdef.load_geometry(2)


	import multiprocessing
	q = multiprocessing.Queue(maxsize=(cycles*2)+1)

	import output_writer
	ow = output_writer.output_write()
	ow.set_queue(q)
	ow.set_file(file("output.dat", "w"))
	ow.start()



	q.put(XBounds)
	q.put(YBounds)
	q.put(ZBounds)
	q.put(cycles*2)

	statusPrint("Starting framework...")
	exascale.init(force_level=4)
	p = exascale.get_impl()
	statusPrint("Framework started...")

	if MAKE_IMAGE:
		import imaging
		zones_of_interest = imaging.get_zones([XBounds, YBounds, ZBounds])
		zw = p.zeros_like(zones_of_interest)	

	statusPrint("Running for %s cycles" % cycles)
	for i in range(cycles):
		statusPrint("Cycle #%s..." % (i + 1))
		if MAKE_IMAGE:
			p.a_add(zw, zw, do_run(pdef, q, p, zones_of_interest=zones_of_interest))
		else:
			do_run(pdef, q, p)

	# tell our thread to close...
	q.put("f")

	statusPrint("Done with cycles")
	statusPrint("Waiting for write...")
	tk.enter_event("WWait")
	while ow.is_alive():
		pass
	tk.leave_event("WWait")

	if MAKE_IMAGE:
		tk.enter_event("Img")
		statusPrint("Making image...")
		imaging.process_image(load=False, zones_data=[XBounds, YBounds, ZBounds], zw_data=zw)
		tk.leave_event("Img")
 
	if TIMES: tk.print_results()

def do_run(pdef, q, p, zones_of_interest=None):
	tk.enter_event("Setup")
	debugPrint("Loading problem definition")
	
	x = [] 
	y = [] 
	z = [] 
	xa = [] 
	ya = []
	za = []

	for i in range(0, pdef.get_num_particles()):
		part = create_particle()
		x.append(part[0])
		y.append(part[1])
		z.append(part[2])
		xa.append(part[3])
		ya.append(part[4])
		za.append(part[5])

	debugPrint("Setting up Exa...")

	debugPrint("Run level is: " , exascale.get_current_run_level())
	debugPrint("Optimizing common functions...")
	def invertSign(x, y, z):
		p.s_mul(x, x, -1.0)
		p.s_mul(y, y, -1.0)
		p.s_mul(z, z, -1.0)
	# only called outside of loop
	# invertSign = p.optimize_function(invertSign)

	def calcTravelDistance(result, position, bound, angle):
		p.s_add(result, position, bound)
		p.a_div(result, result, angle)

	calcTravelDistance = p.optimize_function(calcTravelDistance)

	def takeAbsoluteValue(r1, r2, r3, in1, in2, in3):
		p.a_abs(r1, in1)
		p.a_abs(r2, in2)
		p.a_abs(r3, in3)

	takeAbsoluteValue = p.optimize_function(takeAbsoluteValue)

	def subtractAndSquare(r, in1, in2):
		p.a_sub(r, in1, in2)
		p.s_pow(r, r, 2)

	#subtractAndSquare = p.optimize_function(subtractAndSquare)
	# only called outside of loop

	def multiply(r1, r2, r3, in1, in2, in3):
		p.a_mul(r1, r1, in1)
		p.a_mul(r2, r2, in2)
		p.a_mul(r3, r3, in3)

	multiply = p.optimize_function(multiply)

	def add(r1, r2, r3, in1, in2, in3):
		p.a_add(r1, r1, in1)
		p.a_add(r2, r2, in2)
		p.a_add(r3, r3, in3)

	add = p.optimize_function(add)

	def subtract(r1, r2, r3, in1, in2, in3):
		p.a_sub(r1, r1, in1)
		p.a_sub(r2, r2, in2)
		p.a_sub(r3, r3, in3)

	subtract = p.optimize_function(subtract)

	def square(r1, r2, r3):
		p.s_pow(r1, r1, 2)
		p.s_pow(r2, r2, 2)
		p.s_pow(r3, r3, 2)

	def gFunc(r, fx, fy, fz, xl, yl, zl, t1, t2):
		# bounds checking
		p.positive_negative_filter(t2, t2, 1, 1)
		p.in_bounds(t1, fx, 0, xl)
		p.a_mul(t2, t2, t1)

		p.in_bounds(t1, fy, 0, yl)
		p.a_mul(t2, t2, t1)

		p.in_bounds(t1, fz, 0, zl)
		p.a_mul(t2, t2, t1)

		# g function proper
		p.s_mul(r, fx, yl)
		p.a_add(r, r, fy)
		p.s_mul(r, r, zl)
		p.a_add(r, r, fz)
		p.s_add(r, r, 1)

		# remove any values that are out of bounds
		p.a_mul(r, r, t2)

	gFunc = p.optimize_function(gFunc)

	def doIneqCalc(ineq, xlty, xltz, yltz, filterX, filterY, filterZ, minX, minY, minZ):
		p.a_sub(ineq, filterX, filterY)
		p.positive_negative_filter(xlty, ineq, 0, 1)

		p.a_sub(ineq, filterX, filterZ)
		p.positive_negative_filter(xltz, ineq, 0, 1)

		p.a_sub(ineq, filterY, filterZ)
		p.positive_negative_filter(yltz, ineq, 0, 1)

		p.a_mul(minX, xlty, xltz)
		p.positive_negative_filter(xlty, xlty, 0, 1)
		p.a_mul(minY, yltz, xlty)

		# xlty and yltz are now used for temp storage
		p.positive_negative_filter(xlty, minX, 0, 1)
		p.positive_negative_filter(yltz, minY, 0, 1)
		p.a_mul(minZ, xlty, yltz)

	doIneqCalc = p.optimize_function(doIneqCalc)

	debugPrint("Copying inital data onto device...")


	x = p.create_array(x)
	y = p.create_array(y)
	z = p.create_array(z)
	xa = p.create_array(xa)
	ya = p.create_array(ya)
	za = p.create_array(za)


	coordShape = x.shape
	angleShape = xa.shape


	debugPrint("Calculating traces...")
	xt = []
	yt = []
	zt = []

	# for easier subtraction...
	invertSign(x, y, z)

	for i in XBounds:
		newData = p.zeros_like(x)
		calcTravelDistance(newData, x, i, xa)
		xt.append(newData)



	for i in YBounds:
		newData = p.zeros_like(y)
		calcTravelDistance(newData, y, i, ya)
		yt.append(newData)


	for i in ZBounds:
		newData = p.zeros_like(z)
		calcTravelDistance(newData, z, i, za)
		zt.append(newData)


	p.free_array(x)
	p.free_array(y)
	p.free_array(z)

	# revert negation...
	#invertSign(x, y, z)
	
	debugPrint("Creating copies as two-D arary...")
	axt = p.list_to_twoD(xt)
	ayt = p.list_to_twoD(yt)
	azt = p.list_to_twoD(zt)

	# free up all of the data that was in xt, yt, and zt
	for i in xt:
		p.free_array(i)

	for i in yt:
		p.free_array(i)
	
	for i in zt:
		p.free_array(i)

	# we need to replace any negative values with NaN
	def filterOutNegatives(toFilter):
		fil = p.zeros_like(toFilter)
		p.positive_negative_filter(fil, toFilter, 1, p.get_nan())
		p.a_mul(toFilter, toFilter, fil)
		p.free_array(fil)

	filterOutNegatives(axt)
	filterOutNegatives(ayt)
	filterOutNegatives(azt)


	debugPrint("Calculating inital starting point, stopping point, and sign...")

	taxt = p.create_array_with_shape((axt.shape[1], axt.shape[0]))
	p.transpose(taxt, axt)
	fx = p.zeros_like(x)
	p.minloc_array(fx, taxt)
	lx = p.zeros_like(x)
	p.maxloc_array(lx, taxt)
	p.free_array(taxt)

	tayt = p.create_array_with_shape((ayt.shape[1], ayt.shape[0]))
	p.transpose(tayt, ayt)
	fy = p.zeros_like(y)
	p.minloc_array(fy, tayt)
	ly = p.zeros_like(y)
	p.maxloc_array(ly, tayt)
	p.free_array(tayt)

	tazt = p.create_array_with_shape((azt.shape[1], azt.shape[0]))
	p.transpose(tazt, azt)
	fz = p.zeros_like(z)
	p.minloc_array(fz, tazt)
	lz = p.zeros_like(z)
	p.maxloc_array(lz, tazt)
	p.free_array(tazt)

	t1 = p.zeros_like(fx)
	t2 = p.zeros_like(fx)
	p.replace_val(t2, t2, 0, 1)

	sx = p.create_array_with_shape(angleShape)
	sy = p.create_array_with_shape(angleShape)
	sz = p.create_array_with_shape(angleShape)
	osx = p.create_array_with_shape(angleShape)
	osy = p.create_array_with_shape(angleShape)
	osz = p.create_array_with_shape(angleShape)

	p.positive_negative_filter(sx, xa, 1, -1)
	p.positive_negative_filter(sy, ya, 1, -1)
	p.positive_negative_filter(sz, za, 1, -1)
	p.positive_negative_filter(osx, xa, 1, -1)
	p.positive_negative_filter(osy, ya, 1, -1)
	p.positive_negative_filter(osz, za, 1, -1)

	p.free_array(xa)
	p.free_array(ya)
	p.free_array(za)

	# it is possible that our particle will not intersect ANY zones. In this case, both the FX
	# and LX entry will be nan. We need to replace all NaNs in fN and lN with -1s
	p.replace_val(fx, fx, p.get_nan(), -1.0)
	p.replace_val(fy, fy, p.get_nan(), -1.0)
	p.replace_val(fz, fz, p.get_nan(), -1.0)
	p.replace_val(lx, lx, p.get_nan(), -1.0)
	p.replace_val(ly, ly, p.get_nan(), -1.0)
	p.replace_val(lz, lz, p.get_nan(), -1.0)


	debugPrint("Starting iterations...")

	add(lx, ly, lz, sx, sy, sz)

	def getSignMultiplierArray(f, l):
		toReturn = p.zeros_like(f)
		subtractAndSquare(toReturn, f, l)
		p.positive_negative_filter(toReturn, toReturn, 1.0, 0.0)
		return toReturn

	s = []
	ws = []

	iterCount = 0



	# A note on particle completion: Once a particle's f* entry matches that particle's l*
	# entry, for ANY ONE axis, no more zones are intersected UNLESS that particle's f* entry
	# started out matching that particle's l* entry.


	# some axis may already be complete
	debugPrint("Figure out if any particle is already completed")
	multiply(sx, sy, sz, getSignMultiplierArray(fx, lx), getSignMultiplierArray(fy, ly), getSignMultiplierArray(fz, lz))

	tempX = p.create_array_with_shape(coordShape)
	tempY = p.create_array_with_shape(coordShape)
	tempZ = p.create_array_with_shape(coordShape)

	forSqrdVal = p.zeros_like(sx)
	filterX = p.zeros_like(sx)
	filterY = p.zeros_like(sy)
	filterZ = p.zeros_like(sz)
	ineq = p.zeros_like(fx)
	xlty = p.zeros_like(fx)
	xltz = p.zeros_like(fx)
	yltz = p.zeros_like(fy)
	minX = p.zeros_like(fx)
	minY = p.zeros_like(fy)
	minZ = p.zeros_like(fz)
	toFindMin = p.list_to_twoD([filterX, filterY, filterZ])
	toFindMinT = p.create_array_with_shape((toFindMin.shape[1], toFindMin.shape[0]))
	toAppend = p.create_array_with_shape(coordShape)

	if MAKE_IMAGE:
		zw = p.zeros_like(zones_of_interest)

	tk.leave_event("Setup")

	while p.sum_reduction(t2) != 0:
		tk.enter_event("Iter")
		iterCount = iterCount + 1
		debugPrint("\tITERATION #",iterCount)
		debugPrint((fx, lx))
		debugPrint((fy, ly))
		debugPrint((fz, lz))
		debugPrint("\tFinding distance to next intercept...")

		tk.enter_event("Splice")
		p.adv_array_splice(tempX, axt, fx)
		p.adv_array_splice(tempY, ayt, fy)
		p.adv_array_splice(tempZ, azt, fz)
		tk.leave_event("Splice")

		debugPrint("\tCreating filter arrays for completed particles...")
		tk.enter_event("Filter")
		p.s_pow(forSqrdVal, sx, 2.0)
		p.positive_negative_filter(filterX, forSqrdVal, 0, p.get_nan())

		p.s_pow(forSqrdVal, sy, 2.0)
		p.positive_negative_filter(filterY, forSqrdVal, 0, p.get_nan())

		p.s_pow(forSqrdVal, sz, 2.0)
		p.positive_negative_filter(filterZ, forSqrdVal, 0, p.get_nan())
		tk.leave_event("Filter")

		debugPrint("\tFinding the next distance travelled...")
		tk.enter_event("Next")
		add(filterX, filterY, filterZ, tempX, tempY, tempZ)
		toFindMin = p.list_to_twoD([filterX, filterY, filterZ])
		p.transpose(toFindMinT, toFindMin)
		p.min_array(toAppend, toFindMinT)
		s.append(p.get_array(toAppend))

		tk.leave_event("Next")

		debugPrint("\tCalculating the zone travelled through...")

		# -- MAKE f* STORE THE CURRENT INTERCEPT
		# f* normally stores the NEXT intercept, not the current one
		subtract(fx, fy, fz, osx, osy, osz)

		tk.enter_event("gFunc")
		nextZones = p.zeros_like(x)

		debugPrint((fx, fy, fz))
		gFunc(nextZones, fx, fy, fz, len(XBounds) - 1, len(YBounds) - 1, len(ZBounds) - 1, t1, t2)

		# -- REVERT f* TO BE THE NEXT INTERCEPT
		add(fx, fy, fz, osx, osy, osz)

		ws.append(nextZones)

		tk.leave_event("gFunc")

		if MAKE_IMAGE:
			tk.enter_event("ImgC")
			p.count_multi_vals(zw, zones_of_interest, nextZones)
			print p.sum_reduction(zw)
			tk.leave_event("ImgC")


		debugPrint("\tCalculating iteration inequalities...")
		tk.enter_event("Ineq")

		# change nans to max val to avoid nans looking like they are smaller then other values
		p.replace_val(filterX, filterX, p.get_nan(), p.get_max_val())
		p.replace_val(filterY, filterY, p.get_nan(), p.get_max_val())
		p.replace_val(filterZ, filterZ, p.get_nan(), p.get_max_val())

		doIneqCalc(ineq, xlty, xltz, yltz, filterX, filterY, filterZ, minX, minY, minZ)

		tk.leave_event("Ineq")

		tk.enter_event("Clean")
		debugPrint("\tIterating loop variables...")
		multiply(minX, minY, minZ, sx, sy, sz)
		add(fx, fy, fz, minX, minY, minZ)

		debugPrint("\tFigure out if any of our particles have completed...")
		multiply(sx, sy, sz, getSignMultiplierArray(fx, lx), getSignMultiplierArray(fy, ly), getSignMultiplierArray(fz, lz))
		tk.leave_event("Clean")

		debugPrint("")
		tk.leave_event("Iter")

	debugPrint("Finished iterating in ", iterCount, " steps.")

	p.free_array(tempX)
	p.free_array(tempY)
	p.free_array(tempZ)

	p.free_array(forSqrdVal)
	p.free_array(filterX)
	p.free_array(filterY)
	p.free_array(filterZ)
	p.free_array(ineq)
	p.free_array(xlty)
	p.free_array(xltz)
	p.free_array(yltz)
	p.free_array(minX)
	p.free_array(minY)
	p.free_array(minZ)
	p.free_array(toFindMin)
	p.free_array(toFindMinT)

	p.free_array(axt)
	p.free_array(ayt)
	p.free_array(azt)


	# data in s and ws are currently stored with particles in columns. Change to rows.
	s = p.create_array(s)
	ts = p.create_array_with_shape((s.shape[1], s.shape[0]))
	p.transpose(ts, s)
	s = ts

	ws = p.list_to_twoD(ws)
	tws = p.create_array_with_shape((ws.shape[1], ws.shape[0]))
	p.transpose(tws, ws)
	ws = tws


	ds = p.zeros_like(s)
	p.pairwise_difference(ds, s)

	filt = p.zeros_like(ds)

	# now, anything that is a 0 in ds needs to be a 0 everywhere else
	p.positive_negative_filter(filt, ds, 1, 0)
	p.a_mul(ws, ws, filt)
	p.a_mul(s, s, filt)

	# anything that is a 0 in ws needs to be a 0 everywhere else
	p.positive_negative_filter(filt, ws, 1, 0)
	p.a_mul(ds, ds, filt)
	p.a_mul(s, s, filt)

	# Attenuation
	#tk.enter_event("Attn")
	#debugPrint("Loading MFP table...")
	#mfp_table = p.create_array(pdef.load_mfp_table())
	
	# create a table with MFP of zones aligned with ds/ws
	#mfpl = p.zeros_like(ds)
	#p.adv_array_splice2(mfpl, mfp_table, ws)

	# divide ds by mfpl to convert ds to MFP
	#p.a_div(mfpl, ds, mfpl)
	
	# sum up the MFP for each particle
	#mfpl = p.twoD_to_list(mfpl)
	#for i in mfpl:
	#	p.cum_sum(i, i)

	#mfpl = p.list_to_twoD(mfpl)

	# make them all negative
	#p.s_mul(mfpl, mfpl, -1)
	#p.s_exp(mfpl, mfpl)

	# mfpl is now a list of coeffs
	# if you multiply the inital weight of any particle by an entry in mfpl,
	# you will get the attenuated weight of that particle at that point

	#tk.leave_event("Attn")


	s = p.get_array(s)
	ws = p.get_array(ws)
	ds = p.get_array(ds)

	#debugPrint(s)
	#debugPrint("")
	#debugPrint(ds)
	#debugPrint(ws)
	if OUTPUT_PATH_LENGTHS: 
		q.put(ds)
	else:
		q.put([])

	if OUTPUT_ZONES: 
		q.put(ws)
	else:
		q.put([])

	if MAKE_IMAGE:
		return zw


if __name__ == "__main__":
	import argparse

	parser = argparse.ArgumentParser(description='Run MCMini')
	parser.add_argument('-c', '--cycles', type=int, default=1, help='the number of cycles to run')
	parser.add_argument('-d', '--debug', default=False, action='store_true', help="displays debugging information")
	parser.add_argument('-t', '--times', default=False, action='store_true', help="display timing information after run")
	parser.add_argument('-q', '--no-status', default=False, action='store_true', help="disable status messages")
	parser.add_argument('--ds', default=False, action='store_true', help='write out path length data')
	parser.add_argument('--ws', default=False, action='store_true', help='write out zone data')
	parser.add_argument('-i', '--image', default=False, action='store_true', help='Creates an image from the processed data at the last x plane')

	args = parser.parse_args()
	DEBUG = args.debug
	TIMES = args.times
	STATUS = not args.no_status
	OUTPUT_ZONES = args.ws
	OUTPUT_PATH_LENGTHS = args.ds
	MAKE_IMAGE = args.image
	

	run(cycles=args.cycles)
