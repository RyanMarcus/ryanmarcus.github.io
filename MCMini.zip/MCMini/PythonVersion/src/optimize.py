import numpy
import time

def optimize(serialFunc, accelFunc, dataGen=False):
	if dataGen:
		return __optimize(serialFunc, accelFunc, dataGen, 100)

	return __optimize(serialFunc, accelFunc, __create_random_datagen(), 100)

def __create_random_datagen():
	return lambda x: numpy.random.random_sample(x)

def __optimize(sfunc, afunc, dataGen, iters):
	sTimes = []
	aTimes = []
	print "Getting inital data..."
	
	# try with size 1
	sTimes.append(__take_sample(sfunc, dataGen(1)))
	aTimes.append(__take_sample(afunc, dataGen(1)))

	# try with size 500
	sTimes.append(__take_sample(sfunc, dataGen(500)))
	aTimes.append(__take_sample(afunc, dataGen(500)))

	# try with size 1000
	sTimes.append(__take_sample(sfunc, dataGen(1000)))
	aTimes.append(__take_sample(afunc, dataGen(1000)))

	# try with size 5000
	sTimes.append(__take_sample(sfunc, dataGen(5000)))
	aTimes.append(__take_sample(afunc, dataGen(5000)))

	# try with size 10000
	sTimes.append(__take_sample(sfunc, dataGen(10000)))
	aTimes.append(__take_sample(afunc, dataGen(10000)))


	sline = __calc_line(sTimes)
	aline = __calc_line(aTimes)
	ginst = __calc_intersect(sline, aline)
	print "Inital guess: ", ginst	
	print "Inital serial line: ", sline
	print "Inital acceld line: ", aline
	print ""

	print "Starting iterations..."
	for i in range(iters):
		sTimes.append(__take_sample(sfunc, dataGen(ginst)))
		aTimes.append(__take_sample(afunc, dataGen(ginst)))
		sline = __calc_line(sTimes)
		aline = __calc_line(aTimes)
		ginst = __calc_intersect(sline, aline)

	print "Result: ", ginst
	print "Final serial line: ", sline
	print "Final acceld line: ", aline


def __take_sample(func, params):
	return (len(params), __time(func, params))

def __time(func, params):
	t = time.time()
	func(params)
	return time.time() - t

def __calc_line(data):
	x = numpy.array([i[0] for i in data])
	y = numpy.array([i[1] for i in data])
	return numpy.polyfit(x, y, 1)

def __calc_intersect(line1, line2):
	return (line2[1] - line1[1])/(line1[0] - line2[0])

if __name__ == "__main__":
	import exascale
	exascale.init()
	ap = exascale.get_impl()
	exascale.init(force_level=4)
	sp = exascale.get_impl()
	
	def s_doCalc(data):
		data = sp.create_array(data)
		for i in range(0, 5000):
			sp.a_mul(data, data, data)
			sp.a_div(data, data, data)
			sp.a_sin(data, data)
		sp.sum_reduction(data)

	def a_doCalc(data):
		data = ap.create_array(data)
		for i in range(0, 5000):
			ap.a_mul(data, data, data)
			ap.a_div(data, data, data)
			ap.a_sin(data, data)
		ap.sum_reduction(data)

	optimize(s_doCalc, a_doCalc)
