import multiprocessing
import cPickle


class output_write(multiprocessing.Process):
	def set_queue(self, q):
		self.q = q

	def set_file(self, f):
		self.f = f

	def run(self):
		while True:
			to_write = self.q.get()
			
			if to_write == "f":
				self.f.flush()
				break

			cPickle.dump(to_write, self.f)
