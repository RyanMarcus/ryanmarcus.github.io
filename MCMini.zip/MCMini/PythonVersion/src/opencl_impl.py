import base_impl
import numpy
import pyopencl
from pyopencl import array
import pyopencl.clmath
from pyopencl.elementwise import ElementwiseKernel
from pyopencl.reduction import ReductionKernel
import aio_parse
import hashlib

class opencl_impl(base_impl.base_impl):

	__a_add = "%s[i] = %s[i] + %s[i]"
	__a_sub = "%s[i] = %s[i] - %s[i]"
	__a_mul = "%s[i] = %s[i] * %s[i]"
	__a_div = "%s[i] = %s[i] / %s[i]"
	__a_abs = "%s[i] = fabs(%s[i])"
	__a_sin = "%s[i] = sin(%s[i])"

	__s_add = "%s[i] = %s[i] + %s"
	__s_sub = "%s[i] = %s[i] - %s"
	__s_mul = "%s[i] = %s[i] * %s"
	__s_div = "%s[i] = %s[i] / %s"
	__s_pow = "%s[i] = pow(%s[i], %s)"

	__positive_negative_filter = "%s[i] = (%s[i] > 0 ? %s : %s)"
	__replace_val = "%s[i] = (%s[i] == %s ? %s : %s[i])"
	__in_bounds = "%s[i] = (%s[i] < %s && %s[i] > %s ? 1 : 0)"

	def __init__(self):
		self.ctx = pyopencl.create_some_context(interactive=True)
		self.queue = pyopencl.CommandQueue(self.ctx)
		self.__init_kernels()

	def __init_kernels(self):
		self.a_add = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c",
			self.__a_add % ("a", "b", "c"),
			"addA")

		self.a_sub = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c",
			self.__a_sub % ("a", "b", "c"),
			"subA")

		self.a_mul = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c",
			self.__a_mul % ("a", "b", "c"),
			"mulA")

		self.a_div = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c",
			self.__a_div % ("a", "b", "c"),
			"divA")

		self.a_abs = ElementwiseKernel(self.ctx,
			"float *a, float *b",
			self.__a_abs % ("a", "b"),
			"absA")

		self.a_sin = ElementwiseKernel(self.ctx,
			"float *a, float *b",
			self.__a_sin % ("a", "b"),
			"sinA")

		self.s_add = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			self.__s_add % ("a", "b", "c"),
			"addS")

		self.s_sub = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			self.__s_sub % ("a", "b", "c"),
			"subS")

		self.s_mul = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			self.__s_mul % ("a", "b", "c"),
			"mulS")

		self.s_div = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			self.__s_div % ("a", "b", "c"),
			"divS")

		self.s_pow = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			self.__s_pow % ("a", "b", "c"),
			"powS")

		self.replace_val_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c, float d",
			"a[i] = (b[i] == c ? d : b[i])",
			"replace_val_k")

		self.replace_nan_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, float c",
			"a[i] = (isnan(b[i]) ? c : b[i])",
			"replace_nan_k")

		self.adv_array_splice_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c, int w, int h, float errorVal",
			"a[i] = (c[i] > -1 && c[i] < h ? b[((int)c[i]) * w + i] : errorVal)",
			"adv_array_splice_k")

		self.adv_array_splice2 = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c",
			"a[i] = b[(int)c[i]]",
			"adv_array_splice_k2")

		self.transpose_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w, int h",
			"a[get_idx(i, w, h)] = b[i]",
			"transposeK",
			preamble="""int get_idx(int i, int w, int h) {
					int rowIdx = floor((float)i / (float)w);
					int colIdx = i - rowIdx*w;
					return (colIdx * h) + rowIdx;
				}
				""")

		self.in_bounds = ElementwiseKernel(self.ctx,
			"float *a, float *b, float lower, float upper",
			"a[i] = (b[i] < upper && b[i] > lower ? 1 : 0)",
			"in_bounds")

		self.pairwise_diff_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w",
			"a[i] = do_pd(b, w, i)",
			"pairwisediffK",
			preamble="""float do_pd(global float *b, int w, int i) {
					if (i % w == 0) {
						return b[i];
					}
					return b[i] - b[i - 1];
				}
				""")

		self.list_to_twoD_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int start",
			"b[i + start] = a[i]",
			"list_to_twoDK")
		
		self.count_vals_k = ReductionKernel(self.ctx,
			numpy.int32,
			arguments="__global float *x, float y",
			neutral="0",
			map_expr="(x[i] == y ? 1 : 0)",
			reduce_expr="a+b")

		self.count_multi_vals_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, float *c, int s",
			"a[i] += doCount(b, c, s, i)",
			"count_multi_vals",
			preamble = """float doCount(global float *b, global float *c, int s, int i) {
						int lookingFor = b[i];
						int idx = 0;
						float toReturn = 0.0;
						while (idx != s) {
							toReturn = (c[idx] == lookingFor ? toReturn + 1.0 : toReturn);
							idx++;
						}

						return toReturn;
					}""")

		self.min_array_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w",
			"a[i] = minReduc(i, b, w)",
			"min_arrayK",
			preamble = """float minReduc(int i, global float *b, int w) {
				int start;
				float currMax = b[i*w];
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((currMax < b[start]) || isnan(b[start]) ? currMax : b[start]);
				}
				return currMax;
			}""")

		self.minloc_array_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w",
			"a[i] = minReduc(i, b, w)",
			"minloc_arrayK",
			preamble = """float minReduc(int i, global float *b, int w) {
				int start;
				int currMax = i*w;
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((b[currMax] < b[start]) || isnan(b[start]) ? currMax : start);
				}
				currMax = currMax - (i*w);
				return (float)currMax;
			}""")

		self.maxloc_array_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w",
			"a[i] = maxReduc(i, b, w)",
			"maxloc_arrayK",
			preamble = """float maxReduc(int i, global float *b, int w) {
				int start;
				int currMax = i*w;
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((b[currMax] > b[start]) || isnan(b[start]) ? currMax : start);
				}
				currMax = currMax - (i*w);
				return (float)currMax;
			}""")

		self.row_sum_k = ElementwiseKernel(self.ctx,
			"float *a, float *b, int w",
			"a[i] = rowSum(i, b, w)",
			"row_sum",
			preamble = """float rowSum(int i, global float *b, int w) {
					int start;
					float c_sum = 0.0;
					for(start=(i*w);start<((i*w)+w);start++) {
						c_sum += b[start];
					}
					
					return c_sum;
				}""")

		# once pycuda dev gets rolled out as release
		#self.cum_sum_k = InclusiveScanKernel(numpy.float32, "a+b")

		self.cum_sum = ElementwiseKernel(self.ctx,
			"float *a, float *b",
			"a[i] = cumSum(i, b)",
			"cum_sum",
			preamble = """float cumSum(int i, global float *b) {
					int ii = 0;
					float toR = 0.0;
					while (ii <= i) {
						toR += b[ii];
						ii++;
					}

					return toR;
				}""")


		self.positive_negative_filter = ElementwiseKernel(self.ctx,
			"float *a, float *b, float posVal, float negVal",
			self.__positive_negative_filter % ("a", "b", "posVal", "negVal"),
			"pos_neg_filtK")




	def create_array(self, initVals):
		if type(initVals) != numpy.ndarray:
			initVals = numpy.array(initVals, dtype=numpy.float32)

		return pyopencl.array.to_device(self.queue, initVals)

	def create_array_with_shape(self, shape):
		return pyopencl.array.zeros(self.queue, shape,numpy.float32)

	def get_array(self, array):
		return array.get()
	
	def free_array(self, array):
		array.data.release()

	def zeros_like(self, array):
		return pyopencl.array.zeros_like(array)

	def count_vals(self, inp, val):
		return self.count_vals_k(inp, val).get()

	def count_multi_vals(self, result, needles, haystack):
		self.count_multi_vals_k(result, needles, haystack, haystack.size)

	def list_to_twoD(self, arrayList):
		length = len(arrayList[0])
		currLength = 0
		toReturn = self.create_array_with_shape((len(arrayList), length))
		for i in arrayList:
			self.list_to_twoD_k(i, toReturn, currLength)
			currLength = currLength + length

		return toReturn

	def twoD_to_list(self, twoD):
		toR = []
		indicies = pyopencl.array.arange(0, twoD.shape[1], 1, dtype=numpy.float32)
		for i in range(0, twoD.shape[0]):
			toR.append(pyopencl.array.take(twoD, indicies))
			self.s_add(indicies, indicies, twoD.shape[1])

		return toR

	def optimize_function(self, func):
		commands = aio_parse.get_aio_function(func)

		# build the param string
		paramString = []
		params = commands.pop(0)
		for i in params:
			if i[1] == "a":
				paramString.append("float *" + i[0])
			else:
				paramString.append("float " + i[0])

		paramString = ", ".join(paramString)
		paramString = paramString.replace("float *", "global float *")
		
		# build statements to place in the preamble...
		statements = []
		for i in commands:
			template = eval("self._opencl_impl__" + i[0])
			template = template % tuple(i[1:])
			template = template + ";"
			statements.append(template)

		preambleCode = "void doOp(" + paramString + ", int i) {\n" + "\n".join(statements) + "\n}"
		preambleCallCode = "doOp(" + paramString.replace("float", "").replace("*", "").replace("global","") + ", i)"

		import random

		return ElementwiseKernel(self.ctx,
			paramString.replace("global", ""),
			preambleCallCode,
			"c_" + hashlib.md5(preambleCode + preambleCallCode).hexdigest(),
			preamble=preambleCode)


	def get_nan(self):
		return numpy.nan

	def replace_val(self, result, inp, val, rep):
		if numpy.isnan(val):
			self.replace_nan_k(result, inp, rep)
		else:
			self.replace_val_k(result, inp, val, rep)

	def get_max_val(self):
		return numpy.finfo(numpy.float32).max

	def sum_reduction(self, array):
		return pyopencl.array.sum(array).get()

	def max_reduction(self, array):
		return pyopencl.array.max(array).get()

	def maxloc_reduction(self, array):
		return numpy.argmax(self.get_array(array))

	def maxloc_array(self, result, array):
		self.maxloc_array_k(result, array, array.shape[1])


	def min_reduction(self, array):
		return pyopencl.array.min(array).get()

	def minloc_reduction(self, array):
		return numpy.argmin(self.get_array(array))

	def minloc_array(self, result, array):
		self.minloc_array_k(result, array, array.shape[1])

	def row_sum(self, result, array):
		self.row_sum_k(result, array, array.shape[1])

	def min_array(self, result, array):
		self.min_array_k(result, array, array.shape[1])

	def dot_reduction(self, array1, array2):
		return pyopencl.array.dot(array1, array2).get()

	def transpose(self, result, arrayList):
		self.transpose_k(result, arrayList, arrayList.shape[1], arrayList.shape[0])

	def pairwise_difference(self, result, inp):
		self.pairwise_diff_k(result, inp, inp.shape[0])

	def adv_array_splice(self, result, twoD, indexArray):
		return self.adv_array_splice_k(result, twoD, indexArray, twoD.shape[1], twoD.shape[0], self.get_max_val())
