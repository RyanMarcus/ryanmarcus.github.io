class base_impl:
	"""
	This class represents the basic implementation class of the Exa framework. Ideally, regardless of the run level that is choosen, exascale.get_impl() will return an object that is based off of this class. Therefore, it should not matter what the actual implementation is. You can use any implementation object in the same way, thus allowing for the same code to be ran on multiple run levels.

	All implementations should support all of these functions. You should not have to check to see if a function is supported.
	"""

	def create_array(self, initVals):
		""" 
		Takes in an array like object and returns a pointer to an array on device.
		
		An array like object can be a python list or a numpy ndarray.
		"""
				
		raise NotImplementedError("")

	def create_array_with_shape(self, shape):
		"""
		Creates a zero-filled array with the given shape and returns a pointer to it	
		"""
		raise NotImplementedError("")

	def get_array(self, array):
		"""
		Takes in a pointer to an on-device array and returns a numpy ndarray.
		"""
		
		raise NotImplementedError("")

	def free_array(self, array):
		"""
		Frees up space on the device by removing the array from the device. You can use this if your application is running into memory trouble, although some built in garbage-collection does occur
		"""
		raise NotImplementedError("")

	def  free_all(self):
		""" Frees up all allocated space on the device """
		raise NotImplementedError("")

	def zeros_like(self, array):
		"""
		Takes in a pointer to an on-device array and returns a pointer to an on-device array of the same size, filled with zeros.
		"""
		raise NotImplementedError("")

	def list_to_twoD(self, arrayList):
		"""
		Takes in a list of (equally sized) 1D arrays and returns a 2D array in which each element of the list of arrays becomes a row
		"""
		raise NotImplementedError("")

	def twoD_to_list(self, twoD):
		"""
		Takes in a 2D array and returns a list of 1D arrays
		"""
		raise NotImplementedError("")

	def optimize_function(self, func):
		"""
		Takes in a function containing only calls to scalar and array operations and returns an optimized function
		
		All of the array parameters of the passed-in function must have the same shape.
		"""
		raise NotImplementedError("")

	def positive_negative_filter(self, result, array, posVal, negVal):
		"""
		Takes in a pointer to an on-device array and two scalars, posVal and negVal. Stores into result posVal whenever the original array is positive and negVal whenever the original array is negative. Zero is considered negative.
		"""
		raise NotImplementedError("")

	def get_nan(self):
		""" returns a NaN """
		raise NotImplementedError("")

	def get_max_val(self):
		""" returns the largest value of a number type """
		raise NotImplementedError("")

	def count_vals(self, inp, val):
		""" returns the number of times val appears in inp """
		raise NotImplementedError("")

	def count_multi_vals(self, result, needles, haystack):
		""" stores the number of occurances of needles[i] into result[i] """
		raise NotImplementedError("")

	def replace_val(self, result, inp, val, rep):
		"""
		copies all the values of inp into result, except where inp[i] = val, in which case result[i] = rep
		"""
		raise NotImplementedError("")

	def sum_reduction(self, array):
		"""
		Takes in a pointer to an on-device array and returns the scalar summation of the array
		"""
		raise NotImplementedError("")

	def max_reduction(self, array):
		"""
		Takes in a pointer to an on-device array and returns the largest scalar value in the array
		"""
		raise NotImplementedError("")

	def maxloc_reduction(self, array):
		"""
		Takes in a pointer to an on-device array and returns the index of the largest scalar value in the array
		"""

		raise NotImplementedError("")

	def maxloc_array(self, result, array):
		"""
		Takes in a pointer to an on-device two-dimensional array and stores the indexes of the largest element of each row of the input array into the result array
		""" 
		raise NotImplementedError("")

	def min_reduction(self, array):
		"""
		Takes in a pointer to an on-device array and returns the smallest scalar value in the array
		"""
		raise NotImplementedError("")

	def minloc_reduction(self, array):
		"""
		Takes in a pointer to an on-device array and returns the index of the smallest scalar value in the array
		"""		
		raise NotImplementedError("")

	def minloc_array(self, result, array):
		"""
		Takes in a pointer to an on-device two-dimensional array and stores the indexes of the smallest element of each row of the input array into the result array
		""" 
		raise NotImplementedError("")

	def min_array(self, result, array):
		"""
		Takes in a pointer to an on-device two-dimensional array and stores the minimum value of array[i] into result[i]
		"""
		raise NotImplementedError("")

	def dot_reduction(self, array1, array2):
		"""
		Takes in two pointers to on-device arrays and returns the scalar dot product of the arrays
		"""
		raise NotImplementedError("")

	def in_bounds(self, result, array, lower, upper):
		"""
		Takes in a pointer to an on-device array and sets results[i] to 0 if array[i] is out of bounds, and results[i] to 1 if array[i] is in bounds for all i
		"""
		raise NotImplementedError("")

	def transpose(self, result, arrayList):
		"""
		Takes in a pointer to a on-device multi-dimension array and sets the 1st parameter to a pointer to a new array which is the transpose of the input array
		"""
		raise NotImplementedError("")

	def a_add(self, result, inp1, inp2):
		"""
		Takes in three pointers to on-device arrays and stores the sum of the 2nd and 3rd arrays into the first array
		"""
		raise NotImplementedError("")

	def a_sub(self, result, inp1, inp2):
		"""
		Takes in three pointers to on-device arrays and stores the difference of the 2nd and 3rd arrays into the first array
		"""
		raise NotImplementedError("")

	def a_mul(self, result, inp1, inp2):
		"""
		Takes in three pointers to on-device arrays and stores the product of the 2nd and 3rd arrays into the first array
		"""
		raise NotImplementedError("")

	def a_div(self, result, inp1, inp2):
		"""
		Takes in three pointers to on-device arrays and stores the result of division on the 2nd and 3rd arrays into the first array
		"""
		raise NotImplementedError("")

	def a_abs(self, result, inp1):
		"""
		Takes in two pointers to on-device arrays and stores the absolute value of the 2nd array into the first array
		"""

		raise NotImplementedError("")

	def a_sin(self, result, inp1):
		"""
		Takes in two pointers to on-device arrays and stores the sin of the 2nd array into the 1st array
		"""
		raise NotImplementedError("")

	def s_add(self, result, inp1, sca1):
		"""
		Takes in two pointers to on-device arrays and a scalar. Stores the result of adding the scaler to the 2nd array into the 1st.
		"""
		raise NotImplementedError("")

	def s_sub(self, result, inp1, sca1):
		"""
		Takes in two pointers to on-device arrays and a scalar. Stores the result of subtracting the scaler from the 2nd array into the 1st.
		"""
		raise NotImplementedError("")

	def s_mul(self, result, inp1, sca1):
		"""
		Takes in two pointers to on-device arrays and a scalar. Stores the result of multiplying the scaler by the 2nd array into the 1st.
		"""
		raise NotImplementedError("")

	def s_div(self, result, inp1, sca1):
		"""
		Takes in two pointers to on-device arrays and a scalar. Stores the result of dividing the 2nd array by the scalar into the 1st.
		"""
		raise NotImplementedError("")

	def s_pow(self, result, inp1, sca1):
		"""
		Takes in two pointers to on-device arrays and a scalar. Stores the result of raising the 2nd array to the scalar into the 1st.
		"""
		raise NotImplementedError("")

	def s_exp(self, result, inp1):
		"""
		Makes result[i] = e^inp1[i] for all i
		"""
		raise NotImplementedError("")

	def pairwise_difference(self, result, inp):
		"""
		Takes the pairwise difference of inp and stores it into result. If inp is two-D, pairwise operations are conducted on each row of inp.
		"""
		raise NotImplementedError("")

	def row_sum(self, result, inp):
		"""
		Calculates the sum of each of the 2D input array's rows and stores it in the result array
		"""
		raise NotImplementedError("")

	def cum_sum(self, result, inp):
		"""
		Calculates the cumulative sum of inp and stores the result in result
		"""
		raise NotImplementedError("")

	def adv_array_splice(self, result, twoD, indexArray):
		"""
		Sets result such that for all i: result[i] = twoD[indexArray[i]][i]. If indexArray[i] is out of bounds, get_max_val will be used
		"""
		raise NotImplementedError("")

	def adv_array_splice2(self, result, oneD, indexArray):
		"""
		Sets result such that for all i,j: result[i][j] = oneD[indexArray[i][j]]
		"""
		raise NotImplementedError("")
