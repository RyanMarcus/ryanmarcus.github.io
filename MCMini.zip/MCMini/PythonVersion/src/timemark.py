import time

class timemark:
	def __init__(self):
		self.timerecs = []
		self.rec_list = []
		self.currrecs = dict()

	def enter_event(self, name):
		if not name in self.rec_list:
			self.rec_list.append(name)

		self.currrecs[name] = time.time()

	def leave_event(self, name):
		self.timerecs.append((name, time.time() - self.currrecs[name]))
		del self.currrecs[name]

	def print_results(self):
		rec_data = []
		for i in self.rec_list:
			current_data = filter(lambda x: x[0] == i, self.timerecs)
			total_time = sum(map(lambda x: x[1], current_data))
			avg_time = total_time / len(current_data) if len(current_data) != 0 else 0
			rec_data.append((i, total_time, avg_time))

		# sort by total time...
		rec_data = sorted(rec_data, key=lambda x: x[1])
		print "Name\t\t\tTotal\t\t\t\tAvg"
		for i in rec_data:
			print i[0], "\t\t\t", i[1], "\t\t\t", i[2]
		
