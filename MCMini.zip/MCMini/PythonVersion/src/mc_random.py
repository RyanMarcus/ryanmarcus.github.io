seedInit = 19073486328125
modVal = 281474976710656
normVal = 1.0/float(modVal)
addVal = 0
pos = 0

randVals = []

def next():
	global seedInit, addVal, modVal, normVal, pos

	seedInit = ((seedInit * 19073486328125) + addVal) % modVal
	seedInit = seedInit & 281474976710655
	pos += 1
	return (seedInit * normVal) 

def skip(n):
	# TODO: replace with smart skip function
	for i in range(n):
		next()

def chiSqrd():
	N = 600000
	bins = []
	for i in range(0, 10):
		bins.append(0)
	
	# fill our bins
	for i in range(0, N):
		v = int(next()*10.0)
		bins[v] = bins[v] + 1
	print bins

	# calculate P
	p = 0.0
	expectedValue = float(N)/float(len(bins))

	for i in bins:
		p += (i - expectedValue)**2 / expectedValue

	if p > 21.67 or p < 2.088:
		return ("Reject (2%)", p)

	if p > 16.29 or p < 3.325:
		return ("Suspect (10%)", p)

	return ("Accept", p)

if __name__ == "__main__":
	print chiSqrd()
