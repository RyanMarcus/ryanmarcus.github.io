import aio_parse
import exascale
exascale.init()
p = exascale.get_impl()

def ourFunc(a, b, c, d):
	p.a_add(a, b, c)
	p.a_sub(a, b, c)
	p.s_mul(a, b, d)
	p.s_add(a, a, 5.0)

func = p.optimize_function(ourFunc)

print func
