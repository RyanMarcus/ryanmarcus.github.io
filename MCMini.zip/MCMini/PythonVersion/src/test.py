print "t",
print "t"
