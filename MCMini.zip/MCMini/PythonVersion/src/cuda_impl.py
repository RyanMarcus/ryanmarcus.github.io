import base_impl
import numpy
import pycuda
import pycuda.autoinit
from pycuda import gpuarray
from pycuda.elementwise import ElementwiseKernel
from pycuda.reduction import ReductionKernel
import aio_parse
import hashlib



class cuda_impl(base_impl.base_impl):

	__a_add = "%s[i] = %s[i] + %s[i]"
	__a_sub = "%s[i] = %s[i] - %s[i]"
	__a_mul = "%s[i] = %s[i] * %s[i]"
	__a_div = "%s[i] = %s[i] / %s[i]"
	__a_abs = "%s[i] = fabs(%s[i])"
	__a_sin = "%s[i] = sin(%s[i])"

	__s_add = "%s[i] = %s[i] + %s"
	__s_sub = "%s[i] = %s[i] - %s"
	__s_mul = "%s[i] = %s[i] * %s"
	__s_div = "%s[i] = %s[i] / %s"
	__s_pow = "%s[i] = powf(%s[i], %s)"
	__s_exp = "%s[i] = exp(%s)"

	__positive_negative_filter = "%s[i] = (%s[i] > 0.0 ? %s : %s)"
	__replace_val = "%s[i] = (%s[i] == %s ? %s : %s[i])"
	__in_bounds = "%s[i] = (%s[i] < %s && %s[i] > %s ? 1 : 0)"

	def __init__(self):
		self.__init_kernels()

	def __init_kernels(self):
		try:
			if (self.addA): return
		except AttributeError:
			pass

		self.a_add = ElementwiseKernel(
			"float *a, float *b, float *c",
			self.__a_add % ("a", "b", "c"),
			"addA")

		self.a_sub = ElementwiseKernel(
			"float *a, float *b, float *c",
			self.__a_sub % ("a", "b", "c"),
			"subA")

		self.a_mul = ElementwiseKernel(
			"float *a, float *b, float *c",
			self.__a_mul % ("a", "b", "c"),
			"mulA")

		self.a_div = ElementwiseKernel(
			"float *a, float *b, float *c",
			self.__a_div % ("a", "b", "c"),
			"divA")

		self.a_abs = ElementwiseKernel(
			"float *a, float *b",
			self.__a_abs % ("a", "b"),
			"absA")

		self.a_sin = ElementwiseKernel(
			"float *a, float *b",
			self.__a_sin % ("a", "b"),
			"sinA")

		self.s_add = ElementwiseKernel(
			"float *a, float *b, float c",
			self.__s_add % ("a", "b", "c"),
			"addS")

		self.s_sub = ElementwiseKernel(
			"float *a, float *b, float c",
			self.__s_sub % ("a", "b", "c"),
			"subS")

		self.s_mul = ElementwiseKernel(
			"float *a, float *b, float c",
			self.__s_mul % ("a", "b", "c"),
			"mulS")

		self.s_div = ElementwiseKernel(
			"float *a, float *b, float c",
			self.__s_div % ("a", "b", "c"),
			"divS")

		self.s_pow = ElementwiseKernel(
			"float *a, float *b, float c",
			self.__s_pow % ("a", "b", "c"),
			"powS")

		#self.s_exp = ElementwiseKernel(
		#	"float *a, float *b",
		#	self.__s_exp % ("a", "b"),
		#	"expS")

		self.replace_val_k = ElementwiseKernel(
			"float *a, float *b, float c, float d",
			self.__replace_val % ("a", "b", "c", "d", "b"),
			"replace_val_k")

		self.replace_nan_k = ElementwiseKernel(
			"float *a, float *b, float c",
			"a[i] = (isnan(b[i]) ? c : b[i])",
			"replace_nan_k")

		self.adv_array_splice_k = ElementwiseKernel(
			"float *a, float *b, float *c, int w, int h, float errorVal",
			"a[i] = (c[i] > -1 && c[i] < h ? b[((int)c[i]) * w + i] : errorVal)",
			"adv_array_splice_k")

		self.adv_array_splice2 = ElementwiseKernel(
			"float *a, float *b, float *c",
			"a[i] = b[(int)c[i]]",
			"adv_array_splice_k2")

		self.transpose_k = ElementwiseKernel(
			"float *a, float *b, int w, int h",
			"a[get_idx(i, w, h)] = b[i]",
			"transposeK",
			preamble="""__device__ int get_idx(int i, int w, int h) {
					int rowIdx = floor((float)i / (float)w);
					int colIdx = i - rowIdx*w;
					return (colIdx * h) + rowIdx;
				}
				""")

		self.in_bounds = ElementwiseKernel(
			"float *a, float *b, float lower, float upper",
			"a[i] = (b[i] < upper && b[i] > lower ? 1 : 0)",
			"in_bounds")

		self.pairwise_diff_k = ElementwiseKernel(
			"float *a, float *b, int w",
			"a[i] = do_pd(b, w, i)",
			"pairwisediffK",
			preamble="""__device__ float do_pd(float *b, int w, int i) {
					if (i % w == 0) {
						return b[i];
					}
					return b[i] - b[i - 1];
				}
				""")

		self.list_to_twoD_k = ElementwiseKernel(
			"float *a, float *b, int start",
			"b[i + start] = a[i]",
			"list_to_twoDK")
		

		self.maxloc_reduction_k = ReductionKernel(
			numpy.int32,
			hack=True,
			arguments="float *x",
			neutral="0",
			map_expr="i",
			reduce_expr="(x[(int)a] > x[(int)b]) ? (int)a : (int)b")

		self.minloc_reduction_k = ReductionKernel(
			numpy.int32,
			hack=True,
			arguments="float *x",
			neutral="0",
			map_expr="i",
			reduce_expr="(x[(int)a] < x[(int)b]) ? (int)a : (int)b")

		self.count_vals_k = ReductionKernel(
			numpy.int32,
			arguments="float *x, float y",
			neutral="0",
			map_expr="(x[i] == y ? 1 : 0)",
			reduce_expr="a+b")

		self.count_multi_vals_k = ElementwiseKernel(
			"float *a, float *b, float *c, int s",
			"a[i] += doCount(b, c, s, i)",
			"count_multi_vals",
			preamble = """__device__ float doCount(float *b, float *c, int s, int i) {
						int lookingFor = b[i];
						int idx = 0;
						float toReturn = 0.0;
						while (idx != s) {
							toReturn = (c[idx] == lookingFor ? toReturn + 1.0 : toReturn);
							idx++;
						}

						return toReturn;
					}""")
					

		self.min_array_k = ElementwiseKernel(
			"float *a, float *b, int w",
			"a[i] = minReduc(i, b, w)",
			"min_arrayK",
			preamble = """__device__ float minReduc(int i, float *b, int w) {
				int start;
				float currMax = b[i*w];
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((currMax < b[start]) || isnan(b[start]) ? currMax : b[start]);
				}
				return currMax;
			}""")

		self.minloc_array_k = ElementwiseKernel(
			"float *a, float *b, int w",
			"a[i] = minReduc(i, b, w)",
			"minloc_arrayK",
			preamble = """__device__ float minReduc(int i, float *b, int w) {
				int start;
				int currMax = i*w;
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((b[currMax] < b[start]) || isnan(b[start]) ? currMax : start);
				}
				currMax = currMax - (i*w);
				return (float)currMax;
			}""")

		self.maxloc_array_k = ElementwiseKernel(
			"float *a, float *b, int w",
			"a[i] = maxReduc(i, b, w)",
			"maxloc_arrayK",
			preamble = """__device__ float maxReduc(int i, float *b, int w) {
				int start;
				int currMax = i*w;
				for(start=(i*w)+1;start<((i*w)+w);start++) {
					currMax = ((b[currMax] > b[start]) || isnan(b[start]) ? currMax : start);
				}
				currMax = currMax - (i*w);
				return (float)currMax;
			}""")

		self.row_sum_k = ElementwiseKernel(
			"float *a, float *b, int w",
			"a[i] = rowSum(i, b, w)",
			"row_sum",
			preamble = """__device__ float rowSum(int i, float *b, int w) {
					int start;
					float c_sum = 0.0;
					for(start=(i*w);start<((i*w)+w);start++) {
						c_sum += b[start];
					}
					
					return c_sum;
				}""")

		# once pycuda dev gets rolled out as release
		#self.cum_sum_k = InclusiveScanKernel(numpy.float32, "a+b")

		self.cum_sum = ElementwiseKernel(
			"float *a, float *b",
			"a[i] = cumSum(i, b)",
			"cum_sum",
			preamble = """__device__ float cumSum(int i, float *b) {
					int ii = 0;
					float toR = 0.0;
					while (ii <= i) {
						toR += b[ii];
						ii++;
					}

					return toR;
				}""")

		self.positive_negative_filter = ElementwiseKernel(
			"float *a, float *b, float posVal, float negVal",
			self.__positive_negative_filter % ("a", "b", "posVal", "negVal"),
			"pos_neg_filtK")

		self.__set_item = ElementwiseKernel(
			"float *a, float *b, int i1",
			"a[i] = (i == i1 ? b[0] : a[i])",
			"set_itemK")



	def create_array(self, initVals):
		if type(initVals) != numpy.ndarray or initVals.dtype != numpy.float32:
			initVals = numpy.array(initVals, dtype=numpy.float32)

		return pycuda.gpuarray.to_gpu(initVals)

	def create_array_with_shape(self, shape):
		return pycuda.gpuarray.zeros(shape,numpy.float32)

	def get_array(self, array):
		if type(array) == numpy.ndarray:
			return array

		return array.get()

	def free_array(self, array):
		array.gpudata.free()

	def zeros_like(self, array):
		return pycuda.gpuarray.zeros_like(array)

	def get_nan(self):
		return numpy.nan

	def count_vals(self, inp, val):
		return self.count_vals_k(inp, val).get()

	def count_multi_vals(self, result, needles, haystack):
		self.count_multi_vals_k(result, needles, haystack, haystack.size)

	def replace_val(self, result, inp, val, rep):
		if numpy.isnan(val):
			self.replace_nan_k(result, inp, rep)
		else:
			self.replace_val_k(result, inp, val, rep)

	def get_max_val(self):
		return numpy.finfo(numpy.float32).max

	def list_to_twoD(self, arrayList):
		length = len(arrayList[0])
		currLength = 0
		toReturn = self.create_array_with_shape((len(arrayList), length))
		for i in arrayList:
			self.list_to_twoD_k(i, toReturn, currLength)
			currLength = currLength + length

		return toReturn

	def twoD_to_list(self, twoD):
		toR = []
		indicies = pycuda.gpuarray.arange(0, twoD.shape[1], 1, dtype=numpy.float32)
		for i in range(0, twoD.shape[0]):
			toR.append(pycuda.gpuarray.take(twoD, indicies))
			self.s_add(indicies, indicies, twoD.shape[1])

		return toR

	

	def optimize_function(self, func):
		commands = aio_parse.get_aio_function(func)

		# build the param string
		paramString = []
		params = commands.pop(0)
		for i in params:
			if i[1] == "a":
				paramString.append("float *" + i[0])
			else:
				paramString.append("float " + i[0])

		paramString = ", ".join(paramString)
		
		# build statements to place in the preamble...
		statements = []
		for i in commands:
			template = eval("self._cuda_impl__" + i[0])
			template = template % tuple(i[1:])
			template = template + ";"
			statements.append(template)

		preambleCode = "__device__ void doOp(" + paramString + ", int i) {\n" + "\n".join(statements) + "\n}"
		preambleCallCode = "doOp(" + paramString.replace("float", "").replace("*", "") + ", i)"
		
		import random
		
		return ElementwiseKernel(
			paramString,
			preambleCallCode,
			"c_" + hashlib.md5(preambleCode + preambleCallCode).hexdigest(),
			preamble=preambleCode)
			

	def sum_reduction(self, array):
		return pycuda.gpuarray.sum(array).get()

	def max_reduction(self, array):
		return pycuda.gpuarray.max(array).get()

	def maxloc_reduction(self, array):
		return self.maxloc_reduction_k(array).get()

	def maxloc_array(self, result, array):
		self.maxloc_array_k(result, array, array.shape[1])

	def min_reduction(self, array):
		return pycuda.gpuarray.min(array).get()

	def minloc_reduction(self, array):
		return self.minloc_reduction_k(array).get()

	def minloc_array(self, result, array):
		self.minloc_array_k(result, array, array.shape[1])

	def row_sum(self, result, array):
		self.row_sum_k(result, array, array.shape[1])

	#def cum_sum(self, result, array):
		# future
		#self.cum_sum_k(result, output_ary=array)

	def min_array(self, result, array):
		self.min_array_k(result, array, array.shape[1])

	def dot_reduction(self, array1, array2):
		return pycuda.gpuarray.dot(array1, array2).get()

	def transpose(self, result, arrayList):
		self.transpose_k(result, arrayList, arrayList.shape[1], arrayList.shape[0])

	def pairwise_difference(self, result, inp):
		if len(inp.shape) != 1:
			self.pairwise_diff_k(result, inp, inp.shape[1])
		else:
			self.pairwise_diff_k(result, inp, inp.shape[0])

	def adv_array_splice(self, result, twoD, indexArray):
		return self.adv_array_splice_k(result, twoD, indexArray, twoD.shape[1], twoD.shape[0], self.get_max_val())

