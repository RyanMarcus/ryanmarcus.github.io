import base_impl
import numpy

class numpy_impl(base_impl.base_impl):
	def create_array(self, initVals):
		if type(initVals) != numpy.ndarray or initVals.dtype != numpy.float32:
			initVals = numpy.array(initVals, dtype=numpy.float32)
			return initVals

		temp = numpy.empty_like(initVals)
		temp[:] = initVals[:]
		return temp

	def get_array(self, array):
		temp = numpy.empty_like(array)
		temp[:] = array[:]
		return temp

	def free_array(self, array):
		pass

	def create_array_with_shape(self, shape):
		return numpy.zeros(shape, dtype=numpy.float32)

	def zeros_like(self, array):
		return numpy.zeros_like(array)
	
	def list_to_twoD(self, arrayList):
		return self.create_array(arrayList)

	def positive_negative_filter(self, result, array, posVal, negVal):
		onesLike = numpy.ones_like(array)
		result[:] = numpy.where(array > 0, onesLike * posVal, onesLike*negVal)[:]

	def get_nan(self):
		return numpy.nan

	def get_max_val(self):
		return numpy.finfo(numpy.float32).max

	def count_vals(self, inp, val):
		return numpy.sum(numpy.where(inp == val, 1, 0))

	def replace_val(self, result, inp, val, rep):
		if numpy.isnan(val):
			temp = numpy.where(numpy.isnan(inp), rep, inp)
		else:
			temp = numpy.where(inp == val, rep, inp)
		result[:] = temp[:]

	def optimize_function(self, func):
		# no way to optimize
		return func

	def sum_reduction(self, array):
		return numpy.sum(array)

	def max_reduction(self, array):
		return numpy.nanmax(array)

	def maxloc_reduction(self, array):
		return numpy.nanargmax(array)

	def maxloc_array(self, result, array):
		result[:] = [self.maxloc_reduction(i) for i in array][:]

	def min_reduction(self, array):
		return numpy.nanmin(array)

	def minloc_reduction(self, array):
		return numpy.nanargmin(array)

	def minloc_array(self, result, array):
		result[:] = [self.minloc_reduction(i) for i in array][:]

	def min_array(self, result, array):
		result[:] = [self.min_reduction(i) for i in array][:]

	def dot_reduction(self, array1, array2):
		return numpy.dot(array1, array2)

	def in_bounds(self, result, array, lower, upper):
		temp = numpy.where(array > lower, 1, 0)
		temp *= numpy.where(array < upper, 1, 0)
		result[:] = temp[:]

	def transpose(self, result, arrayList):
		temp = numpy.transpose(arrayList)
		result[:] = temp[:]
	
	def a_add(self, result, inp1, inp2):
		temp = inp1 + inp2
		result[:] = temp[:]

	def a_sub(self, result, inp1, inp2):
		temp = inp1 - inp2
		result[:] = temp[:]

	def a_mul(self, result, inp1, inp2):
		temp = inp1 * inp2
		result[:] = temp[:]

	def a_div(self, result, inp1, inp2):
		temp = inp1 / inp2
		result[:] = temp[:]

	def a_abs(self, result, inp1):
		result[:] = numpy.abs(inp1)[:]

	def a_sin(self, result, inp1):
		result[:] = numpy.sin(inp1)[:]

	def s_add(self, result, inp1, sca1):
		self.a_add(result, inp1, sca1)

	def s_sub(self, result, inp1, sca1):
		self.a_sub(result, inp1, sca1)

	def s_mul(self, result, inp1, sca1):
		self.a_mul(result, inp1, sca1)

	def s_div(self, result, inp1, sca1):
		self.a_div(result, inp1, sca1)

	def s_pow(self, result, inp1, sca1):
		temp = inp1 ** 2
		result[:] = temp[:]

	def pairwise_difference(self, result, inp):
		if len(inp.shape) == 1:
			# 1D pairwise diff
			i = 1
			result[0] = inp[0]
			while i != len(inp):
				result[i] = inp[i] - inp[i - 1]
				i = i + 1
			return
		
		# 2D pairwise diff
		i = 0
		for ii in inp:
			self.pairwise_difference(result[i], ii)
			i = i + 1
			

	def adv_array_splice(self, result, twoD, indexArray):
		k = 0
		for i in indexArray:
			if i < 0 or i >= twoD.shape[0]:
				result[k] = self.get_max_val()
			else:
				result[k] = twoD[i][k]
			k = k + 1

	def adv_array_splice2(self, result, oneD, indexArray):
		k = 0
		for i in indexArray:
			j = 0
			for ii in i:
				result[k][j] = oneD[ii]
				j = j + 1
			k = k + 1
