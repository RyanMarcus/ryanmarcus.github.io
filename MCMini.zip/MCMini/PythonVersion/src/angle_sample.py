import mc_random
import math


def __rand_val(a, b):
	r = b - a
	return ((r*mc_random.next()) + a)

def direct_sample_angle():
	""" directly sample an angle in three space and return a tuple containing the cosine
		of an angle from the X, Y, and Z axis """
	w = __rand_val(-1, 1)
	b = math.sqrt(1 - w**2)
	r = __rand_val(0, 2*math.pi)
	u = b * math.cos(r)
	v = b * math.sin(r)

	assert str(u**2 + v**2 + w**2) == "1.0"
	return (float(u), float(v), float(w))

def reject_sample_angle():
	""" sample an angle in three space through a rejection technique and return a tuple
		containing the cosine of the an angle from the X, Y, and Z axis """

	w = __rand_val(-1, 1)
	b = math.sqrt(1 - w**2)

	a = __rand_val(-1, 1)
	c = __rand_val(-1, 1)

	while a**2 + c**2 > 1:
		a = __rand_val(-1, 1)
		c = __rand_val(-1, 1)

	denom = a**2 + c**2
	u = b * (a**2 - c**2) / denom
	v = b * (2*a*c) / denom

	assert str(u**2 + v**2 + w**2) == "1.0"
	return (float(u), float(v), float(w))

if __name__ == "__main__":
	print "Direct: ", direct_sample_angle()
	print "Reject: ", reject_sample_angle()

	print "Benchmarking sample techniques... (smaller is better)"
	import time
	now = time.time()
	for i in range(0, 10000):
		a = direct_sample_angle()

	print "Direct sample: ", time.time() - now
	now = time.time()
	for i in range(0, 10000):
		a = reject_sample_angle()

	print "Reject sample: ", time.time() - now
