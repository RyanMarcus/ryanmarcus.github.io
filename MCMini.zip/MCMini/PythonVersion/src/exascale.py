"""
This module represents the main exascale framework.

In order to use it, first import it, and then call:

exascale.init()

This will pick the most optimal run level. In order to get an implementation object, use exascale.get_impl(). Most of Exa's functionality is accessible through this implementation.
"""

RUN_LEVEL_CUDA = 0
"""A constant to represent the CUDA run level"""

RUN_LEVEL_OPENCL = 1
"""A constant to represent the OpenCL run level"""

RUN_LEVEL_MPI = 2
"""A constant to represent the MPI run level"""

RUN_LEVEL_OPENMP = 3
""" A constant to represent the OpenMP run level"""

RUN_LEVEL_SERIAL = 4
""" A constant to represent the serial (non-concurrent) run level"""

__current_run_level = 4

def init(force_level=False):
	""" 
	Sets up the exascale framework.
	
	By default, Exa will pick the "most optimal" run level, in this order: CUDA, OpenCL, MPI, OpenMP, Serial.

	If the force_level parameter is specified, that run level will be used.
 	"""
	if force_level:
		global __current_run_level
		__current_run_level = force_level
	else:
		__pick_optimal_run_level()

def get_current_run_level():
	"""
	Returns an integer representing the current run level.
	"""
	return __current_run_level

def __pick_optimal_run_level():
	global __current_run_level
	for i in range(0, 5):
		if check_for_run_level(i):
			__current_run_level = i
			return __current_run_level
	return -1

def get_useable_run_levels():
	"""
	Returns an array of integers representing the available run levels
	"""
	return filter(check_for_run_level, range(0, 5))

def check_for_run_level(level):
	"""
	Checks to see if the run level specified is available.
	"""

	if level == RUN_LEVEL_CUDA:
		try:
			import pycuda
			from pycuda import gpuarray
			import numpy
		except:
			return False
		return True

	if level == RUN_LEVEL_OPENCL:
		try:
			import pyopencl
			import numpy
			pyopencl.get_platforms()
		except:
			return False
		return True

	if level == RUN_LEVEL_MPI:
		try:
			# not yet supported
			return False
			import mpi4py
			import numpy
		except:
			return False
		return True

	if level == RUN_LEVEL_OPENMP:
		# not supported yet
		return False

	if level == RUN_LEVEL_SERIAL:
		try:
			import numpy
		except:
			return False
		return True			

	return False

def get_impl():
	"""
	Returns an impl object that must be used to access all of Exa's array functions
	"""
	if get_current_run_level() == RUN_LEVEL_SERIAL:
		import numpy_impl
		return numpy_impl.numpy_impl()

	if get_current_run_level() == RUN_LEVEL_CUDA:
		import cuda_impl
		return cuda_impl.cuda_impl()

	if get_current_run_level() == RUN_LEVEL_OPENCL:
		import opencl_impl
		return opencl_impl.opencl_impl()
	
                    
if __name__ == "__main__":
	print "Available modes: " , get_useable_run_levels()
