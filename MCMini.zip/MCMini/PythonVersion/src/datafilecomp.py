import cPickle
data = cPickle.load(file("output.dat", "r"))
odata = cPickle.load(file("output2.dat", "r"))

data = data[-2]
odata = odata[-2]

k = 0
for i, ii in zip(data, odata):	
	if abs(sum(i) - sum (ii)) > 1:
		print k
		print i
		print ii
	k = k + 1
