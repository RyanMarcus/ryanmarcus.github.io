import numpy
import exascale
exascale.init()
p = exascale.get_impl()

def calc_zones_of_interest(XBounds, YBounds, ZBounds, intercept, axis=0):
	""" Calculate the list of zones on an image plane based on the intercept INDEX
		and axis specified. """

	# generate a list of tuples that will serve as input to the gFunc.
	# Each element of this list will contain intercept for the value of
	# axis axis.
	if axis == 0:
		list1 = YBounds
		list2 = ZBounds
	elif axis == 1:
		list1 = XBounds
		list2 = ZBounds
	elif axis == 2:
		list1 = XBounds
		list2 = YBounds
	else:
		return False # invalid axis

	
	list1 = len(list1) - 1
	list2 = len(list2) - 1

	import itertools
	a = itertools.product(range(list1), range(list2))
		
	if axis == 0:
		toReturn = ((intercept, i[0], i[1]) for i in a)
	elif axis == 1:
		toReturn = ((i[0], intercept, i[1]) for i in a)
	elif axis == 2:
		toReturn = ((i[0], i[1], intercept) for i in a)

	n = (len(XBounds) - 1, len(YBounds) - 1, len(ZBounds) - 1)
	g = lambda x: (x[2] + 1) + (n[2] * (x[1] + (n[1] * x[0]))) + 1
	return map(g, toReturn)

def create_image(XBounds, YBounds, ZBounds, intercept, data, axis=0):
	if axis == 0:
		list1 = YBounds
		list2 = ZBounds
	elif axis == 1:
		list1 = XBounds
		list2 = ZBounds
	elif axis == 2:
		list1 = XBounds
		list2 = YBounds
	else:
		return False # invalid axis

	
	list1 = len(list1) - 1
	list2 = len(list2) - 1

	import itertools
	a = itertools.product(range(list1), range(list2))
	# the order of a should be the same as the order of data
	import Image
	img = Image.new("RGB", (list1 + 1, list2 + 1))
	img_data = img.load()
	
	for (loc, val) in zip(a, data):
		img_data[loc] = (int(val*255.0), 0, 0)
		#print loc, val

	img.save("output.png", "PNG")
		

def load_data(f):
	""" reads in saved transport data from f. Returns a tuple that was written out
		by MCMini.py """

	import cPickle
	data = []
	data.append(cPickle.load(f))
	data.append(cPickle.load(f))
	data.append(cPickle.load(f))
	leng = cPickle.load(f)
	data.append(cPickle.load(f))
	data.append(cPickle.load(f))

	for i in range(leng - 2):
		if i % 2 == 0:
			data[3] = numpy.append(data[3], cPickle.load(f)) # numpy arrays -- append=extend
		else:
			data[4] = numpy.append(data[4], cPickle.load(f)) # numpy arrays -- append=extend

	return data

def get_zones(data):
	return p.create_array(calc_zones_of_interest(data[0], data[1], data[2], data[0][-2]))

def process_image(load=True, zones_data=None, zw_data=None):
	if load:
		data = load_data(file("output.dat", "r"))

	print "Done reading"
	zones = get_zones(zones_data if not load else data[0:2])
	print "Total zones of interest: ", len(zones)
	
	if load:
		zw = p.zeros_like(zones)
		ws = p.create_array(data[4])
		p.count_multi_vals(zw, zones, ws)
	else:
		zw = zw_data

	print "Done calculating zone values"
	maxP = p.max_reduction(zw)
	print "max factor: ", maxP
	p.s_div(zw, zw, maxP)

	print "Done normalizing values"
	zw = p.get_array(zw)
	print "Done copying"
	if load:
		create_image(data[0], data[1], data[2], data[0][-2], zw)
	else:
		create_image(zones_data[0], zones_data[1], zones_data[2], zones_data[0][-2], zw)
	print "Image created"

if __name__ == "__main__":
	process_image()
	
