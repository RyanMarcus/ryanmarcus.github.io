
import numpy
import time

print "Test numpy..."
now = time.time()
a = numpy.array(range(0, 4000), dtype=numpy.float32)
b = numpy.array(range(8000, 12000), dtype=numpy.float32)
c = numpy.array(range(12000, 16000), dtype=numpy.float32)
d = numpy.empty_like(a)

for i in range(0, 5000):
	d = numpy.sin(a)
	d = d + a + b
	d = d / c

e = numpy.sum(d)
cpuTime = time.time() - now

print "Test exa..."
import exascale
exascale.init()
p = exascale.get_impl()
now = time.time()

a = p.create_array(range(0, 4000))
b = p.create_array(range(4000, 8000))
c = p.create_array(range(12000, 16000))
d = p.zeros_like(a)

for i in range(0, 5000):
	p.a_sin(d, a)
	p.a_add(d, d, a)
	p.a_add(d, d, b)
	p.a_div(d, d, c)

e = p.sum_reduction(d)

exaTime = time.time() - now


print "Test elewise combined..."
def doIter(a, b, c, d):
	p.a_sin(d, a)
	p.a_add(d, d, a)
	p.a_add(d, d, b)
	p.a_div(d, d, c)

allInOne = p.optimize_function(doIter)

now = time.time()
a = p.create_array(range(0, 4000))
b = p.create_array(range(4000, 8000))
c = p.create_array(range(12000, 16000))
d = p.zeros_like(a)

for i in range(0, 5000):
	allInOne(a, b, c, d)

e = p.sum_reduction(d)
combTime = time.time() - now

numCalcs = (4.0*5000.0)*16000.0
print "Type \t Time \t\t\t Calc/S, \t\t Times faster"
print "CPU \t ", cpuTime, " \t ", numCalcs/cpuTime, "\t  1.0"
print "Exa \t ", exaTime , " \t ", numCalcs/exaTime, " \t ", (numCalcs/exaTime)/(numCalcs/cpuTime)
print "AIO \t ", combTime, " \t ", numCalcs /combTime, " \t ", (numCalcs/combTime)/(numCalcs/cpuTime)
