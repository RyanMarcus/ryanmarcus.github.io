import exascale
import unittest
import random
import sys
import numpy

class TestExascaleFramework(unittest.TestCase):

	def setUp(self):
		import os
		if 'FORCE_RUN_LEVEL' in os.environ:		
			run_level_force = int(os.environ['FORCE_RUN_LEVEL'])
			exascale.init(force_level=run_level_force)
		else:
			exascale.init()
		
		self.ha = numpy.array(range(-100, 100), dtype=numpy.float32)
		self.hb = numpy.array(range(-100, 100), dtype=numpy.float32)
		
		random.shuffle(self.hb)

		self.hc = numpy.array([1, 2, 3], dtype=numpy.float32)


		self.p = exascale.get_impl()
		self.a = self.p.create_array(self.ha)
		self.b = self.p.create_array(self.hb)
		self.c = self.p.create_array(self.hc)

	def test_run_level(self):
		self.assertTrue(exascale.get_current_run_level() > -1)

	def test_zeros_like(self):
		self.assertEquals(numpy.sum(self.p.get_array(self.p.zeros_like(self.a))), 0)
		self.assertEquals(numpy.sum(self.p.get_array(self.p.zeros_like(self.b) * self.b)), 0)
		self.assertEquals(numpy.sum(self.p.get_array(self.p.zeros_like(self.c) + self.c)), numpy.sum(self.p.get_array(self.c)))

	def test_pnf(self):
		self.p.positive_negative_filter(self.a, self.a, 0, 0)
		self.assertEquals(numpy.sum(self.p.get_array(self.a)), 0)

	def test_replace_val(self):
		temp = self.p.zeros_like(self.a)
		self.p.replace_val(temp, self.a, 99, 0)
		self.assertEquals(self.p.max_reduction(temp), 98)
		temp = self.p.create_array([1, 2, 3, self.p.get_nan()])
		self.p.replace_val(temp, temp, self.p.get_nan(), -1)
		temp = self.p.get_array(temp)
		self.assertEquals(temp[3], -1)

	def test_count_val(self):
		self.assertEquals(self.p.count_vals(self.a, 50), 1)
		self.assertEquals(self.p.count_vals(self.b, 20), 1)
		self.assertEquals(self.p.count_vals(self.c, 2), 1)

	def test_sum(self):
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.p.get_array(self.a)))
		self.assertEquals(self.p.sum_reduction(self.b), numpy.sum(self.p.get_array(self.b)))
		self.assertEquals(self.p.sum_reduction(self.c), numpy.sum(self.p.get_array(self.c)))

	def test_max(self):
		self.assertEquals(self.p.max_reduction(self.a), 99)
		self.assertEquals(self.p.max_reduction(self.b), 99)
		self.assertEquals(self.p.max_reduction(self.c), 3)

	def test_maxloc(self):
		self.assertEquals(self.p.maxloc_reduction(self.a), len(self.a) - 1)
		self.assertEquals(self.p.get_array(self.b)[self.p.maxloc_reduction(self.b)], 99)
		self.assertEquals(self.p.maxloc_reduction(self.c), 2)

	def test_maxloc_array(self):
		a = self.p.create_array([[4,2,3,1],[4,5,6,9],[7,18,9, 2]])
		b = self.p.create_array([0,0,0])
		self.p.maxloc_array(b, a)
		b = self.p.get_array(b)
		self.assertEquals(b[0], 0)
		self.assertEquals(b[1], 3)
		self.assertEquals(b[2], 1)

	
	def test_min(self):
		self.assertEquals(self.p.min_reduction(self.a), -100)
		self.assertEquals(self.p.min_reduction(self.b), -100)
		self.assertEquals(self.p.min_reduction(self.c), 1)

	def test_minloc(self):
		self.assertEquals(self.p.minloc_reduction(self.a), 0)
		self.assertEquals(self.p.get_array(self.b)[self.p.minloc_reduction(self.b)], -100)
		self.assertEquals(self.p.minloc_reduction(self.c), 0)

	def test_minloc_array(self):
		a = self.p.create_array([[4,self.p.get_nan(),3,10],[self.p.get_nan(),5,6,20],[7,-18,self.p.get_nan(),self.p.get_nan()]])
		b = self.p.create_array([0,0,0])
		self.p.minloc_array(b, a)
		b = self.p.get_array(b)
		self.assertEquals(b[0], 2)
		self.assertEquals(b[1], 1)
		self.assertEquals(b[2], 1)

	def test_dot(self):
		self.assertEquals(self.p.dot_reduction(self.c, self.c), 14)
		self.assertEquals(self.p.dot_reduction(self.a, self.a), 666700)

	def test_transpose(self):
		a = [[1,2,3,9],[4,5,6,2],[7,8,9,3]]
		a = self.p.create_array(a)
		b = self.p.create_array_with_shape((a.shape[1], a.shape[0]))
		self.p.transpose(b, a)
		b = self.p.get_array(b)
		self.assertEquals(b[1][0], 2)
		self.assertEquals(b[0][2], 7)
		self.assertEquals(numpy.sum(b[1]), 15)
		self.assertEquals(b[3][0], 9)
		self.assertEquals(b[3][1], 2)
		self.assertEquals(b[3][2], 3)
		
	def test_large_array(self):
		a = range(0, 100001)
		a = self.p.create_array(a)
		self.p.s_add(a, a, 5)
		self.p.s_sub(a, a, 5)
		self.assertEquals(self.p.max_reduction(a), 100000)
		self.assertEquals(self.p.min_reduction(a), 0)

	def test_a_add(self):
		self.p.a_add(self.a, self.b, self.a)
		self.ha = self.hb + self.ha
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_a_sub(self):
		self.p.a_sub(self.a, self.b, self.a)
		self.ha = self.hb - self.ha
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_a_mul(self):
		self.p.a_mul(self.a, self.b, self.a)
		self.ha = self.hb * self.ha
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))
		
	def test_a_div(self):
		self.p.a_div(self.a, self.b, self.a)
		self.ha = self.hb / self.ha
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_a_abs(self):
		self.p.a_abs(self.a, self.a)
		self.ha = abs(self.ha)
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_a_sin(self):
		self.p.a_sin(self.a, self.a)
		self.ha = numpy.sin(self.ha)
		self.assertAlmostEqual(self.p.sum_reduction(self.a), numpy.sum(self.ha), places=4)

	def test_s_add(self):
		self.p.s_add(self.a, self.a, 5.0)
		self.ha = self.ha + 5.0
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_s_sub(self):
		self.p.s_sub(self.a, self.a, 5.0)
		self.ha = self.ha - 5.0
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))

	def test_s_mul(self):
		self.p.s_mul(self.a, self.a, 5.0)
		self.ha = self.ha * 5.0
		self.assertEquals(self.p.sum_reduction(self.a), numpy.sum(self.ha))


	def test_s_div(self):
		self.p.s_div(self.a, self.a, 5.0)
		self.ha = self.ha / 5.0
		self.assertEquals(round(self.p.sum_reduction(self.a)), round(numpy.sum(self.ha)))

	def test_s_pow(self):
		self.p.s_add(self.a, self.a, 1.0)
		self.ha = self.ha**1.0
		self.assertEquals(abs(self.p.sum_reduction(self.a)), abs(numpy.sum(self.ha)))

	def test_adv_array_splice(self):
		a = self.p.create_array([[1,2,3],[2,3,1],[7,9,2]])
		b = self.p.create_array([0,1,8])
		c = self.p.zeros_like(b)
		self.p.adv_array_splice(c, a, b)
		c = self.p.get_array(c)
		self.assertEquals(c[0], 1)
		self.assertEquals(c[1], 3)
		self.assertEquals(c[2], self.p.get_max_val())

	def test_adv_array_splice2(self):
		a = self.p.create_array([[1,0,1],[1,2,1],[1,0,1]])
		b = self.p.create_array([0, 1, 2])
		c = self.p.zeros_like(a)
		self.p.adv_array_splice2(c, b, a)
		c = self.p.get_array(c)
		self.assertEquals(c[0][0], 1)
		self.assertEquals(c[0][1], 0)
		self.assertEquals(c[0][2], 1)
		self.assertEquals(c[1][0], 1)
		self.assertEquals(c[1][1], 2)
		self.assertEquals(c[1][2], 1)
		self.assertEquals(c[2][0], 1)
		self.assertEquals(c[2][1], 0)
		self.assertEquals(c[2][2], 1)

	def test_pairwise_difference(self):
		a = self.p.create_array([6, 5, 4, 3, 2, 1])
		r = self.p.zeros_like(a)
		self.p.pairwise_difference(r, a)
		r = self.p.get_array(r)
		self.assertEquals(r[0], 6)
		self.assertEquals(r[1], -1)
		self.assertEquals(r[2], -1)
		self.assertEquals(r[3], -1)
		self.assertEquals(r[4], -1)
		self.assertEquals(r[5], -1)

		a = self.p.create_array([[6, 5, 4, 3, 2, 1],[6, 5, 4, 3, 2, 1],[6, 5, 4, 3, 2, 1]])
		rr = self.p.zeros_like(a)
		self.p.pairwise_difference(rr, a)
		rr = self.p.get_array(rr)
		self.assertEquals(rr[0][0], r[0])
		self.assertEquals(rr[1][1], r[1])
		self.assertEquals(rr[2][2], r[2])

	def test_list_to_twoD(self):
		l = []
		l.append(self.p.create_array([1, 2, 3, 4]))
		l.append(self.p.create_array([1, 2, 3, 4]))
		l.append(self.p.create_array([1, 2, 3, 4]))
		
		r = self.p.list_to_twoD(l)
		r = self.p.get_array(r)
		self.assertEquals(r[0][0], 1)
		self.assertEquals(r[1][0], 1)
		self.assertEquals(r[2][0], 1)
		self.assertEquals(r[1][1], 2)
		self.assertEquals(r[2][3], 4)

	def test_twoD_to_list(self):
		l = self.p.create_array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]])
		ll = self.p.twoD_to_list(l)

		self.assertEquals(len(ll), 3)

		for i in ll:
			#print i
			i.r = self.p.get_array(i)

		self.assertEquals(ll[0].r[0], 1)
		self.assertEquals(ll[1].r[0], 5)
		self.assertEquals(ll[2].r[0], 9)
		self.assertEquals(ll[0].r[2], 3)
		self.assertEquals(ll[1].r[1], 6)
		self.assertEquals(ll[2].r[3], 12)

	def test_min_array(self):
		l = []
		l.append(self.p.create_array([1, 2, 3, 4]))
		l.append(self.p.create_array([1, 2, -3, 4]))
		l.append(self.p.create_array([1, -2, 3, 4]))
		r = self.p.list_to_twoD(l)
		t = self.p.create_array_with_shape((3,))
		self.p.min_array(t, r)
		t = self.p.get_array(t)
		self.assertEquals(t[0], 1)
		self.assertEquals(t[1], -3)
		self.assertEquals(t[2], -2)

	def test_in_bounds(self):
		self.p.in_bounds(self.a, self.a, -5, 5)
		self.assertEquals(self.p.sum_reduction(self.a), 9)

	def test_count_multi_vals(self):
		n = self.p.create_array([1, 2, 3])
		r = self.p.zeros_like(n)
		self.p.count_multi_vals(r, n, self.a)
		self.assertEquals(self.p.sum_reduction(r), 3)
		r = self.p.get_array(r)
		self.assertEquals(r[0], 1)
		self.assertEquals(r[1], 1)
		self.assertEquals(r[2], 1)
		self.assertEquals(len(r), 3)

		l = []
		l.append(self.p.create_array([1, 2, 3, 4]))
		l.append(self.p.create_array([1, 2, -3, 4]))
		l.append(self.p.create_array([1, -2, 3, 4]))
		rl = self.p.list_to_twoD(l)
		r = self.p.zeros_like(n)
		self.p.count_multi_vals(r, n, rl)
		r = self.p.get_array(r)
		self.assertEquals(r[0], 3)
		self.assertEquals(r[1], 2)
		self.assertEquals(r[2], 2)

	def test_no_assoc(self):
		a = [1, 2, 3, 4]
		a = self.p.create_array(a)
		self.p.s_mul(a, a, 2)
		b = self.p.get_array(a)
		self.p.s_mul(a, a, 2)
		self.assertEquals(self.p.sum_reduction(a), 4+8+12+16)
		self.assertEquals(b[1], 4)

	def test_row_sum(self):
		a = self.p.create_array([[1, 2, 3], [1, 2, 4], [2, 4, 5], [0, 0, 0]])
		b = self.p.create_array_with_shape((a.shape[0], 1))
		self.p.row_sum(b, a)
		b = self.p.get_array(b)
		self.assertEquals(b[0], 6)
		self.assertEquals(b[1], 7)
		self.assertEquals(b[2], 11)
		self.assertEquals(b[3], 0)

	def test_cum_sum(self):
		a = self.p.create_array([1, 2, 3, 4, 5])
		self.p.cum_sum(a, a)
		a = self.p.get_array(a)
		self.assertEquals(a[0], 1)
		self.assertEquals(a[1], 3)
		self.assertEquals(a[2], 6)
		self.assertEquals(a[3], 10)
		self.assertEquals(a[4], 15)
	


if __name__ == "__main__":
	unittest.main()
