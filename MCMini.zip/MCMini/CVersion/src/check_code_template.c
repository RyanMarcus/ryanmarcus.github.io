#include <stdlib.h>
#include <check.h>
#include "code_template.h"


START_TEST (test1) {
	struct strStrHashTable* t = ssht_create(1);
	ssht_add(t, ssht_makeKVPair("%VAR1%", "test"));

	char* myVar = readTemplate("code_template_tests/test1.txt", t);
	fail_unless(strcmp(myVar, "This is a test of single variables\n") == 0);
} END_TEST

START_TEST (test2) {
	char* myVar = readTemplate("code_template_tests/test2.txt", NULL);
	fail_unless(myVar == NULL);
} END_TEST

START_TEST (test3) {
	char* myVar = readTemplate("code_template_tests/test3.txt", NULL);
	fail_if(myVar == NULL);
} END_TEST

START_TEST (test4) {
	char* myVar = readTemplate("code_template_tests/test1.txt", NULL);
	fail_unless(myVar == NULL);
} END_TEST

START_TEST (test5) {
	struct strStrHashTable* t = ssht_create(2);
	ssht_add(t, ssht_makeKVPair("%test1%", "test"));
	ssht_add(t, ssht_makeKVPair("%test2%", "test2"));

	char* myVar = readTemplate("code_template_tests/test4.txt", t);
	fail_unless(strlen(myVar) > 0);

} END_TEST

START_TEST (test6) {
	struct strStrHashTable* t = ssht_create(20);
	ssht_add(t, ssht_makeKVPair("%NAME%", "name"));
	ssht_add(t, ssht_makeKVPair("%RANDOM_OFFSET%", "roff"));
	ssht_add(t, ssht_makeKVPair("%INITSEED%", "iseed"));
	ssht_add(t, ssht_makeKVPair("%MULT%", "mult"));
	ssht_add(t, ssht_makeKVPair("%ADD%", "add"));
	ssht_add(t, ssht_makeKVPair("%MASK%", "mask"));
	ssht_add(t, ssht_makeKVPair("%NORM%", "norm"));

	char* myVar = readTemplate("code_template_tests/particleCreate.clt", t);
	fail_unless(strlen(myVar) > 0);
} END_TEST

Suite* template_suite() {
	Suite* s = suite_create("Code Template Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, test1);
	tcase_add_test (tc_core, test2);
	tcase_add_test (tc_core, test3);
	tcase_add_test (tc_core, test4);
	tcase_add_test (tc_core, test5);
	tcase_add_test (tc_core, test6);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;
	Suite *s = template_suite();
	SRunner *sr = srunner_create (s);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
