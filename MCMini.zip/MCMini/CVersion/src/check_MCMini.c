#include <stdlib.h>
#include <check.h>
#include "MCMini.h"
#include "opencl.h"
#include "contextFactory.h"
#include "MCMini_config_read.h"
#include "strstrhashtable.h"
#include "random.h"
#include "angle_sample.h"

#define feq(x, y) (fabs(x - y) < 0.0001)

START_TEST (test_init) {
	int i;

	// set up OpenCL, which sets did, ctx, and cdq
	setup_opencl();
	printDeviceInfo(did);

	// read in the config file
	struct MCMini_config* config = read_MCMini_config("config_reader_tests/test4.txt");
	if (config == NULL) exit(1); // invalid config file

	// create size variables for the bounds lists...
	// the actual bounds list are in the config object
	size_t x_bounds_size = sizeof(int) * *config->num_x_bounds;
	size_t y_bounds_size = sizeof(int) * *config->num_y_bounds;
	size_t z_bounds_size = sizeof(int) * *config->num_z_bounds;

	// copy the bounds list onto the device
	cl_mem d_x_bounds = createBuffer(ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, x_bounds_size, config->x_bounds);
	cl_mem d_y_bounds = createBuffer(ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, y_bounds_size, config->y_bounds);
	cl_mem d_z_bounds = createBuffer(ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, z_bounds_size, config->z_bounds);

	writeToBuffer(cdq, d_x_bounds, x_bounds_size, config->x_bounds);
	writeToBuffer(cdq, d_y_bounds, y_bounds_size, config->y_bounds);
	writeToBuffer(cdq, d_z_bounds, z_bounds_size, config->z_bounds);

	// create the geom_description array
	// values: sourceX, sourceY, sourceZ, |xBounds|, |yBounds|, |zBounds|
	size_t geom_description_size = sizeof(float) * 6;
	cl_float* geom_description = malloc(geom_description_size);
	geom_description[0] = (float)config->source_x; 
	geom_description[1] = (float)config->source_y; 
	geom_description[2] = (float)config->source_z;
 	geom_description[3] = (float)*config->num_x_bounds;
	geom_description[4] = (float)*config->num_y_bounds;
	geom_description[5] = (float)*config->num_z_bounds;

	// copy geom_description onto the device
	cl_mem d_geom_description = createBuffer(ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, geom_description_size, geom_description);
	writeToBuffer(cdq, d_geom_description, geom_description_size, geom_description);

	// create pointers for the particles array
	// data: x, y, z, xa, ya, za, blank, blank
	size_t particles_size;
	cl_float8* particles;
	cl_mem d_particles;

	// the first step is creating the inital particles, which is done by particleCreate.clt
	// the first call here is strange because it figures out the optimal workgroup size
	// so it might change the number of particles we are using
	create_initial_particles(d_geom_description, &particles, &d_particles, &particles_size, config);

	// code to read init particle data back to host and print...
	readFromBuffer(cdq, d_particles, particles_size, particles);
	waitForAllEvents(cdq);
	fail_unless(feq(particles[0].s0, 5.000000f));
	fail_unless(feq(particles[0].s1, 5.000000f));
	fail_unless(feq(particles[0].s2, 5.000000f));
	fail_unless(feq(particles[0].s3, .852123f));
	fail_unless(feq(particles[0].s4, -0.423773f));
	fail_unless(feq(particles[0].s5, 0.307087f));

	fail_unless(feq(particles[1].s0, 5.000000f));
	fail_unless(feq(particles[1].s1, 5.000000f));
	fail_unless(feq(particles[1].s2, 5.000000f));
	fail_unless(feq(particles[1].s3, -0.442436f));
	fail_unless(feq(particles[1].s4, -0.789052f));
	fail_unless(feq(particles[1].s5, 0.426201f));

	fail_unless(feq(particles[2].s0, 5.000000f));
	fail_unless(feq(particles[2].s1, 5.000000f));
	fail_unless(feq(particles[2].s2, 5.000000f));
	fail_unless(feq(particles[2].s3, 0.693896f));
	fail_unless(feq(particles[2].s4, 0.543069f));
	fail_unless(feq(particles[2].s5, -0.472847f));

	fail_unless(feq(particles[8].s0, 5.000000f));
	fail_unless(feq(particles[8].s1, 5.000000f));
	fail_unless(feq(particles[8].s2, 5.000000f));
	fail_unless(feq(particles[8].s3, 0.1830967f));
	fail_unless(feq(particles[8].s4, 0.977115f));
	fail_unless(feq(particles[8].s5,  -0.10826f));
	

	fail_unless(feq(particles[9].s0, 5.000000f));
	fail_unless(feq(particles[9].s1, 5.000000f));
	fail_unless(feq(particles[9].s2, 5.000000f));
	fail_unless(feq(particles[9].s3, -0.471662f));
	fail_unless(feq(particles[9].s4, -0.877846f));
	fail_unless(feq(particles[9].s5, 0.083197f));
	

	// now that we know how many particles we are using, we can allocate xDist, yDist, and zDist
	size_t xDist_size = config->num_particles * *config->num_x_bounds * sizeof(cl_float);
	cl_mem d_xDist = createBuffer(ctx, CL_MEM_READ_WRITE, xDist_size, NULL);

	size_t yDist_size = config->num_particles * *config->num_y_bounds * sizeof(cl_float);
	cl_mem d_yDist = createBuffer(ctx, CL_MEM_READ_WRITE, yDist_size, NULL);

	size_t zDist_size = config->num_particles * *config->num_z_bounds * sizeof(cl_float);
	cl_mem d_zDist = createBuffer(ctx, CL_MEM_READ_WRITE, zDist_size, NULL);	

	// now do the particle trace
	do_particle_trace(d_geom_description, d_particles, d_x_bounds, d_y_bounds, d_z_bounds, d_xDist, d_yDist, d_zDist, config);

	// code to read and print xDist
	float* xDist = malloc(xDist_size);
	readFromBuffer(cdq, d_xDist, xDist_size, xDist);
	waitForAllEvents(cdq);

	fail_unless(isnan(xDist[0]), "NaN actually was: %f\n", xDist[0]);
	fail_unless(isnan(xDist[1]));
	fail_unless(isnan(xDist[2]));
	fail_unless(isnan(xDist[3]));
	fail_unless(isnan(xDist[4]));
	fail_unless(feq(xDist[5], 0.000000));
	fail_unless(feq(xDist[6], 1.173540));
	fail_unless(feq(xDist[7], 2.347079));
	fail_unless(feq(xDist[8], 3.520618));
	fail_unless(feq(xDist[9], 4.694158));
	fail_unless(feq(xDist[10], 11.301079));
	fail_unless(feq(xDist[11], 9.040863));
	fail_unless(feq(xDist[12], 6.780647));
	fail_unless(feq(xDist[13], 4.520432));
	fail_unless(feq(xDist[14], 2.260216));
	fail_unless(feq(xDist[15], -0.000000));
	fail_unless(isnan(xDist[16]));
	fail_unless(isnan(xDist[17]));
	fail_unless(isnan(xDist[18]));
	fail_unless(isnan(xDist[19]));
	fail_unless(isnan(xDist[20]));
	fail_unless(isnan(xDist[21]));
	fail_unless(isnan(xDist[22]));
	fail_unless(isnan(xDist[23]));
	fail_unless(isnan(xDist[24]));
	fail_unless(feq(xDist[25], 0.000000));
	fail_unless(feq(xDist[26], 1.441138));
	fail_unless(feq(xDist[27], 2.882276));
	fail_unless(feq(xDist[28], 4.323414));
	fail_unless(feq(xDist[29], 5.764552));
	fail_unless(feq(xDist[30], 17.017244));
	fail_unless(feq(xDist[31], 13.613795));
	fail_unless(feq(xDist[32], 10.210346));
	fail_unless(feq(xDist[33], 6.806898));
	fail_unless(feq(xDist[34], 3.403449));
	fail_unless(feq(xDist[35], -0.000000));
	fail_unless(isnan(xDist[36]));
	fail_unless(isnan(xDist[37]));
	fail_unless(isnan(xDist[38]));
	fail_unless(isnan(xDist[39]));
	fail_unless(isnan(xDist[40]));
	fail_unless(isnan(xDist[41]));
	fail_unless(isnan(xDist[42]));
	fail_unless(isnan(xDist[43]));
	fail_unless(isnan(xDist[44]));
	fail_unless(feq(xDist[45], 0.000000));
	fail_unless(feq(xDist[46], 1.645833));
	fail_unless(feq(xDist[47], 3.291665));
	fail_unless(feq(xDist[48], 4.937498));
	fail_unless(feq(xDist[49], 6.583331));
	fail_unless(feq(xDist[50], 14.701842));
	fail_unless(feq(xDist[51], 11.761474));
	fail_unless(feq(xDist[52], 8.821105));
	fail_unless(feq(xDist[53], 5.880737));
	fail_unless(feq(xDist[54], 2.940368));
	fail_unless(feq(xDist[55], -0.000000));
	fail_unless(isnan(xDist[56]));
	fail_unless(isnan(xDist[57]));
	fail_unless(isnan(xDist[58]));
	fail_unless(isnan(xDist[59]));
	fail_unless(isnan(xDist[60]));
	fail_unless(isnan(xDist[61]));
	fail_unless(isnan(xDist[62]));
	fail_unless(isnan(xDist[63]));
	fail_unless(isnan(xDist[64]));
	fail_unless(feq(xDist[65], 0.000000));
	fail_unless(feq(xDist[66], 10.229981));
	fail_unless(feq(xDist[67], 20.459963));
	fail_unless(feq(xDist[68], 30.689945));
	fail_unless(feq(xDist[69], 40.919926));
	fail_unless(feq(xDist[70], 21.485882));
	fail_unless(feq(xDist[71], 17.188705));
	fail_unless(feq(xDist[72], 12.891529));
	fail_unless(feq(xDist[73], 8.594353));
	fail_unless(feq(xDist[74], 4.297176));
	fail_unless(feq(xDist[75], -0.000000));
	fail_unless(isnan(xDist[76]));
	fail_unless(isnan(xDist[77]));
	fail_unless(isnan(xDist[78]));
	fail_unless(isnan(xDist[79]));
	fail_unless(isnan(xDist[80]));
	fail_unless(isnan(xDist[81]));
	fail_unless(isnan(xDist[82]));
	fail_unless(isnan(xDist[83]));
	fail_unless(isnan(xDist[84]));
	fail_unless(feq(xDist[85], 0.000000));
	fail_unless(feq(xDist[86], 5.461628));
	fail_unless(feq(xDist[87], 10.923257));
	fail_unless(feq(xDist[88], 16.384886));
	fail_unless(feq(xDist[89], 21.846514));
	fail_unless(feq(xDist[90], 10.600806));
	fail_unless(feq(xDist[91], 8.480645));
	fail_unless(feq(xDist[92], 6.360484));
	fail_unless(feq(xDist[93], 4.240323));
	fail_unless(feq(xDist[94], 2.120161));
	fail_unless(feq(xDist[95], -0.000000));
	fail_unless(isnan(xDist[96]));
	fail_unless(isnan(xDist[97]));
	fail_unless(isnan(xDist[98]));
	fail_unless(isnan(xDist[99]));


	// create first and last intercept array
	size_t first_size = config->num_particles * sizeof(cl_int4);
	cl_mem d_first = createBuffer(ctx, CL_MEM_READ_WRITE, first_size, NULL);

	size_t last_size = config->num_particles * sizeof(cl_int4);
	cl_mem d_last = createBuffer(ctx, CL_MEM_READ_WRITE, last_size, NULL);

	find_first_last_intercept(d_geom_description, d_xDist, d_yDist, d_zDist, d_first, d_last, config);
	
	// code to read and print first
	cl_int4* first = malloc(first_size);
	readFromBuffer(cdq, d_first, first_size, first);
	waitForAllEvents(cdq);
	for (i = 0; i < config->num_particles; i++) {
		fail_unless(first[i].x == 5);
		fail_unless(first[i].y == 5);
		fail_unless(first[i].z == 5);
	}
	
} END_TEST

Suite* mcmini_suite() {
	Suite* s = suite_create("MCMini Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, test_init);
	//tcase_add_test (tc_core, RayleighUniformity);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() {
	int number_failed;

	Suite *s = mcmini_suite();
	SRunner *sr = srunner_create (s);
	srunner_set_fork_status (sr, CK_NOFORK);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

