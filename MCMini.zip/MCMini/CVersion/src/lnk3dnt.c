#include "lnk3dnt.h"

#define CYL_MESH 2
#define RZ_MESH 7
#define RZT_MESH 15
#define SPH_MESH 3
#define XYZ_MESH 14

void read_double_and_convert(FILE* f, int num, float* to_store) {
	double temp[num];
	fread(&temp, sizeof(double), num, f);
	int i;
	for (i=0; i < num; i++) {
		to_store[i] = (float) temp[i];
	}
}

void read_lnk3dnt(FILE* f, struct MCMini_config* c) {
	char buf[16];
	int i;
	fread(&buf, sizeof(char), 8, f); //hname
	buf[8] = 0;
	fread(&buf, sizeof(char), 8, f); // huse1
	fread(&buf, sizeof(char), 8, f); // huse2
	fread(&i, sizeof(int), 1, f); // ivers

	int ispec[27];
	fread(&ispec, sizeof(int), 27, f); // ispec
	
	// ispec, in this order:
	// 0 igom: 	geometry type
	// 1 nzone: 	the number of pure materials
	// 7 ninti:	number of X intercepts
	// 8 nintj:	number of Y intercepts
	// 9 nintk:	number of Z intercepts
	// 23 nmxsp:	number of material slots per element (max number of materials per element(zone?))
	// 25 intrec
	// 26 ilevel

	if (ispec[0] != XYZ_MESH) {
		fprintf(stderr, "Mesh is not XYZ -- not yet supported.\n");
	}

	c->num_materials = ispec[1];	

	float* x_bounds = malloc((2 + ispec[7]) * sizeof(float)); 
	float* y_bounds = malloc((2 + ispec[8]) * sizeof(float)); 
	float* z_bounds = malloc((2 + ispec[9]) * sizeof(float));
	
	int* zone_material = malloc(ispec[7] * ispec[8] * ispec[9] * sizeof(int) * ispec[23]);
	float* zone_density = malloc(ispec[7] * ispec[8] * ispec[9] * sizeof(float) * ispec[23]);
	c->zone_material = malloc(ispec[7] * ispec[8] * ispec[9] * sizeof(struct alias_list*));

	x_bounds[0] = (float)ispec[7]; 
	y_bounds[0] = (float)ispec[8]; 
	z_bounds[0] = (float)ispec[8]; 

	x_bounds[61] = 3.14f;

	// lnk3dnt stores all the bounds as doubles (8 bytes)
	// we'll need to read those in, and convert them
	read_double_and_convert(f, ispec[7]+1, x_bounds + 1);
	read_double_and_convert(f, ispec[8]+1, y_bounds + 1);
	read_double_and_convert(f, ispec[9]+1, z_bounds + 1);

	// store the proper pointers in the config
	c->num_x_bounds = x_bounds;
	c->num_y_bounds = y_bounds;
	c->num_z_bounds = z_bounds;
	
	c->x_bounds = x_bounds + 1;
	c->y_bounds = y_bounds + 1;
	c->z_bounds = z_bounds + 1;

	// throw out "fine-mesh" intervals
	if (0 != fseek(f, sizeof(int) * (ispec[7] + ispec[8] + ispec[9]), SEEK_CUR)) fprintf(stderr, "Could not seek in file!\n");
	int j;
	//for (i=0; i < ispec[7] + ispec[8] + ispec[9]; i++) {
	//	fread(&j, sizeof(int), 1, f);
	//}

	// read in material IDs
	int l, k;
	for (l=0; l < ispec[23]; l++) {
		for (k=0; k < ispec[9]; k++) {
			for (j=0; j < ispec[8]; j++) {
				for (i=0; i < ispec[7]; i++) {
					fread(&zone_material[(index_to_zone(c, i, j, k) * ispec[23]) + l], sizeof(int), 1, f);
					zone_material[(index_to_zone(c, i, j, k) * ispec[23]) + l]--;
				}
			}
		}
	}

	// read in zone density 
	for (l=0; l < ispec[23]; l++) {
		for (k=0; k < ispec[9]; k++) {
			for (j=0; j < ispec[8]; j++) {
				for (i=0; i < ispec[7]; i++) {
					read_double_and_convert(f, 1, &zone_density[(index_to_zone(c, i, j, k) * ispec[23]) + l]);
				}
			}
		}
	}

	// build the alias lists
	for (i=0; i < ispec[7] * ispec[8] * ispec[9]; i++) {
		int num_values = 0;
		for (k = 0; k < ispec[23]; k++) if (zone_material[(i * ispec[23]) + k] > 0 && zone_density[(i * ispec[23]) + k] > 0.f) num_values++;
		c->zone_material[i] = generate_alias_list(num_values, &(zone_material[i * ispec[23]]), &(zone_density[i * ispec[23]]));
	}

	fclose(f);
}	



