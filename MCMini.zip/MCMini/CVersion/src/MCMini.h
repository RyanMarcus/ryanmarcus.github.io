#ifndef MCMINI_H
#define MCMINI_H
#include "opencl.h"
#include "contextFactory.h"
#include "MCMini_config_read.h"
#include "strstrhashtable.h"
#include "random.h"
#include "angle_sample.h"
#include "linked_list.h"
#include "jit.h"
#include "materials.h"

#define MAX_CHILDREN_PER_REACTION 2 
#define MAX_CHILDREN_PER_REACTION_S "2"

// kernel functions
void create_initial_particles(struct opencl_runtime* r, cl_mem d_geom_description, cl_float8** particles, cl_mem* d_particles, size_t* particles_size, struct MCMini_config* config);
void do_particle_trace(struct opencl_runtime* r, cl_mem data, cl_mem particles, cl_mem x_bounds, cl_mem  y_bounds, cl_mem z_bounds, cl_mem xDist, cl_mem yDist, cl_mem zDist, struct MCMini_config* config);
void find_first_last_intercept(struct opencl_runtime* r, cl_mem data, cl_mem xDist, cl_mem yDist, cl_mem zDist, cl_mem first, cl_mem last, struct MCMini_config* config);
cl_event calculate_zones(struct opencl_runtime* r, cl_mem data, cl_mem d_first, cl_mem zones, struct MCMini_config* config);
void progress_counters(struct opencl_runtime* r, cl_mem d_particles, cl_mem d_data, cl_mem d_zones, cl_mem d_first, cl_mem d_xDist, cl_mem d_yDist, cl_mem d_zDist, cl_mem d_track_length, struct MCMini_config* config);
void calculate_attenuation(struct opencl_runtime* r, int num_zone_intercepts, cl_mem particles, cl_mem d_length_seq, cl_mem mfp, cl_mem atten, int num_intersects);
void calculate_mfp_seq(struct opencl_runtime* r, cl_mem d_length_seq, cl_mem d_mfp, cl_mem d_mfp_seq, int num_zone_intercepts);
void calculate_reactions(struct opencl_runtime* r, cl_mem reaction_done, cl_mem particles, cl_mem mfp, cl_mem lengths, cl_mem mfp_lengths, int num_intercepts, cl_mem zones, cl_mem reactions, cl_mem old_reactions, struct MCMini_config* config);
void calculate_scatter(struct opencl_runtime* r, cl_mem particles, cl_mem reactions, int reactions_per_particle, int num_reactions, int max_daughters); 
void calculate_absorb(struct opencl_runtime* r, cl_mem reactions, cl_mem energy_dep, int num_reactions, int max_daughters); 
void calculate_fission(struct opencl_runtime* r, cl_mem particles, cl_mem reactions, int reactions_per_particle, int num_reactions, int max_daughters); 
void calculate_total_reactions(struct opencl_runtime* r, cl_mem reactions, int num_reactions, cl_mem count, cl_mem below_cutoff, char* weight_cutoff);

// helper functions
int should_continue_iteration(int* zones, struct MCMini_config* config);

// host-side data processing functions
int make_zone_data_seq(struct linked_list* zones, struct MCMini_config* config, int** seq_zones, size_t* size);
int make_zone_length_data_seq(struct linked_list* zones, struct MCMini_config* config, float** seq_lengths);
int make_reaction_data(struct linked_list* zones, struct MCMini_config* config, size_t* size, cl_float8** reactions, int max_reactions_per_particle);

// stdout output functions
void output_zone_history(FILE* output, struct linked_list* ll, struct MCMini_config* config);
void output_zone_tally(FILE* output, struct linked_list* ll, struct MCMini_config* config);
void output_particle_track_lengths(FILE* output, struct linked_list* ll, struct MCMini_config* config);

#endif
