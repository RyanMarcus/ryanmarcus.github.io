#include "imaging.h"

void create_image(struct zone_tally *t, struct MCMini_config* c, int axis, int plane, FILE* f) {
	int cur_x, cur_y, cur_z;
	int max_x, max_y, max_z;

	int* inc1;
	int* inc2;
	int* max_inc1;
	int* max_inc2;

	cur_x = 0;
	cur_y = 0;
	cur_z = 0;

	max_x = (int) *c->num_x_bounds;
	max_y = (int) *c->num_y_bounds;
	max_z = (int) *c->num_z_bounds;

	switch (axis) {
		case 0: inc1 = &cur_y; inc2 = &cur_z; max_inc1 = &max_y; max_inc2 = &max_z; cur_x = plane; break;
		case 1: inc1 = &cur_x; inc2 = &cur_z; max_inc1 = &max_x; max_inc2 = &max_z; cur_y = plane; break;
		case 2: inc1 = &cur_x; inc2 = &cur_y; max_inc1 = &max_x; max_inc2 = &max_y; cur_z = plane; break;
		default: fprintf(stderr, "Unknown axis for imaging"); return; break;
	}

	float** img = malloc(sizeof(float*) * *max_inc1);
	int i;
	for (i=0; i < *max_inc1; i++) img[i] = malloc(sizeof(float) * *max_inc2); 
	
	float cur_max = 0.f;

	for (*inc1 = 0; *inc1 != *max_inc1; *inc1 = (*inc1) + 1) {
		for (*inc2 = 0; *inc2 != *max_inc2; *inc2 = (*inc2) + 1) {
		//	printf("%d, %d -> %d (%d, %d, %d): %d\n", *inc1, *inc2, index_to_zone(c, cur_x, cur_y, cur_z), cur_x, cur_y, cur_z, (int)get_value_for_zone(t, index_to_zone(c, cur_x, cur_y, cur_z)));
			img[*inc1][*inc2] = get_value_for_zone(t, index_to_zone(c, cur_x, cur_y, cur_z));
			cur_max = (cur_max > img[*inc1][*inc2] ? cur_max : img[*inc1][*inc2]);
		}	
	}

	#ifdef DEBUG
		printf("\tMax flux: %f\n", cur_max);
	#endif

	fprintf(f, "P6 %d %d 255\n", *max_inc1, *max_inc2);	
	int j;
	char b;
	for (i=0; i < *max_inc1; i++) {
		for (j=0; j < *max_inc2; j++) {
			b = (char)(255.f * (img[i][j]/cur_max));
			fwrite(&b, sizeof(char), 1, f);
			fwrite(&b, sizeof(char), 1, f);
			fwrite(&b, sizeof(char), 1, f);
		}
	}
}
