#include "strstrhashtable.h"
#define FNV_PRIME 16777619
#ifdef HASHTABLE_STATS
#endif
unsigned int str_hash(char* str, unsigned int capa);

unsigned int str_hash(char* str, unsigned int capa) {
	unsigned int hash = 2166136261;
	char* c = str;
	while (*c != 0) {
		hash ^= *c;
		hash *= FNV_PRIME;
		c++;
	}
	return hash % capa;
}

struct keyVal* ssht_makeKVPair(char* key, char* val) {
	struct keyVal* kv = (struct keyVal*) malloc(sizeof(struct keyVal));
	
	if (kv == NULL) return NULL;

	kv->key = (char*) malloc(sizeof(char) * (strlen(key) + 1));
	if (kv->key == NULL) return NULL;
	strcpy(kv->key, key);

	kv->val = (char*) malloc(sizeof(char) * (strlen(val) + 1));
	if (kv->val == NULL) return NULL;
	strcpy(kv->val, val);

	return kv;
}

struct keyVal* ssht_makeKVPairGeneric(char* key, void* val) {
	struct keyVal* kv = (struct keyVal*) malloc(sizeof(struct keyVal));
	
	if (kv == NULL) return NULL;

	kv->key = (char*) malloc(sizeof(char) * (strlen(key) + 1));
	if (kv->key == NULL) return NULL;
	strcpy(kv->key, key);


	kv->val = val;

	return kv;
}


struct strStrHashTable* ssht_create(unsigned int initCapacity) {
	struct strStrHashTable* toR = (struct strStrHashTable*) malloc(sizeof(struct strStrHashTable));
	if (toR == NULL) return NULL;	
	toR->capacity = initCapacity;
	toR->table = (struct keyVal**) calloc((size_t)initCapacity, sizeof(struct keyVal*));
	return toR;
}

int ssht_add(struct strStrHashTable* table, struct keyVal* kv) {
	// use linear probing to find out where this value should go...
	unsigned int hashVal = str_hash(kv->key, table->capacity);
	unsigned int tries = 0;
	if (hashVal == 12) printf("HERE!!!!!!\n");
	while (table->table[hashVal] != NULL) {
		// that value wasn't null -- need to expand
		tries++;
		if (tries == table->capacity) return 0;
		hashVal++;
		hashVal = hashVal % table->capacity;
	}

	table->table[hashVal] = kv;
	return 1;
}
#ifdef HASHTABLE_STATS
int misses = 0;
int lookups = 0;
#endif
struct keyVal* ssht_lookup(struct strStrHashTable* table, char* key) {
	#ifdef HASHTABLE_STATS
	lookups++;
	#endif
	unsigned int hashVal;
	#ifndef OPTIMIZE
	unsigned int tries;
	tries = 0;
	#endif

	#ifndef OPTIMIZE
	if (table == NULL) return NULL;
	if (key == NULL) return NULL;
	#endif

	hashVal = str_hash(key, table->capacity);

	while (table->table[hashVal] != NULL && strcmp(table->table[hashVal]->key, key) != 0) {
		#ifndef OPTIMIZE
		tries++;
		if (tries == table->capacity) return NULL;
		#endif 
		hashVal++;
		hashVal = hashVal % table->capacity;
	}

	#ifdef HASHTABLE_STATS
		if (table->table[hashVal] == NULL) return NULL;
		int rHashVal = str_hash(key, table->capacity);
		if (tries != 0) {
			printf("HT miss: looking for %s with hash %d (%d tries, hit %s)\n", key, rHashVal, tries, table->table[rHashVal]->key);
			misses++;
		}
	#endif


	return table->table[hashVal];
}

#ifdef HASHTABLE_STATS
void ssht_print_stats() {
	printf("%d hashtable lookups with %d misses\n", lookups, misses);
}
#endif

void free_table(struct strStrHashTable* table) {
	unsigned int i;
	if (table == NULL) return;	
	for (i = 0; i < table->capacity; i++) {
		if (table->table[i] != NULL) {		
			free(table->table[i]->key);
			free(table->table[i]->val);
			free(table->table[i]);
		}
	}

	free(table);
	return;
}

