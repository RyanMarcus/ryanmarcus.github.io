if [ -e docs/templates.txt ]; then
	rm docs/templates.txt
fi

for file in opencl_templates/*.clt; do
	echo "*** $file ***" >> docs/templates.txt
	cat $file | grep "//@" | cut -c 5- >> docs/templates.txt
	echo -e "\n" >> docs/templates.txt
done
