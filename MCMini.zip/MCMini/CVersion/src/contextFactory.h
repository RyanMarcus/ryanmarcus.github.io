#ifndef CONTEXT_FACTORY_H
#define CONTEXT_FACTORY_H
#include "opencl.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdarg.h>
#include "strstrhashtable.h"
#ifdef MEM_TRACK
#include <execinfo.h>
#endif

void trackProfData(cl_event e, cl_int status, void* data);
void printProfileInfo();

 
cl_device_id promptUserForDevice(void);
void listDevices(void);
cl_device_id getDeviceByIndex(int idx);
void printDeviceInfo(cl_device_id id);
cl_device_id getArbitraryDevice(void);

cl_context createContextFromDevice(cl_device_id id);

cl_command_queue createCommandQueue(cl_context ctx, cl_device_id id);

void releaseCommandQueue(cl_command_queue cdq);

cl_mem createBuffer(cl_context ctx, cl_mem_flags flags, size_t size, void* host);
cl_event readFromBuffer(cl_command_queue cdq, cl_mem buffer, size_t size, void* host);
cl_event writeToBuffer(cl_command_queue cdq, cl_mem buffer, size_t size, void* ptr);
void releaseMemObject(cl_mem mem);

long int getTotalMemUsed();
#ifdef MEM_TRACK
int getUnfreedBlockCount();
void printMemInfo();
#endif

cl_program createProgram(cl_context ctx, cl_device_id id, const char** string, int count);

cl_kernel createKernel(cl_program prg, const char* kernel_name);
void setKernelArg(cl_kernel ck, unsigned int index, size_t arg_size, void* arg_val);
size_t getOptimalMultiple(cl_kernel ck, cl_device_id d);
cl_event startKernel(cl_command_queue cdq, cl_kernel ck, size_t globalSize, size_t localSize); 

cl_ulong getEventDuration(cl_event event);


void waitForEvent(cl_event ce);
void waitForAllEvents(cl_command_queue cdq);
void releaseEvent(cl_event ce);

void releaseKernel(cl_kernel ck);
void releaseProgram(cl_program prg);
void releaseContext(cl_context ctx);

int roundToMult(int numToRound, int multiple);
#endif
