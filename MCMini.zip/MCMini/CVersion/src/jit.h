#ifndef JIT_H
#define JIT_H
#include "code_template.h"
#include "opencl.h"
#include "contextFactory.h"

void init_jit();
cl_kernel get_kernel(struct opencl_runtime* r, char* kernel_name, struct strStrHashTable* t);

#endif

