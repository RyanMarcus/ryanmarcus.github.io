rm -rf performance_test/test*

cd performance_test
./generate_test_files.sh
cd ..

for file in `ls performance_test/test*`
do
    echo "*** `echo $file | cut -d\"/\" -f2` ***"
    time ./MCMini $file > /dev/null
done

rm -rf performance_test/test*

