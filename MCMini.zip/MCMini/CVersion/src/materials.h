#ifndef MATERIALS_H
#define MATERIALS_H
#include "MCMini_config_read.h"
#include <math.h>
#include "alias_selection.h"
#include "random.h"

float mfp(struct MCMini_config* c, struct alias_list* ac, float density, float energy, float temperature);
int index_to_zone(struct MCMini_config* c, int x, int y, int z); 
int pick_reaction_for_material(int mat_id);
int pick_material_for_zone(int zone_id, struct MCMini_config* c, struct RandomNumberConfiguration* rnc);
#endif
