#include "transport.h"


// - do_transport
// ---- do_init
// ---- do_init_batch
// ---- do_trace
// ---- ----- do_post_trace_prints
// ---- do_reformat_trace_data
// ---- do_zone_mfp
// ---- do_attenuation
// ---- do_make_sequential_mfp_data
// ---- do_calculate_reactions
// ---- ---- do_scatter
// ---- ---- do_absorb
// ---- ---- do_fission
// ---- do_next_generation
// ---- ---- if we haven't exhausted particle weights below the cut off:
// ---- ---- ---- do_trace
// ---- ---- otherwise:
// ---- ---- ---- do_terminate_batch
// ---- do_terminate_batch
// ---- ---- do_flux_tally
// ---- ---- do_image

void do_trace();
void do_post_trace_prints();
void do_init();
void do_init_batch();
void do_reformat_trace_data();
void do_zone_mfp();
void do_attenuation();
void do_sequential_mfp_data();
void do_calculate_reactions();
void do_scatter();
void do_absorb();
void do_fission();
void do_next_generation();
void do_prepare_daughters_for_transport();
void do_terminate_batch();
void do_flux_tally();
void do_image();


// the sizes of the bounds arrays
size_t x_bounds_size;
size_t y_bounds_size;
size_t z_bounds_size;

// the device bounds buffers
cl_mem d_x_bounds;
cl_mem d_y_bounds;
cl_mem d_z_bounds;

size_t xDist_size;
cl_mem d_xDist;
                 
size_t yDist_size;
cl_mem d_yDist;
                 
size_t zDist_size;
cl_mem d_zDist; 

size_t geom_description_size;
cl_float* geom_description;

cl_mem d_geom_description;

// create pointers for the particles array
// data: x, y, z, xa, ya, za, blank, blank
size_t particles_size;
cl_float8* particles;
cl_mem d_particles;

float* length_seq;

struct linked_list* z_hist;
struct linked_list* length_hist;

float* mfp_data;
cl_mem d_mfp;

int num_zone_intercepts; 
int* zone_seq;
size_t zone_seq_size;

cl_mem d_zone_seq;
cl_mem d_length_seq;
cl_mem d_atten;


size_t mfp_seq_size;
cl_mem d_mfp_seq; 

struct linked_list* reactions; 

size_t reactions_data_size;
cl_float8* reactions_data;
cl_mem d_reactions_data;
int num_reactions;

size_t energy_dep_size;
cl_mem d_energy_dep;
float* energy_dep;

int num_generations;

struct opencl_runtime* oclr;
struct MCMini_config* config;

#pragma omp threadprivate(config, d_atten, d_energy_dep, d_geom_description, d_length_seq, d_mfp, d_mfp_seq, d_particles, d_reactions_data, d_xDist, d_x_bounds, d_yDist, d_y_bounds, d_zDist, d_z_bounds, d_zone_seq, energy_dep, energy_dep_size, geom_description, geom_description_size, length_hist, length_seq, mfp_data, mfp_seq_size, num_generations, num_reactions, num_zone_intercepts, oclr, particles, particles_size, reactions, reactions_data, reactions_data_size, xDist_size, x_bounds_size, yDist_size, y_bounds_size, zDist_size, z_bounds_size, z_hist, zone_seq, zone_seq_size)
struct run_tallies* rt;

void do_transport(struct run_tallies* tallies, struct opencl_runtime* r, struct MCMini_config* c) {
	config = c;
	config->curr_batch = 1;
	rt = tallies;
	oclr = r;
	do_init();
}

void do_init() {
	// create size variables for the bounds lists...
	// the actual bounds list are in the config object
	x_bounds_size = sizeof(int) * *config->num_x_bounds;
	y_bounds_size = sizeof(int) * *config->num_y_bounds;
	z_bounds_size = sizeof(int) * *config->num_z_bounds;

	// copy the bounds list onto the device
	d_x_bounds = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, x_bounds_size, config->x_bounds);
	d_y_bounds = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, y_bounds_size, config->y_bounds);
	d_z_bounds = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, z_bounds_size, config->z_bounds);

	writeToBuffer(oclr->cdq, d_x_bounds, x_bounds_size, config->x_bounds);
	writeToBuffer(oclr->cdq, d_y_bounds, y_bounds_size, config->y_bounds);
	writeToBuffer(oclr->cdq, d_z_bounds, z_bounds_size, config->z_bounds);

	// create the geom_description array
	// values: sourceX, sourceY, sourceZ, |xBounds|, |yBounds|, |zBounds|
	geom_description_size = sizeof(float) * 6;
	geom_description = malloc(geom_description_size);
	geom_description[0] = (float)config->source_x; 
	geom_description[1] = (float)config->source_y; 
	geom_description[2] = (float)config->source_z;
 	geom_description[3] = (float)*config->num_x_bounds;
	geom_description[4] = (float)*config->num_y_bounds;
	geom_description[5] = (float)*config->num_z_bounds;

	// copy geom_description onto the device
	d_geom_description = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, geom_description_size, geom_description);
	waitForEvent(writeToBuffer(oclr->cdq, d_geom_description, geom_description_size, geom_description));

	status_print("Baseline memory\n");

	do_init_batch();
}

void do_init_batch() {

	num_generations = 0;
	// the first step is creating the inital particles, which is done by particleCreate.clt
	// the first call here is strange because it figures out the oclr->optimal workgroup size
	// so it might change the number of particles we are using
	create_initial_particles(oclr, d_geom_description, &particles, &d_particles, &particles_size, config);

	do_trace();

}


void do_trace() {
	status_print("Starting trace...\n");

	// now that we know how many particles we are using, we can allocate xDist, yDist, and zDist
	xDist_size = config->num_particles * *config->num_x_bounds * sizeof(cl_float);
	d_xDist = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, xDist_size, NULL);

	yDist_size = config->num_particles * *config->num_y_bounds * sizeof(cl_float);
	d_yDist = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, yDist_size, NULL);

	zDist_size = config->num_particles * *config->num_z_bounds * sizeof(cl_float);
	d_zDist = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, zDist_size, NULL);


	// now do the particle trace
	do_particle_trace(oclr, d_geom_description, d_particles, d_x_bounds, d_y_bounds, d_z_bounds, d_xDist, d_yDist, d_zDist, config);

	// we still need bounds in order to trace the daughters

	// create first and last intercept array
	size_t first_size = config->num_particles * sizeof(cl_int4);
	cl_mem d_first = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, first_size, NULL);

	size_t last_size = config->num_particles * sizeof(cl_int4);
	cl_mem d_last = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, last_size, NULL);
	
	// find those intercepts
	find_first_last_intercept(oclr, d_geom_description, d_xDist, d_yDist, d_zDist, d_first, d_last, config);

	// create an array for zones on the device
	size_t zones_size = config->num_particles * sizeof(cl_int);
	int* zones = malloc(zones_size);
	cl_mem d_zones = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, zones_size, NULL);

	// create an array for track lengths on the device
	size_t track_length_size = config->num_particles * sizeof(cl_float);
	float* track_length = malloc(track_length_size);
	cl_mem d_track_length = createBuffer(oclr->ctx, CL_MEM_WRITE_ONLY, track_length_size, NULL);  
	cl_event zone_calc_event = NULL;

	// create a linked list to store the zones list and track lengths
	z_hist = ll_create();
	length_hist = ll_create();

	while (1==1) {
		// calculate our current zones -- keep in mind that d_zones can not change until
		// we've copied that data back to the host for saving
		calculate_zones(oclr, d_geom_description, d_first, d_zones, config); 
		readFromBuffer(oclr->cdq, d_zones, zones_size, zones);
		
		// progress the counters in first
		progress_counters(oclr, d_particles,d_geom_description, d_zones, d_first, d_xDist, d_yDist, d_zDist, d_track_length, config);
		zone_calc_event = readFromBuffer(oclr->cdq, d_track_length, track_length_size, track_length);

		if (zone_calc_event != NULL) {
			waitForEvent(zone_calc_event);
			if (0 == should_continue_iteration(zones, config)) break;

			// if we are still here, we need to copy zones back and add it to our list
			add_to_linked_list(zones, zones_size, z_hist);
			add_to_linked_list(track_length, track_length_size, length_hist);
		}	
	}

	// don't need: d_track_length, d_zones, d_first, d_last, d_xDist, d_yDist, d_zDist
	releaseMemObject(d_track_length);
	releaseMemObject(d_zones);
	releaseMemObject(d_first);
	releaseMemObject(d_last);
	releaseMemObject(d_xDist);
	releaseMemObject(d_yDist);
	releaseMemObject(d_zDist);
	free(track_length);
	free(zones);
	status_print("Trace done\n");
	do_post_trace_prints();

	do_reformat_trace_data();
	
}

void do_reformat_trace_data() {
	num_zone_intercepts = make_zone_data_seq(z_hist, config, &zone_seq, &zone_seq_size);
	
	make_zone_length_data_seq(length_hist, config, &length_seq);
	//int i;
	//for(i=0; i < zone_seq_size / sizeof(float); i++) {
	//	printf("%d\n", zone_seq[i]);
	//}
	
	do_zone_mfp();

}

void do_post_trace_prints() {
	if (config->zone_tally == 1) {
		status_print("\nZone tallies...\n");
		output_zone_tally(output, z_hist, config);
	}

	if (config->particle_track_length == 1) {
		status_print("\nParticle track lengths...\n");
		output_particle_track_lengths(output, length_hist, config);
	}

	if (config->zone_history == 1) {
		status_print("\nParticle zone history...\n");
		output_zone_history(output, z_hist, config);
	}
}

void do_zone_mfp() {
	status_print("Calculating zone MFPs...\n");
	waitForEvent(readFromBuffer(oclr->cdq, d_particles, particles_size, particles));
	mfp_data = calloc(num_zone_intercepts, sizeof(float));
	int i;
	// calculate the mfp for each zone
	for (i=0; i < num_zone_intercepts; i++) {
		if (zone_seq[i] == -1) { mfp_data[i] = -1.f; continue; }
		mfp_data[i] = mfp(config, config->zone_material[zone_seq[i]], 2.0f, particles[i / num_zone_intercepts].s6, 30.0f);
	}

	d_mfp = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, num_zone_intercepts * sizeof(float), mfp_data);
	waitForEvent(writeToBuffer(oclr->cdq, d_mfp, num_zone_intercepts * sizeof(float), mfp_data));

	do_attenuation();

}

void do_attenuation() {
	// copy the length and mfp data on to the device, and then
	// make room for attenuated weights

	d_zone_seq = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, zone_seq_size, zone_seq);
	d_length_seq = createBuffer(oclr->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, num_zone_intercepts * sizeof(float), length_seq);
	d_atten = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, num_zone_intercepts * sizeof(float), NULL);

	writeToBuffer(oclr->cdq, d_zone_seq, zone_seq_size, zone_seq);
	writeToBuffer(oclr->cdq, d_length_seq, num_zone_intercepts * sizeof(int), length_seq);

	calculate_attenuation(oclr, num_zone_intercepts, d_particles, d_length_seq, d_mfp, d_atten, num_zone_intercepts);	

	// deal with attenuation... note that the attenuated weights must be recorded before checking for reactions,
	// because the reactions algorithm modifies the particle's weight
	float* atten = malloc(sizeof(float) * num_zone_intercepts);
	cl_event atten_read = readFromBuffer(oclr->cdq, d_atten, sizeof(float) * num_zone_intercepts, atten);	
	
	waitForEvent(atten_read);

	releaseMemObject(d_atten);
	
	// store it in the flux tally
	add_to_tally(rt->flux, num_zone_intercepts, zone_seq, atten);

	add_to_tally_inc(rt->zone, num_zone_intercepts, zone_seq);

	do_sequential_mfp_data();

}

void do_sequential_mfp_data() {
	// build our seq_mfp data
	mfp_seq_size = num_zone_intercepts * sizeof(float);
	d_mfp_seq = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, mfp_seq_size, NULL);
	calculate_mfp_seq(oclr, d_length_seq, d_mfp, d_mfp_seq, num_zone_intercepts);

	//int i;
	//float* mfp_seq = malloc(mfp_seq_size);
	//waitForEvent(readFromBuffer(oclr->cdq, d_mfp_seq, mfp_seq_size, mfp_seq));
	//for (i=0; i < num_zone_intercepts; i++) {
	//	printf("%f %f\n", length_seq[i], mfp_seq[i]);
	//}
	
	do_calculate_reactions();	
}

void do_calculate_reactions() {
	status_print("Calculating reactions...\n");

	// in order to calculate actual reactions, we'll use an interation method similar to our ray trace
	// method. NOTE: this algorithm only supports one reaction type per zone, but could be easily modified
	// to support more.
	// 1. create an array (reactions_done) of size equal to particles, initially filled with 0s. This array will contain
	//    all 1s when a particular particle has had all of it's reactions calculated (when we've sampled
	//    enough mean-free-paths to exit the geometry)
	// 2. while reactions_done is not all -1s, run the following sets of kernels PER PARTICLE
	//
	//	1. For all kernels: if my entry in reactions_done is a -1, finish.
	//	2. calculate a random number of MFPs, and determine the zone that lands us in.
	//		a. if the zone is out of the geometry, set my reactions_done value to -1 and finish
	//	3. place the zone ID into an array reaction_zone_ids, along with the position and weight of the reaction
	//		a. Place with the reaction weight and position.
	//		b. Update the particle's weight
	//	4. Pull that array into a linked list on the host
	//	5. replace each zone ID with a reaction type for that zone (scatter, absorb, fission)
	//	6. calculate the scatter reactions
	//	7. calculate the absorb reactions (no new particle data -- but add to an array containing how much energy has been left in a zone, energy_dep)
	//	8. calculate the fission reactions
	//	9. Store the children and energy_dep arrays into a linked list on the host, clear each array, and repeat

	
	size_t reaction_done_size = config->num_particles * sizeof(int);
	int* reaction_done = calloc(config->num_particles, sizeof(int));
	cl_mem d_reaction_done = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, reaction_done_size, reaction_done);
	writeToBuffer(oclr->cdq, d_reaction_done, reaction_done_size, reaction_done);

	// in order to calculate reactant particle weights, we need to have two arrays -- one for the last
	// set of reactions and one for the next. This is because the next reaction a particle has depends on
	// the previous reaction a particle had
	// we'll use two arrays, and we'll swap pointers to those arrays.
	size_t reaction_zone_id_size = config->num_particles * sizeof(cl_float8) * MAX_CHILDREN_PER_REACTION;
	cl_mem d_reaction_zone_id = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, reaction_zone_id_size, NULL);
	cl_float8* reaction_zone_id = malloc(reaction_zone_id_size);	

	size_t old_reaction_zone_id_size = config->num_particles * sizeof(cl_float8) * MAX_CHILDREN_PER_REACTION;
	cl_mem d_old_reaction_zone_id = createBuffer(oclr->ctx, CL_MEM_READ_WRITE, old_reaction_zone_id_size, NULL);

	cl_mem* temp = NULL;
	cl_mem* curr_old = NULL;
	cl_mem* curr_new = &d_reaction_zone_id;

	reactions = ll_create();

	waitForAllEvents(oclr->cdq);

	do {
		calculate_reactions(oclr, d_reaction_done, d_particles, d_mfp, d_length_seq, d_mfp_seq, num_zone_intercepts, d_zone_seq, *curr_new, (curr_old ==  NULL? NULL : *curr_old), config);
		if (curr_old == NULL) curr_old = &d_old_reaction_zone_id;
	
		// pull back the iterator array and check it
		readFromBuffer(oclr->cdq, *curr_new, reaction_zone_id_size, reaction_zone_id);	
		waitForEvent(readFromBuffer(oclr->cdq, d_reaction_done, reaction_done_size, reaction_done));
		// code to print out reactions as they are calculated
		//iint i;
		//for (i=0; i < config->num_particles*MAX_CHILDREN_PER_REACTION; i++) printf("%d: %f %f %f (progressed: %f from %f)\n", (int)reaction_zone_id[i].s3, reaction_zone_id[i].s0, reaction_zone_id[i].s1, reaction_zone_id[i].s2, reaction_zone_id[i].s4, reaction_zone_id[i].s5);
		//printf("\n");
		add_to_linked_list(reaction_zone_id, reaction_zone_id_size, reactions);
	
		temp = curr_old;
		curr_old = curr_new;
		curr_new = temp;
	} while(should_continue_iteration(reaction_done, config));
	num_reactions = make_reaction_data(reactions, config, &reactions_data_size, &reactions_data, MAX_CHILDREN_PER_REACTION);
	
	//num_reactions /= MAX_CHILDREN_PER_REACTION;
	status_print("Generation had %d reactions\n", num_reactions);

	// need an array to store energy dep into
	energy_dep_size = NUM_ZONES(config) * sizeof(cl_float);
	energy_dep = calloc(NUM_ZONES(config), sizeof(cl_float));
	d_energy_dep = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, energy_dep_size, energy_dep);
	writeToBuffer(oclr->cdq, d_energy_dep, energy_dep_size, energy_dep);

	// we need to copy the reaction data onto the device, and free up some of the memory we no longer need
	releaseMemObject(d_reaction_done);
	releaseMemObject(d_reaction_zone_id);
	releaseMemObject(d_old_reaction_zone_id);
	releaseMemObject(d_mfp);
	releaseMemObject(d_mfp_seq);
	releaseMemObject(d_zone_seq);
	releaseMemObject(d_length_seq);

	status_print("Reactions calculated\n");

	d_reactions_data = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, reactions_data_size, reactions_data);
	waitForEvent(writeToBuffer(oclr->cdq, d_reactions_data, reactions_data_size, reactions_data));

	


	// each of the reaction functions (do_scatter, do_absorb, and do_fission) will iterate over the reaction data array and
	// will calculate all of the reactions with their particular ID. They will modify the reactions_data array in order
	// to store their new particle's angle cosines and energies

	//printf("Before...\n");
	// code to read back d_reactions_data and print it
	//waitForEvent(readFromBuffer(oclr->cdq, d_reactions_data, reactions_data_size, reactions_data));
	//int i;
	//for (i=0; i < reactions_data_size / sizeof(cl_float8); i++) {
	//	printf("%f %f %f @ %f MeV\n", reactions_data[i].s3, reactions_data[i].s4, reactions_data[i].s5, reactions_data[i].s6);
	//}
	do_scatter();
	do_absorb();
	do_fission();
	//printf("After...\n");

	// TODO store energy dep
	releaseMemObject(d_energy_dep);

	// code to read back d_reactions_data and print it
	//waitForEvent(readFromBuffer(oclr->cdq, d_reactions_data, reactions_data_size, reactions_data));
	//int i;
	//for (i=0; i < reactions_data_size / sizeof(cl_float8); i++) {
	//	printf("%f %f %f @ %f MeV\n", reactions_data[i].s3, reactions_data[i].s4, reactions_data[i].s5, reactions_data[i].s6);
	//	printf("%f @ %f MeV\n", reactions_data[i].s7, reactions_data[i].s6);
	//}
	

	do_next_generation();
	
}

void do_scatter() {
	calculate_scatter(oclr, d_particles, d_reactions_data, num_reactions/(config->num_particles), num_reactions, MAX_CHILDREN_PER_REACTION);
}

void do_absorb() {
	calculate_absorb(oclr, d_reactions_data, d_energy_dep, num_reactions, MAX_CHILDREN_PER_REACTION);
	
	//waitForEvent(readFromBuffer(oclr->cdq, d_energy_dep, energy_dep_size, energy_dep));
	//int i;
	//for (i=0; i<NUM_ZONES(config); i++) printf("%d: %f\n", i, energy_dep[i]);
}

void do_fission() {
	calculate_fission(oclr, d_particles, d_reactions_data, num_reactions/(config->num_particles), num_reactions, MAX_CHILDREN_PER_REACTION);	
}

void do_next_generation() {
	if (num_generations == 2) { // TODO hard-coded 2 generations
		num_generations = 0;
		do_terminate_batch();
	}  else {
		num_generations++;
		status_print("Progressing to next generation (%d)...\n", num_generations);
		do_prepare_daughters_for_transport();
	}
}

void do_prepare_daughters_for_transport() {
	// count the number of particles we had react...
	int next_gen_size = 0;
	int below_cut = 0;
	cl_mem count = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, sizeof(cl_int), &next_gen_size);
	cl_mem d_below_cut = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, sizeof(cl_int), &below_cut);
	writeToBuffer(oclr->cdq, count, sizeof(cl_int), &next_gen_size);
	writeToBuffer(oclr->cdq, d_below_cut, sizeof(cl_int), &below_cut);
	calculate_total_reactions(oclr, d_reactions_data, num_reactions, count, d_below_cut, "0.05f"); 	


	readFromBuffer(oclr->cdq, d_below_cut, sizeof(cl_int), &below_cut);
	waitForEvent(readFromBuffer(oclr->cdq, count, sizeof(cl_int), &next_gen_size));
	
	releaseMemObject(count);
	releaseMemObject(d_below_cut);	

	if (next_gen_size == 0) {
		do_terminate_batch();
		return;
	}
	int real_next_gen_size = next_gen_size;
	next_gen_size = roundToMult(next_gen_size, oclr->opt); // need to have a good number of reactants


	status_print("Generation has %d (%d) particles with %d below the cutoff\n", next_gen_size, real_next_gen_size, below_cut);

	// recreate the particles array and load our data into it
	config->num_particles = next_gen_size;	
	particles_size = sizeof(cl_float8) * next_gen_size;
	releaseMemObject(d_particles);
	if (particles != NULL) free(particles);
	particles = malloc(particles_size);

	waitForEvent(readFromBuffer(oclr->cdq, d_reactions_data, reactions_data_size, reactions_data));

	releaseMemObject(d_reactions_data);
	
	int j = 0;
	int i = 0;
	for (i=0; j < next_gen_size && i < num_reactions; i++) {
		if ((int)reactions_data[i].s6 != -1) {
			particles[j] = reactions_data[i];
			j++;
		}
	}

	for (j=real_next_gen_size; j < next_gen_size; j++) {
		particles[j].s0 = -1.f;
		particles[j].s1 = -1.f;
		particles[j].s2 = -1.f;
		particles[j].s3 = -1.f;
		particles[j].s4 = -1.f;
		particles[j].s5 = -1.f;
		particles[j].s6 = -1.f;
		particles[j].s7 = -1.f;
	}

	d_particles = createBuffer(oclr->ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, particles_size, particles);
	waitForEvent(writeToBuffer(oclr->cdq, d_particles, particles_size, particles));	
	do_trace();
}

void do_terminate_batch() {
	releaseMemObject(d_particles);
	releaseMemObject(d_reactions_data);

	// figure out if we have any more batches to run, then write out our data and exit
	status_print("Batch %d complete\n", config->curr_batch);
	#ifdef MEM_TRACK
	printMemInfo();
	#endif
	if (config->curr_batch != config->num_batches) {
		config->curr_batch++;
		do_init_batch();
		return;	
	}

	releaseMemObject(d_x_bounds);
	releaseMemObject(d_y_bounds);
	releaseMemObject(d_z_bounds);
	releaseMemObject(d_geom_description);

	#pragma omp barrier

	#pragma omp master
	{
		do_flux_tally();
		do_image();
	}
}

void do_flux_tally() {
	if (config->flux_tally == 0) return;
	FILE* f = fopen("flux", "w");
	int i;
	write_geom_data(config, f);	
	for (i=0; i < NUM_ZONES(config); i++) {
		float val = get_value_for_zone(rt->flux, i);
		if (val != 0.0f) fprintf(f, "%d: %f\n", i, val);	
	}
	fclose(f);
	status_print("Flux data stored\n");
}

void do_image() {
	if (config->image_axis == -1) return;
	struct zone_tally* zt = (config->image_type == IMAGE_TYPE_FLUX ? rt->flux : rt->zone);
	create_image(zt, config, config->image_axis, config->image_plane, fopen("out.ppm", "w"));
	status_print("Image created on axis %d with plane %d\n", config->image_axis, config->image_plane);	
}

void add_to_linked_list(void* array, size_t array_size, struct linked_list* ll) {
	int* cpy = malloc(array_size);
	memcpy(cpy, array, array_size);
	ll_add(cpy, ll);
}

void status_print(char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	#ifdef MEM_TRACK
	fprintf(output, "%d (%d) ", omp_get_thread_num(), (int)getUnfreedBlockCount());
	#else
	fprintf(output, "%d ", omp_get_thread_num());
	#endif
	vfprintf(output, format, argptr);
	va_end(argptr);
}
