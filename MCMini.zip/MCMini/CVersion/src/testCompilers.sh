make clean
echo "GCC"
make ERRORHALT=false DEBUG=false PROFILE=true CC=gcc -j8
time ./MCMini config_reader_tests/test5.txt > gcc.txt
gprof MCMini >> gcc.txt

echo "Clang"
make clean
make ERRORHALT=false DEBUG=false PROFILE=true CC=clang -j8
time ./MCMini config_reader_tests/test5.txt > clang.txt
gprof MCMini >> clang.txt

echo "PGI"
make clean
make ERRORHALT=false DEBUG=false PROFILE=true CC=pgcc -j8
time ./MCMini config_reader_tests/test5.txt > pgcc.txt
gprof MCMini >> pgcc.txt
