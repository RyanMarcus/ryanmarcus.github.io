#ifndef CONFIG_READER_H
#define CONFIG_READER_H
#include "strstrhashtable.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_PARAMS 200

/**
Reads in a configuration file and returns a key, value hash table
*/
struct strStrHashTable* read_config(char* filename);

/**
Returns the index of needle within haystack, or -1 if it is not found
*/
int find_char_in_string(char* haystack, char needle);
#endif
