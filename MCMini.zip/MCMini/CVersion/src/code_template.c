#include "code_template.h"
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int getFileSize(char* filename);
char* readOneTemplate(char* templateName, struct strStrHashTable* vars);
char** readRequirments(char* kernel_code, int* num_required);

/*int getSizeDelta(struct strStrHashTable* vars) {
	if (vars == NULL) return 0;

	// iterating over the actual hashtable. Kinda messy...
	int i;
	int val;
	int toReturn = 0;
	for (i = 0; i < vars->capacity; i++) {
		if(vars->table[i] == NULL) continue;
		val = strlen(vars->table[i]->val) - strlen(vars->table[i]->key);
		val = (val < 0 ? 0 : val);
		toReturn += val;
	}

	return toReturn;
}*/

char* readTemplate(char* templateName, struct strStrHashTable* vars) {
	char** temp = calloc(10, sizeof(char*));
	temp[0] = readOneTemplate(templateName, vars);
	
	if (temp[0] == NULL) return NULL;

	int i, num_requirments;
	char** requirments;
	requirments = readRequirments(temp[0], &num_requirments);
	for (i=0; i < num_requirments; i++) {
		temp[i+1] = readTemplate(requirments[i], vars);
		if (temp[i+1] == NULL) {
			fprintf(stderr, "Failed to load a required template: %s\n", requirments[i]);
		}
		free(requirments[i]);
	}

	free(requirments);

	size_t total_size = 0;
	for(i=0; i < num_requirments + 1; i++) {
		total_size += strlen(temp[i]);
	}

	total_size *= sizeof(char);
	total_size++;
	char* toReturn = malloc(total_size);
	toReturn[0] = 0;
	for(i=num_requirments; i >= 0; i--) {
		strcat(toReturn, temp[i]);
		free(temp[i]);
	}

	free(temp);
	

	return toReturn;
	

}

char* readOneTemplate(char* templateName, struct strStrHashTable* vars) {

	int p = 0;
	p = open(templateName, O_RDONLY);

	if (p == -1) {
		fprintf(stderr, "Failed to open %s\n", templateName);
		perror("Failed to open template for reading");
		return NULL;
	}

	// determine the size of the file
	size_t sz = getFileSize(templateName) + 1;

	// map it into memory
	char* file = (char*) mmap(NULL, sz, PROT_READ, MAP_PRIVATE, p, 0);

	
	// figure out the delta between the file and the file with replaced variables
	//int sizeDiff = getSizeDelta(vars);
	int sizeDiff = 1024; // useless to try to determine size deltas, variables can be replaced more than once
	

	// be safe
	sizeDiff = (sizeDiff < 0 ? 0 : sizeDiff);

	char* toReturn = (char*) calloc(sz + sizeDiff, sizeof(char));

	// iterate over file, copying into toReturn, replacing variables as we go
	char* c = file;
	while (c < (file + sz) && *c != 0) {
		if (*c == '%' && *(c + 1) == '%') {
			strncat(toReturn, c, 1);
			c += 2;
			continue;
		}
		if (*c == '%') {
			char* startMatch = c; // mark the start of the match
			c++;
			// match. look for ending match...
			while (*c != 0 && *c != '%') {
				c++;
			}

			// c is now at the end %, or the end of the file
			if (*c == 0) {
				fprintf(stderr, "No matching %% found\n");
				return NULL;
			}

			// c is now at the end %
			// copy the parameter name into varName
			int length = c - startMatch;
			length++;
			char* varName = calloc(length + 1, sizeof(char));
			strncpy(varName, startMatch, length);


			// see if we have varName in our variable list...
			struct keyVal* toRep = ssht_lookup(vars, varName);
			if (toRep == NULL) {
				fprintf(stderr, "Did not find replacement for %s (len=%d)\n", varName, length);
				return NULL;
			}

			strcat(toReturn, toRep->val);
			free(varName);
			
			if (*c == 0) break;

			c++;
			continue;
		}
		// regular character -- append it
		strncat(toReturn, c, 1);
		c++;
	}
		


	munmap((void*) file, sz);
	return toReturn;
}

char** readRequirments(char* kernel_code, int* num_required) {
	int i;
	char* stop;
	char* start;
	char* token;
	size_t token_length;
	char** toReturn = calloc(10, sizeof(char*));
	*num_required = 0;

	if (kernel_code == NULL) return NULL;

	for (i=0; i < strlen(kernel_code); i++) {
		if (strncmp(kernel_code + i, "//@ REQUIRES", 12) == 0) {
			// found it
			start = kernel_code + i + 13;
			stop = strchr(start, '\n');
			while (start < stop) {
				token_length = strcspn(start, " \n");
				token = malloc((token_length + 1) * sizeof(char));
				strncpy(token, start, token_length);
				token[token_length] = 0;
	
				if (strcmp(token, "none") == 0) {
					free(token);
					return NULL;
				}

				toReturn[*num_required] = token;
				(*num_required)++;

				start += token_length + 1;
			}
			return toReturn;
		}
	}

	return NULL;
}


int getFileSize(char* filename) {
	FILE* p = fopen(filename, "r");

	if (p == NULL) {
		perror("Failed to measure file size");
		return 0;
	}

	fseek(p, 0L, SEEK_END);
	size_t sz = ftell(p);
	rewind(p);
	return (int)sz;
}

/*
int main() {
	struct strStrHashTable* t = ssht_create(2);
	ssht_add(t, ssht_makeKVPair("%VAR1%", "!var 1 value!"));
	ssht_add(t, ssht_makeKVPair("%VAR2%", "!var 2 value!"));
	printf("%s", readTemplate("test.txt", t));
	return 0;
}
*/
