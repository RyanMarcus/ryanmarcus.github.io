#ifndef RANDOM_H
#define RANDOM_H
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "code_template.h"

struct RandomNumberConfiguration {
	int current; // the current seed for the random number generator
	int multiplyValue; // the value to multiply the seed by (degree 1 in the LRNG)
	int modValue; // the value to mod the LRNG by
	int addValue; // the constant (degree 0) term in the LRNG
	int position; // the position of the RNC (starts at 0)
	int bitmask; // the bitmask (AND) for the number
};


/**
Creates and returns a pointer to a freshly initalized RNC that can be used with other methods provided here
*/
struct RandomNumberConfiguration* getRandomNumberGenerator(int generator_id);

/**
Returns the next random number in the sequence represented by the passed RNC and advances the RNC. This performs
the calculation on the host, not the device. Generates a number between 0 and 1.
*/
float h_rand(struct RandomNumberConfiguration* rnc);

/**
Same as h_rand, but returns a non-normalized value.
*/
int h_rand_nonorm(struct RandomNumberConfiguration* rnc);

/**
Advances the RNC by a certain number in a fast manner and updates the RNC to represent that change. This performs
the calculation on the host, not the device.
*/
void h_skipAhead(struct RandomNumberConfiguration* rnc, int toSkip);

/**
Adds in required random number values for the random.clt kernel
*/
void createRandomNumberDeviceCode(struct RandomNumberConfiguration* rnc, struct strStrHashTable* t);

#endif


