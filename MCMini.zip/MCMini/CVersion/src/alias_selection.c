#include "alias_selection.h"
#include <math.h>

#define FLOAT_CMP(x, y) (fabs(x - y) < 0.0001f)
#include <stdio.h>
int check_for_more_weight(int num_weights, float* weights, int* max, int* min) {
	
	int i;
	for (i = 0; i < num_weights; i++) {
		*max = (weights[i] > weights[*max] ? i : *max);
		if (weights[*min] == 0.0f) {
			if (weights[i] != 0.0f) *min = i;
		} else {
			if (weights[i] != 0.0f && weights[i] < weights[*min]) *min = i;
		}
	}


	if (FLOAT_CMP(weights[*min], 0.0f)) return 0;
	return 1;
}

struct alias_list* generate_alias_list(int num_values, int* values, float* weights) {
	if (num_values == 0) return NULL;
	struct alias_list* toReturn = malloc(sizeof(struct alias_list));
	
	toReturn->ali = malloc(num_values * sizeof(struct alias_list_item*));
	toReturn->count = (unsigned int) num_values;

	unsigned int i;
	for (i=0; i < toReturn->count; i++) {
		toReturn->ali[i] = calloc(1, sizeof(struct alias_list_item));
	}


	// create a copy of weights to work with
	float* lweights = malloc(sizeof(float) * num_values);
	memcpy(lweights, weights, sizeof(float) * num_values);

	// normalize the weights
	float sum = 0.f;
	for (i=0; i < num_values; i++) {
		sum += lweights[i];
	}
		
	for (i=0; i < num_values; i++) {
		lweights[i] /= sum;
	}

	// create an alias'd list like so:
	// normalize all the weights (make them add to 1)
	// while there is still weight to distribute
	// 	put as much weight as possible from the current value with the least remaining weight into an empty partition
	// 	if that doesn't completely fill the partiion, fill the rest with the element with the most remaining weight
	int min = 0;
	int max = 0;
	i = 0;
	struct alias_list_item* empty;
	while (check_for_more_weight(num_values, lweights, &max, &min) != 0) {
		// find an empty partition
		empty = toReturn->ali[i];	
		empty->choice_a = min;
		empty->weight = (lweights[min] > (1.f / num_values) ? (1.f / num_values) : lweights[min]);
		lweights[min] = lweights[min] - empty->weight;
		empty->weight /= (1.f / num_values);
		if (!FLOAT_CMP(empty->weight, 1.f)) { 
			// we need to add more weight here
			float weight_to_add = (1.f - empty->weight) * (1.f / num_values);
			lweights[max] -= weight_to_add;
			empty->choice_b = max;
		}
		i++;
	}
	
	// copy in our values and weights for later use
	toReturn->values = malloc(sizeof(int) * num_values);
	toReturn->weights = malloc(sizeof(float) * num_values);
	memcpy(toReturn->values, values, sizeof(int) * num_values);
	memcpy(toReturn->weights, weights, sizeof(float) * num_values);

	free(lweights);

	return toReturn;
}

int sample_from_alias_list(struct alias_list* al, float rand1, float rand2) {
	struct alias_list_item* ali = al->ali[(int)(rand1 * (float)al->count)];
	return (rand2 < ali->weight ? ali->choice_a : ali->choice_b);
}


void free_alias_list(struct alias_list* al) {
	unsigned int i;
	for (i=0; i < al->count; i++) {
		free(al->ali[i]);
	}

	free(al);
} 
