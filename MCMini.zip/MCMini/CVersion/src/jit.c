#include "jit.h"

#define NUMBER_OF_KERNELS 15 
#define ZERO_DEGREE_INCREASE 5
#define ONE_DEGREE_INCREASE 2

struct strStrHashTable* jit_table;

#pragma omp threadprivate(jit_table)

cl_kernel* compile_kernel(struct opencl_runtime* r, char* kernel_name, struct strStrHashTable* t);

void init_jit() {
	jit_table = ssht_create(NUMBER_OF_KERNELS * ONE_DEGREE_INCREASE + ZERO_DEGREE_INCREASE);
}

cl_kernel get_kernel(struct opencl_runtime* r, char* kernel_name, struct strStrHashTable* t) {
	struct keyVal* kv = ssht_lookup(jit_table, kernel_name);
	if (kv != NULL) return *((cl_kernel*)kv->val);

	// the table is null, the caller was expecting a cached result.
	if (t == NULL) return NULL;

	// we need to compile and return the kernel
	ssht_add(jit_table, ssht_makeKVPairGeneric(kernel_name, compile_kernel(r, kernel_name, t)));
	return get_kernel(r, kernel_name, t);
}

cl_kernel* compile_kernel(struct opencl_runtime* r, char* kernel_name, struct strStrHashTable* t) {
	//  pull the source together
	char* prgm_src = readTemplate(kernel_name, t);

	// compile and load the program
	cl_program prgm = createProgram(r->ctx, r->did, (const char**) &prgm_src, 1);

	// create a kernel for the program
	cl_kernel* ck = malloc(sizeof(cl_kernel)); 
	*ck = createKernel(prgm, ssht_lookup(t, "%NAME%")->val);

	free(prgm_src);
	return ck;
}
