import re

create = re.compile("([a-zA-Z_0-9]+?) = createBuffer")
free = re.compile('releaseMemObject\((.+?)\)')

f = open("transport.c", "r")

all_creates = []
all_frees = []

for l in f:
	o = create.search(l)
	if o != None:
		all_creates.append(o.group(1))

	o = free.search(l)
	if o != None:
		all_frees.append(o.group(1))

all_creates = set(all_creates)
all_frees = set(all_frees)

print all_creates - all_frees
