#ifndef ALIAS_H
#define ALIAS_H

#include <stdlib.h>
#include <string.h> // for memcpy
struct alias_list_item {
	int choice_a;
	int choice_b;
	float weight;	
};

struct alias_list {
	struct alias_list_item** ali;
	unsigned int count;
	float* weights;
	int* values;
};

struct alias_list* generate_alias_list(int num_values, int* values, float* weights);
int sample_from_alias_list(struct alias_list* al, float rand1, float rand2);
void free_alias_list(struct alias_list* al);

#endif
