#include "linked_list.h"

struct linked_list* ll_create() {
	return calloc(1, sizeof(struct linked_list));
}

void ll_add(void* toAdd, struct linked_list* root) {
	if (root->root == NULL) {
		root->root = calloc(1, sizeof(struct int_array_node));
		root->root->val = toAdd;
		root->last = root->root;
		return;
	}

	root->last->next = calloc(1, sizeof(struct int_array_node));
	root->last = root->last->next;
	root->last->val = toAdd;
	root->last->next = NULL;
}

void* ll_pop(struct linked_list* root) {
	if (root->root == NULL) return NULL;
	void* toReturn = root->root->val;
	struct int_array_node* next = root->root->next;	
	free(root->root);
	root->root = next;
	return toReturn;
}

struct linked_list* ll_clone(struct linked_list* root) {
	struct linked_list* toReturn = ll_create();
	struct int_array_node* n = root->root;

	while (n != NULL) {
		ll_add(n->val, toReturn);
		n = n->next;
	}

	return toReturn;
}

int ll_length(struct linked_list* root) {
	int i = 1;
	if (root == NULL) return 0;
	struct int_array_node* n = root->root;
	if (n == NULL) return 0;
	while ((n = n->next) != NULL) i++;
	return i;
}
