#ifndef TRANSPORT_H
#define TRANSPORT_H
#include "omp.h"
#include "MCMini.h"
#include <string.h> // for memcpy
#include "opencl.h"
#include "linked_list.h"
#include "materials.h"
#include "tally.h"
#include "jit.h"
#include "imaging.h"
#define NUM_ZONES(config) (int)*config->num_x_bounds * (int)*config->num_y_bounds * (int)*config->num_z_bounds


FILE* output;

void do_transport(struct run_tallies* tallies, struct opencl_runtime* r, struct MCMini_config* c); 
void add_to_linked_list(void* array, size_t array_size, struct linked_list* ll);
void status_print(char* str, ...);
#endif
