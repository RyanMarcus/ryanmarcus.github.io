//! Provides functions for sampling angles


#ifndef ANGLE_SAMPLE_H
#define ANGLE_SAMPLE_H

#include "code_template.h"
#include "contextFactory.h"

/**
Runs OpenCL code on an arbitrary device to generate a given number of angle samples. The array returned
will contain [u1, v1, w1, u2, v2, w2...]. Runs the code on the passed device.
*/
float* generateAngleSamples(int numSamples, cl_device_id did);

#endif
