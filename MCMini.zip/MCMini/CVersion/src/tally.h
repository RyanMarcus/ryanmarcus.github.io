#ifndef TALLY_H
#define TALLY_H

#include <stdlib.h>

#define TALLY_ID_FLUX 0
#define TALLY_ID_ZONE 1

struct run_tallies {
	struct zone_tally* flux;
	struct zone_tally* zone;
};

struct zone_tally {
	float* tally;
	int tally_id;
};

struct zone_tally* create_zone_tally(int num_zones, int tally_id);
void add_to_tally(struct zone_tally* zt, int num_zones, int* zone_indexes, float* values);
void add_to_tally_inc(struct zone_tally* zt, int num_zones, int* zone_indexes);
float get_value_for_zone(struct zone_tally* zt, int zone_index);

#endif
