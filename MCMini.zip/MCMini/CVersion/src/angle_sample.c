#include "angle_sample.h"
#include "random.h"

float* generateAngleSamples(int numSamples, cl_device_id did) {
	cl_context ctx = createContextFromDevice(did);
	cl_command_queue cdq = createCommandQueue(ctx, did);

	// get the program together...
	struct strStrHashTable* t = ssht_create(10);
	ssht_add(t, ssht_makeKVPair("%NAME%", "generateAngles"));
	createRandomNumberDeviceCode(getRandomNumberGenerator(1), t);

	char* prgm_src = readTemplate("opencl_templates/angleSampleTest.clt", t);

	// compile and load the program
	cl_program prgm = createProgram(ctx, did, (const char**) &prgm_src, 1);

	// create a kernel for the program
	cl_kernel ck = createKernel(prgm, "generateAngles");
	
	// find optimal running values
	size_t opt = getOptimalMultiple(ck, did);
	int numWorkers = roundToMult(numSamples, (int)opt);
	
	// create host space
	cl_int arraySize = numWorkers * 3;
	size_t sz = arraySize * sizeof(float);
	float* hvals = calloc((int) arraySize, sizeof(float));
	
	// create device space
	cl_mem dvals = createBuffer(ctx, CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR, sz, hvals);
	cl_event wce = writeToBuffer(cdq, dvals, sz, hvals);
	waitForEvent(wce);
	releaseEvent(wce);

	// set the kernel's arguments
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &dvals);

	// run the kernel
	cl_event ce = startKernel(cdq, ck, numWorkers, opt);

	// wait for it to finish...
	waitForEvent(ce);
	releaseEvent(ce);

	// wait for anything else to finish...
	waitForAllEvents(cdq);

	// read back the data
	cl_event mre = readFromBuffer(cdq, dvals, sz, hvals);
	waitForEvent(mre);
	releaseEvent(mre);

	releaseCommandQueue(cdq);
	releaseContext(ctx);

	return hvals;	
}

/*int main() {
	generateAngleSamples(10, promptUserForDevice());
	exit(1);
}*/
