#include "linked_list.h"
#include <check.h>

START_TEST (test1) {
	struct linked_list* ll = ll_create();
	
	int* myVals = malloc(sizeof(int) * 1);
	myVals[0] = 4;

	fail_unless(ll_length(ll) == 0, "Length should've been 0, was: %d", ll_length(ll));

	ll_add(myVals, ll);

	myVals = malloc(sizeof(int));
	myVals[0] = 3;
	fail_unless(ll_length(ll) == 1, "Length should've been 1, was: %d", ll_length(ll));

	ll_add(myVals, ll);
	fail_unless(ll_length(ll) == 2, "Length should've been 2, was: %d", ll_length(ll));

	fail_unless(*(int*)ll_pop(ll) == 4);
	fail_unless(*(int*)ll_pop(ll) == 3);
	fail_unless(ll_pop(ll) == NULL);
} END_TEST


Suite* ll_suite() {
	Suite* s = suite_create("Linked List Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, test1);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;

	Suite *s = ll_suite();
	SRunner *sr = srunner_create (s);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
