#include "MCMini.h"

void create_initial_particles(struct opencl_runtime* r, cl_mem d_geom_description, cl_float8** particles, cl_mem* d_particles, size_t* particles_size, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/particleCreate.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(15);
		ssht_add(t, ssht_makeKVPair("%NAME%", "createInit"));
		char buff[10];
		sprintf(buff, "%f", config->push_x);
		ssht_add(t, ssht_makeKVPair("%PUSH_X%", buff));
		sprintf(buff, "%f", config->push_y);
		ssht_add(t, ssht_makeKVPair("%PUSH_Y%", buff));
		sprintf(buff, "%f", config->push_z);
		ssht_add(t, ssht_makeKVPair("%PUSH_Z%", buff));
		createRandomNumberDeviceCode(getRandomNumberGenerator(1), t);

		ck = get_kernel(r, "opencl_templates/particleCreate.clt", t);
		free_table(t);
	}
	#pragma omp critical
	{
		r->opt = getOptimalMultiple(ck, r->did);
	}
	int numParticles = roundToMult(config->num_particles, (int)r->opt);

	if (numParticles != config->num_particles) {
		printf("%d Changed particle count from %d to %d for optimization\n", omp_get_thread_num(), config->num_particles, numParticles);
		config->num_particles = numParticles;
	}
	
	// create host space for particles
	*particles_size = config->num_particles * sizeof(cl_float8);
	*particles = calloc((int)*particles_size, sizeof(cl_float8));
	
	*d_particles = createBuffer(r->ctx, CL_MEM_READ_WRITE, *particles_size, NULL);
	//writeToBuffer(r->cdq, *d_particles, *particles_size, *particles);

	int offset = config->curr_batch * config->num_particles * 2 * (1 + omp_get_thread_num());

	// set the kernel's arguments
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &d_geom_description);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) d_particles);
	setKernelArg(ck, 2, sizeof(cl_int), (void*) &offset);
	// run the kernel
	startKernel(r->cdq, ck, config->num_particles, r->opt);
}

void do_particle_trace(struct opencl_runtime* r, cl_mem data, cl_mem particles, cl_mem x_bounds, cl_mem  y_bounds, cl_mem z_bounds, cl_mem xDist, cl_mem yDist, cl_mem zDist, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/particleTrace.clt", NULL);
	if (ck == NULL) {		
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "trace"));

		ck = get_kernel(r, "opencl_templates/particleTrace.clt", t);

		free_table(t);
	}

	// set the kernel's arguments
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &data);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &particles);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &x_bounds);
	setKernelArg(ck, 3, sizeof(cl_mem), (void*) &y_bounds);
	setKernelArg(ck, 4, sizeof(cl_mem), (void*) &z_bounds);
	setKernelArg(ck, 5, sizeof(cl_mem), (void*) &xDist);
	setKernelArg(ck, 6, sizeof(cl_mem), (void*) &yDist);
	setKernelArg(ck, 7, sizeof(cl_mem), (void*) &zDist);

	
	startKernel(r->cdq, ck, config->num_particles, r->opt);
}

void find_first_last_intercept(struct opencl_runtime* r, cl_mem data, cl_mem xDist, cl_mem yDist, cl_mem zDist, cl_mem first, cl_mem last, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/particleFindFirstLast.clt", NULL);
	if (ck == NULL) {	
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "firstLast"));
	
		ck = get_kernel(r, "opencl_templates/particleFindFirstLast.clt", t);
		free_table(t);
	}

	// set the kernel's arguments
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &data);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &xDist);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &yDist);
	setKernelArg(ck, 3, sizeof(cl_mem), (void*) &zDist);
	setKernelArg(ck, 4, sizeof(cl_mem), (void*) &first);
	setKernelArg(ck, 5, sizeof(cl_mem), (void*) &last);

	startKernel(r->cdq, ck, config->num_particles, r->opt);
}

cl_event calculate_zones(struct opencl_runtime* r, cl_mem data, cl_mem first, cl_mem zones, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/calculateZones.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "calcZones"));
		ck = get_kernel(r, "opencl_templates/calculateZones.clt", t);
		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &data);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &first);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &zones);

	return startKernel(r->cdq, ck, config->num_particles, r->opt);
}

int should_continue_iteration(int* zones, struct MCMini_config* config) {
	int i;
	for (i = 0; i < config->num_particles; i++) {
		if (zones[i] != -1) return 1;
	}

	return 0;
}

void progress_counters(struct opencl_runtime* r, cl_mem d_particles, cl_mem d_data, cl_mem d_zones, cl_mem d_first, cl_mem d_xDist, cl_mem d_yDist, cl_mem d_zDist, cl_mem d_track_length, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/particleProgress.clt", NULL);	
	if (ck == NULL) {
		struct strStrHashTable *t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "progress"));

		ck = get_kernel(r, "opencl_templates/particleProgress.clt", t);

		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &d_particles);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &d_data);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &d_zones);
	setKernelArg(ck, 3, sizeof(cl_mem), (void*) &d_first);
	setKernelArg(ck, 4, sizeof(cl_mem), (void*) &d_xDist);
	setKernelArg(ck, 5, sizeof(cl_mem), (void*) &d_yDist);
	setKernelArg(ck, 6, sizeof(cl_mem), (void*) &d_zDist);
	setKernelArg(ck, 7, sizeof(cl_mem), (void*) &d_track_length);

	startKernel(r->cdq, ck, config->num_particles, r->opt);
}

void calculate_attenuation(struct opencl_runtime* r, int num_zone_intercepts, cl_mem particles, cl_mem d_length_seq, cl_mem mfp, cl_mem atten, int num_intersects) {
	cl_kernel ck = get_kernel(r, "opencl_templates/attenuate.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "attenuate"));
		ck = get_kernel(r, "opencl_templates/attenuate.clt", t);
		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_int), (void*) &num_zone_intercepts);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &particles);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &d_length_seq);
	setKernelArg(ck, 3, sizeof(cl_mem), (void*) &mfp);
	setKernelArg(ck, 4, sizeof(cl_mem), (void*) &atten);

	startKernel(r->cdq, ck, num_intersects, r->opt);
}

void calculate_mfp_seq(struct opencl_runtime* r, cl_mem d_length_seq, cl_mem d_mfp, cl_mem d_mfp_seq, int num_zone_intercepts) {
	cl_kernel ck = get_kernel(r, "opencl_templates/convertLengthToMFP.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "convertMFP"));
		ck = get_kernel(r, "opencl_templates/convertLengthToMFP.clt", t);
		free_table(t);
	}
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &d_length_seq);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &d_mfp_seq);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &d_mfp);

	startKernel(r->cdq, ck, num_zone_intercepts, r->opt);
}

void calculate_reactions(struct opencl_runtime* r, cl_mem reaction_done, cl_mem particles, cl_mem mfp, cl_mem lengths, cl_mem mfp_lengths, int num_intercepts, cl_mem zones, cl_mem reactions, cl_mem old_reactions, struct MCMini_config* config) {
	cl_kernel ck = get_kernel(r, "opencl_templates/calculateReaction.clt", NULL);
	if (ck == NULL) {	
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "findReactions"));
		ssht_add(t, ssht_makeKVPair("%RANDOM_OFFSET%", "0"));
		ssht_add(t, ssht_makeKVPair("%MAX_DAUGHTERS%", MAX_CHILDREN_PER_REACTION_S));
		createRandomNumberDeviceCode(getRandomNumberGenerator(1), t);
	
		ck = get_kernel(r, "opencl_templates/calculateReaction.clt", t);

		free_table(t);
	}

	int isNull = (old_reactions == NULL ? 1 : 0);
	cl_mem old = (isNull == 1 ? particles : old_reactions);


	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &reaction_done);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &particles);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &mfp);
	setKernelArg(ck, 3, sizeof(cl_mem), (void*) &lengths);
	setKernelArg(ck, 4, sizeof(cl_mem), (void*) &mfp_lengths);
	setKernelArg(ck, 5, sizeof(cl_int), (void*) &num_intercepts);
	setKernelArg(ck, 6, sizeof(cl_mem), (void*) &zones);
	setKernelArg(ck, 7, sizeof(cl_mem), (void*) &reactions);
	setKernelArg(ck, 8, sizeof(cl_mem), (void*) &old);
	setKernelArg(ck, 9, sizeof(cl_int), (void*) &isNull);
	

	startKernel(r->cdq, ck, config->num_particles, r->opt);
}

void calculate_scatter(struct opencl_runtime* r, cl_mem particles, cl_mem reactions, int reactions_per_particle, int num_reactions, int max_daughters) {
	cl_kernel ck = get_kernel(r, "opencl_templates/reactionScatter.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(15);
		ssht_add(t, ssht_makeKVPair("%NAME%", "scatter"));
		ssht_add(t, ssht_makeKVPair("%RANDOM_OFFSET%", "1"));
		ssht_add(t, ssht_makeKVPair("%MAX_DAUGHTERS%", MAX_CHILDREN_PER_REACTION_S));
		ssht_add(t, ssht_makeKVPair("%REACTION_ID%", "0"));
		ssht_add(t, ssht_makeKVPair("%PART_MASS%", "1.f"));
		ssht_add(t, ssht_makeKVPair("%PUSH_X%", "0.0"));
		ssht_add(t, ssht_makeKVPair("%PUSH_Y%", "0.0"));
		ssht_add(t, ssht_makeKVPair("%PUSH_Z%", "0.0"));

		createRandomNumberDeviceCode(getRandomNumberGenerator(1), t);
		ck = get_kernel(r, "opencl_templates/reactionScatter.clt", t);

		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &particles);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &reactions);
	setKernelArg(ck, 2, sizeof(cl_int), (void*) &reactions_per_particle);

	startKernel(r->cdq, ck, num_reactions/max_daughters, r->opt);
}

void calculate_absorb(struct opencl_runtime* r, cl_mem reactions, cl_mem energy_dep, int num_reactions, int max_daughters) {
	cl_kernel ck = get_kernel(r, "opencl_templates/reactionAbsorb.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(10);
		ssht_add(t, ssht_makeKVPair("%NAME%", "absorb"));
		ssht_add(t, ssht_makeKVPair("%REACTION_ID%", "1"));
		ssht_add(t, ssht_makeKVPair("%MAX_DAUGHTERS%", MAX_CHILDREN_PER_REACTION_S));
		
		ck = get_kernel(r, "opencl_templates/reactionAbsorb.clt", t);
		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &reactions);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &energy_dep);

	startKernel(r->cdq, ck, num_reactions/max_daughters, r->opt);
} 

void calculate_fission(struct opencl_runtime* r, cl_mem particles, cl_mem reactions, int reactions_per_particle, int num_reactions, int max_daughters) {
	cl_kernel ck = get_kernel(r, "opencl_templates/reactionFission.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(20);
		ssht_add(t, ssht_makeKVPair("%NAME%", "fission"));
		ssht_add(t, ssht_makeKVPair("%RANDOM_OFFSET%", "1"));
		ssht_add(t, ssht_makeKVPair("%MAX_DAUGHTERS%", MAX_CHILDREN_PER_REACTION_S));
		ssht_add(t, ssht_makeKVPair("%REACTION_ID%", "2"));
		ssht_add(t, ssht_makeKVPair("%PART_MASS%", "1.f"));
		ssht_add(t, ssht_makeKVPair("%NUBAR%", "2"));
		ssht_add(t, ssht_makeKVPair("%PUSH_X%", "0.0"));
		ssht_add(t, ssht_makeKVPair("%PUSH_Y%", "0.0"));
		ssht_add(t, ssht_makeKVPair("%PUSH_Z%", "0.0"));

		createRandomNumberDeviceCode(getRandomNumberGenerator(1), t);
		ck = get_kernel(r, "opencl_templates/reactionFission.clt", t);

		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &particles);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) &reactions);
	setKernelArg(ck, 2, sizeof(cl_int), (void*) &reactions_per_particle);

	startKernel(r->cdq, ck, num_reactions/max_daughters, r->opt);

}

 
void calculate_total_reactions(struct opencl_runtime* r, cl_mem reactions, int num_reactions, cl_mem count, cl_mem below_cutoff, char* weight_cutoff) {
	cl_kernel ck = get_kernel(r, "opencl_templates/totalReactions.clt", NULL);
	if (ck == NULL) {
		struct strStrHashTable* t = ssht_create(5);
		ssht_add(t, ssht_makeKVPair("%NAME%", "totalReact"));
		ssht_add(t, ssht_makeKVPair("%WEIGHT_CUTOFF%", weight_cutoff));
		
		ck = get_kernel(r, "opencl_templates/totalReactions.clt", t);

		free_table(t);
	}

	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &count);
	setKernelArg(ck, 1, sizeof(cl_mem), (void*) & below_cutoff);
	setKernelArg(ck, 2, sizeof(cl_mem), (void*) &reactions);

	startKernel(r->cdq, ck, num_reactions, r->opt);
}


int make_zone_data_seq(struct linked_list* zones, struct MCMini_config* config, int** seq_zones, size_t* size) {
	struct linked_list* use_zones = ll_clone(zones);

	int use_zones_length = ll_length(use_zones);
	int num_zones = use_zones_length * config->num_particles;
	*size = sizeof(int) * num_zones;
	int* toReturn  = malloc(*size);
	

	int* curr;
	int i, idx;

	int currStep = 0;
	int num_pops = 0;
	while ((curr = ll_pop(use_zones)) != NULL) {
		for (i=0; i < config->num_particles; i++) {
			currStep = (num_pops * config->num_particles) + i;
			idx = ((currStep % config->num_particles) * use_zones_length) + (currStep / config->num_particles);
			toReturn[idx] = curr[i];
		}
		num_pops++;
	}

	free(use_zones);

	*seq_zones = toReturn;
	return num_zones;
}

int make_zone_length_data_seq(struct linked_list* zones, struct MCMini_config* config, float** seq_lengths) {
	struct linked_list* use_zones = ll_clone(zones);

	int use_zones_length = ll_length(use_zones);
	int num_zones = use_zones_length * config->num_particles;
	float* toReturn  = malloc(sizeof(float) * num_zones);
	

	float* curr;
	float* last = NULL;
	int i, idx;

	int currStep = 0;
	while ((curr = ll_pop(use_zones)) != NULL) {
		for (i=0; i < config->num_particles; i++) {
			// find segment length (reverse cumulative sum) as well
			idx = ((currStep % config->num_particles) * use_zones_length) + (currStep / config->num_particles);			
			toReturn[idx] = curr[i] - (last != NULL ? last[i] : 0.0f);
			currStep++;
		}
		last = curr;
	}

	free(use_zones);

	*seq_lengths = toReturn;
	return num_zones;
}

int make_reaction_data(struct linked_list* zones, struct MCMini_config* config, size_t* size, cl_float8** reactions, int max_children_per_reaction) {
	int i, j, num_pops, mat_id;	
	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);
	struct linked_list* use_ll = ll_clone(zones);
	*size = sizeof(cl_float8) * ll_length(zones) * config->num_particles * max_children_per_reaction;
	*reactions = (cl_float8*) malloc(*size);

	
	
	j = 0;
	num_pops = 0;

	cl_float8* currBatch;
	while ((currBatch = ll_pop(use_ll)) != NULL) {
		for (i=0; i < config->num_particles*max_children_per_reaction; i++) {
			// reaction zones are stored in s3, and will be replaced with a reaction ID
			// the zone will be stored in s5
			// store the zone weight in s4
			j = (num_pops * config->num_particles * max_children_per_reaction) + i;

			(*reactions)[j] = currBatch[i];
			if ((int)(*reactions)[j].s3 != -1) {
				mat_id = pick_material_for_zone((*reactions)[j].s3, config, rnc);
				(*reactions)[j].s5 = (*reactions)[j].s3;
				(*reactions)[j].s3 = (float)pick_reaction_for_material(mat_id);
				(*reactions)[j].s4 = (float)config->material_weights[mat_id];
			} else {
				(*reactions)[j].s5 = -1.f;
				(*reactions)[j].s3 = -1.f;
				(*reactions)[j].s4 = -1.f;
			}
			//printf("%d -> %d\n", (int)currBatch[i].s3, (int)(*reactions)[j].s3);
		}
		num_pops++;	
	}

	free(use_ll);
	return num_pops * config->num_particles * max_children_per_reaction;
}

void output_zone_history(FILE* output, struct linked_list* ll, struct MCMini_config* config) {
	int i;
	int* currBatch;
	struct linked_list* use_ll = ll_clone(ll);

	fprintf(output, "*** ZONE HISTORY ***\n");
	while ((currBatch = ll_pop(use_ll)) != NULL) {
		for (i = 0; i < config->num_particles; i++) {
			fprintf(output, "%d\t", currBatch[i]);
		}
		fprintf(output, "\n");
	}

	//int max = make_zone_data_seq(ll, config, &currBatch);
	//for (i=0; i < max; i++) printf("%d\n", currBatch[i]);

	free(use_ll);
}


void output_zone_tally(FILE* output, struct linked_list* ll, struct MCMini_config* config) {
	int i;
	int num_zones = (int)*config->num_x_bounds * (int)*config->num_y_bounds * (int)*config->num_z_bounds;
	int* zone_tally = calloc(num_zones, sizeof(int));
	int* currBatch;
	struct linked_list* use_ll = ll_clone(ll);

	while ((currBatch = ll_pop(use_ll)) != NULL) {
		for (i = 0; i < config->num_particles; i++) {
			if (currBatch[i] == -1) continue;
			zone_tally[currBatch[i]]++;
		}
	}

	fprintf(output, "*** ZONE TALLY ***\n");
	for (i = 0; i < num_zones; i++) {
		fprintf(output, "%d: %d\n", i, zone_tally[i]);
	}
	free(use_ll);
}

void output_particle_track_lengths(FILE* output, struct linked_list* ll, struct MCMini_config* config) {
	struct linked_list* use_ll = ll_clone(ll);
	float* curr;
	int i;
	
	fprintf(output, "*** TRACK LENGTHS ***\n");
	while ((curr = (float*)ll_pop(use_ll)) != NULL) {
		for (i=0; i < config->num_particles; i++) fprintf(output, "%.2f\t", curr[i]);
		fprintf(output, "\n");
	}


	free(use_ll);

	
}

