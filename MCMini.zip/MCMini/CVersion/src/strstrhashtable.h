#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string.h>
#include <stdlib.h>

#include <stdio.h>
struct strStrHashTable {
	unsigned int capacity;
	struct keyVal** table;
};

struct keyVal {
	char* key;
	void* val;
};

/**
Creates a new key value pair given the passed parameters that can be added to a hash table (for string values)
*/
struct keyVal* ssht_makeKVPair(char* key, char* val);


/**
Creates a new key value pair given the passed parameters that can be added to a hash table (for all values)
*/
struct keyVal* ssht_makeKVPairGeneric(char* key, void* val);

/**
Creates a new hash table with the given capacity
*/
struct strStrHashTable* ssht_create(unsigned int initCapacity);

/**
Adds a value to the hash table. Returns true or false depending on result.
*/
int ssht_add(struct strStrHashTable* table, struct keyVal* kv);

/**
Looks up a key in the hash table. Returns the key/value pair if it is found, NULL otherwise
*/
struct keyVal* ssht_lookup(struct strStrHashTable* table, char* key);

#ifdef HASHTABLE_STATS
void ssht_print_stats();
#endif

/**
Frees a hashtable
*/
void free_table(struct strStrHashTable* table);

#endif
