#ifndef CODE_TEMPLATE_H
#define CODE_TEMPLATE_H

#include "strstrhashtable.h"

/**
Reads in a file stored at templateName and replaces any variables with those found in the
hash table vars. Variables must be surronded by % in both the hash table and the file.

For example, test.txt:
this is a %VAR1% of the system

Would require a hash table mapping %VAR1% to a given string, such as "test."

The modified string will be returned, or NULL if there is an error.
*/
char* readTemplate(char* templateName, struct strStrHashTable* vars);


#endif
