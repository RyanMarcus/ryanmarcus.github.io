f = open("transport.c", "r")

varList = []

for l in f:
	l = l.strip()
	if l[:6] == "struct" : l = l[7:]
	if l.count("{") == 1: break
	if l.count(" ") == 1 and l.count(";") == 1:
		if l.count("(") == 0:
			varList.append(l.split(" ")[1][:-1])

varList.sort()
print ", ".join(varList)	
