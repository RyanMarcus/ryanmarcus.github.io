#include "materials.h"

float mfp_scat(float density, float energy, float temperature) {
	// (2 / 1) = (p / m) -> 2m = p -> p/2 = m
	return density / 2.0f;
}

float mfp_absor(float density, float energy, float temperature) {
	float tao = (1.0f/0.6022f) * sqrtf(1.0f / energy);
	float mfp = ((tao * 7.0f) / 70.0f) * 6.022;
	return 1.0f/mfp;
}

float mfp_fiss(float density, float energy, float temperature) {	
	float tao = (10.0f/0.6022f) * sqrtf(energy);
	float mfp = ((tao * 20.0f) / 200.0f) * .6022;
	return 1.0f/mfp;
}

float mfp(struct MCMini_config* c, struct alias_list* ac, float density, float energy, float temperature) {
	if (ac == NULL) return -1.f;
	float toReturn = 0.f;

	int i, mat_id;
	for (i=0; i < ac->count; i++) {
		mat_id = ac->values[i];
		if (c->mat_map != NULL) mat_id = c->mat_map[mat_id];
		switch (mat_id) {
			case -1: return -1.f; break;
			case 0: toReturn += ac->weights[i] * mfp_scat(density, energy, temperature); break;
			case 1: toReturn += ac->weights[i] * mfp_absor(density, energy, temperature); break;
			case 2: toReturn += ac->weights[i] * mfp_fiss(density, energy, temperature); break;
			default: fprintf(stderr, "Unknown material ID: %d\n", mat_id); break;
		}
	}
	
	return toReturn;
}

int pick_material_for_zone(int zone_id, struct MCMini_config* c, struct RandomNumberConfiguration* rnc) {
	return sample_from_alias_list(c->zone_material[zone_id], h_rand(rnc), h_rand(rnc));
}

int pick_reaction_for_material(int mat_id) {
	return mat_id;
}

int index_to_zone(struct MCMini_config* c, int x, int y, int z) {
	return ((z + 1) + ( ((int) *(c->num_z_bounds)) * (y + ((int)*(c->num_y_bounds)) * x))) - 1;
} 
