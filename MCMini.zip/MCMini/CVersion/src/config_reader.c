#include "config_reader.h"

struct strStrHashTable* read_config(char* filename) {
	FILE *fp;
	char* line = NULL;
	size_t len = 0;
	int readSize = 0;

	fp = fopen(filename, "r");
	if (fp == NULL) return NULL;

	struct strStrHashTable* t = ssht_create(MAX_PARAMS);

	char* buff1 = calloc(1024, sizeof(char));
	char* buff2 = calloc(1024, sizeof(char));

	int pos;
	while ((readSize = getline(&line, &len, fp)) != -1) {
		if (readSize <= 1) continue;
		if (line[0] == '#') continue;
		pos = find_char_in_string(line, '=');
		if (pos == -1) continue;

		if (strncpy(buff1, line, pos) == NULL) return NULL; // should never be NULL
		buff1[pos+1] = (char)0;
		
		if (strncpy(buff2, line + pos + 1, (readSize - pos) - 2) == NULL) return NULL; // should never be NULL
		buff2[(readSize - pos) + 1] = (char) 0;

		if (ssht_add(t, ssht_makeKVPair(buff1, buff2)) == 0) return NULL;
		
		// clear the buffers
		memset(buff1, 0, sizeof(char) * 1024);
		memset(buff2, 0, sizeof(char) * 1024);
	}

	free(buff1);
	free(buff2);
	free(line);
	fclose(fp);

	return t;
}

int find_char_in_string(char* haystack, char needle) {
	if (haystack == NULL) return -1;

	int i;
	for (i = 0; i < strlen(haystack); i++) {
		if (haystack[i] == needle) return i;
	}

	return -1;
}
