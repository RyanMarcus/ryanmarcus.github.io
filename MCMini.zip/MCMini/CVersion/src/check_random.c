#include <stdlib.h>
#include <stdio.h>
#include <check.h>
#include "random.h"
#include <math.h>
#include "opencl.h"
#include "contextFactory.h"

#define CHECK_NUM 100

cl_device_id did;


START_TEST (h_bounds_check) {
	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);
	int i = 0;
	float f = 0.0;
	for (i = 0; i <= CHECK_NUM; i++) {
		f = h_rand(rnc);
		fail_if( (f <= 0.0 || f >= 1.0), "Bounds check failed: (%ldth) %f", rnc->position, f);
	}
	
	free(rnc);
} END_TEST

START_TEST (h_chi_sqrd) {
	int bins[10];

	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);

	int i;
	for (i = 0; i < 10; i++) bins[i] = 0;

	for (i = 0; i <= CHECK_NUM; i++) {
		bins[(int)(h_rand(rnc) * 10.0)]++;
	}

	float p = 0.0;
	float expectedValue = (float)CHECK_NUM / 10.0;

	for (i = 0; i < 10; i++) {
		p += powf((float)bins[i] - expectedValue, 2) / expectedValue;
	}

	fail_if( (p > 16.29 || p < 3.325), "Not within 90%% confidence: %f\n[%d, %d, %d, %d, %d, %d, %d, %d, %d, %d]\n", p, bins[0], bins[1], bins[2], bins[3], bins[4], bins[5], bins[6], bins[7], bins[8], bins[9]);

	free(rnc);

} END_TEST

/*START_TEST (device_host_match) {
	float* nums = generateRandomSamples(CHECK_NUM, did);
	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);
	int i;
	float val;
	for (i=0; i < CHECK_NUM; i++) {
		val = h_rand(rnc);
		fail_if(nums[i] != val, "Host did not match device: r[%d]: h(%f) d(%f)", i, val, nums[i]);
	}
} END_TEST*/

/*START_TEST (h_mcnp_match) {
	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(MCNP_MAIN_GENERATOR);
	int i = 0;

	// check the inital seed
	fail_if(rnc->current != 19073486328125);
	long realVals[9] = { 29763723208841, 187205367447973, 131230026111313, 264374031214925,
				260251000190209, 106001385730621, 232883458246025, 97934850615973,
				163056893025873 };

	for (i = 0; i < 9; i++) {
		long val = h_rand_nonorm(rnc);
		fail_unless( (val == realVals[i]), "Did not match on %d: %ld %ld", i, val, realVals[i]);
	}
} END_TEST
*/
Suite* random_suite() {
	Suite* s = suite_create("Random Number Generator Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, h_bounds_check);
	tcase_add_test (tc_core, h_chi_sqrd);
	//tcase_add_test (tc_core, device_host_match);
	//tcase_add_test (tc_core, h_mcnp_match);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;
	did = getArbitraryDevice();

	Suite *s = random_suite();
	SRunner *sr = srunner_create (s);
	#ifdef AMDAPP // doesn't like forking
		srunner_set_fork_status (sr, CK_NOFORK);
	#endif 
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
