#include "MCMini_config_read.h"

float* parse_bounds(char* bounds);
int parse_dids(char* dids, int* sto);

int idx_to_zone(struct MCMini_config* c, int x, int y, int z) {
	return ((z + 1) + ( ((int) *(c->num_z_bounds)) * (y + ((int)*(c->num_y_bounds)) * x))) - 1;
}

#define ERROR_EXIT { free(toReturn); free_table(t); return NULL; }
struct MCMini_config* read_MCMini_config(char* file) {
	struct keyVal* kv;
	struct MCMini_config* toReturn;
	struct strStrHashTable* t = read_config(file);
	float* parse_result;
	int i;

	toReturn = (struct MCMini_config*) malloc(sizeof(struct MCMini_config));

	if (t == NULL) {
		fprintf(stderr, "Could not read config file\n");
		ERROR_EXIT
	}

	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_DID)) != NULL) {
		toReturn->num_devices = 1;
		toReturn->device_ids = malloc(sizeof(int));
		toReturn->device_ids[0] = atoi(kv->val); 
	} else {
		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_DIDS)) != NULL) {
			toReturn->device_ids = malloc(100 * sizeof(int));
			toReturn->num_devices = parse_dids(kv->val, toReturn->device_ids); 
		} else {
			fprintf(stderr, "No device ID specificed, you will be prompted\n"); 
			toReturn->num_devices = 1;
			toReturn->device_ids = malloc(sizeof(int));
			toReturn->device_ids[0] = -1; 
		}
	}


	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_NUM_PARTICLES)) != NULL) {
		toReturn->num_particles = atoi(kv->val);
		toReturn->orig_num_particles = atoi(kv->val); 
	} else {
		fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_NUM_PARTICLES\n");
		ERROR_EXIT
	}

	toReturn->num_batches = 1;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_NUM_BATCHES)) != NULL ) {
		toReturn->num_batches = atoi(kv->val);
	}

	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_SOURCE_X)) != NULL) {
		toReturn->source_x = atof(kv->val); 
	} else {
		fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_SOURCE_X\n");
		ERROR_EXIT
	}

	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_SOURCE_Y)) != NULL) {
		toReturn->source_y = atof(kv->val); 
	} else {
		fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_SOURCE_Y\n");
		ERROR_EXIT
	}

	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_SOURCE_Z)) != NULL) {
		toReturn->source_z = atof(kv->val); 
	} else {
		fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_SOURCE_Z\n");
		ERROR_EXIT
	}

	toReturn->push_x = 0.f;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_PUSH_X)) != NULL) {
		toReturn->push_x = atof(kv->val);
	}

	toReturn->push_y = 0.f;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_PUSH_Y)) != NULL) {
		toReturn->push_y = atof(kv->val);
	}

	toReturn->push_z= 0.f;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_PUSH_Z)) != NULL) {
		toReturn->push_z = atof(kv->val);
	}

	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_LNK3DNT)) != NULL) {
		read_lnk3dnt(fopen(kv->val, "r"), toReturn);
		toReturn->mat_map = malloc(sizeof(int) * toReturn->num_materials);
		char buff[10];
		for (i=0; i < toReturn->num_materials; i++) {
			sprintf(buff, "mat%d", i);
			if ((kv = ssht_lookup(t, buff)) != NULL) {
				toReturn->mat_map[i] = atoi(kv->val);
			} else {
				fprintf(stderr, "No definition for LNK3DNT material %d\n", i);
				ERROR_EXIT				
			}
		}


	} else {
		toReturn->mat_map = NULL;
		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_X_BOUNDS)) != NULL) {
			parse_result = parse_bounds(kv->val);
			if (parse_result == NULL) {
				fprintf(stderr, "Invalid MCMINI_CONFIG_X_BOUNDS field\n");
				ERROR_EXIT
			}
			toReturn->num_x_bounds = parse_result;
			toReturn->x_bounds = parse_result + 1;
		} else {
			fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_X_BOUNDS\n");
			ERROR_EXIT
		}

		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_Y_BOUNDS)) != NULL) {
			parse_result = parse_bounds(kv->val);
			if (parse_result == NULL) {
				fprintf(stderr, "Invalid MCMINI_CONFIG_Y_BOUNDS field\n");
				ERROR_EXIT
			}
			toReturn->num_y_bounds = parse_result;
			toReturn->y_bounds = parse_result + 1;
		} else {
			fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_Y_BOUNDS\n");
			ERROR_EXIT
		}

		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_Z_BOUNDS)) != NULL) {
			parse_result = parse_bounds(kv->val);
			if (parse_result == NULL) {
				fprintf(stderr, "Invalid MCMINI_CONFIG_Z_BOUNDS field\n");
				ERROR_EXIT
			}
			toReturn->num_z_bounds = parse_result;
			toReturn->z_bounds = parse_result + 1;
		} else {
			fprintf(stderr, "Config file did not define MCMINI_CONFIG_KEY_Z_BOUNDS\n");
			ERROR_EXIT
		}



		int def_mat = -1;
		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_DEFAULT_MATERIAL)) != NULL) {
			def_mat = atoi(kv->val);
		}

		char buff[10]; // no more than 10^10 zones (0 to (10^10)-1)
		int num_bounds = (int)(*toReturn->num_x_bounds * *toReturn->num_y_bounds * *toReturn->num_z_bounds);
		toReturn->zone_material = calloc(num_bounds, sizeof(struct alias_list*));
		int values[1] = {0};
		float weights[1] = {1.0f};
		#pragma omp parallel for
		for (i=0; i < num_bounds; i++) {
			sprintf(buff, "mat%d", i);
			if ((kv = ssht_lookup(t, buff)) != NULL) {
				values[0] = atoi(kv->val);
			} else {
				values[0] = def_mat;
			}
			toReturn->zone_material[i] = generate_alias_list(1, values, weights);
		}

	}

	toReturn->zone_tally = 0;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_ZONE_TALLY)) != NULL) {
		if (strcmp(kv->val, MCMINI_CONFIG_TRUE) == 0) {
			toReturn->zone_tally = 1;
		}
	}

	toReturn->particle_track_length = 0;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_PARTICLE_TRACK_LENGTH)) != NULL) {
		if (strcmp(kv->val, MCMINI_CONFIG_TRUE) == 0) {
			toReturn->particle_track_length = 1;
		}
	}


	toReturn->zone_history = 0;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_ZONE_HISTORY)) != NULL) {
		if (strcmp(kv->val, MCMINI_CONFIG_TRUE) == 0) {
			toReturn->zone_history = 1;
		}
	}

	toReturn->flux_tally = 0;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_FLUX_TALLY)) != NULL) {
		if (strcmp(kv->val, MCMINI_CONFIG_TRUE) == 0) {
			toReturn->flux_tally = 1;
		}
	}

	toReturn->image_axis = -1;
	if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_IMAGE_AXIS)) != NULL) {
		toReturn->image_axis = atoi(kv->val);
		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_IMAGE_PLANE)) != NULL) {
			toReturn->image_plane = atoi(kv->val);
		} else {
			fprintf(stderr, "Could not find image plane in config file\n");
			ERROR_EXIT
		}

		if ((kv = ssht_lookup(t, MCMINI_CONFIG_KEY_IMAGE_TYPE)) != NULL) {
			if (strcmp(kv->val, MCMINI_CONFIG_VALUE_IMAGE_TYPE_ZONE) == 0) {
				toReturn->image_type = IMAGE_TYPE_ZONE;
			} else if (strcmp(kv->val, MCMINI_CONFIG_VALUE_IMAGE_TYPE_FLUX) == 0) {
				toReturn->image_type = IMAGE_TYPE_FLUX;
			} else {
				fprintf(stderr, "Invalid image type\n");
				ERROR_EXIT;
			}	
		} else {
			fprintf(stderr, "You did not specify an image type\n");
			ERROR_EXIT;
		}
	}
 
	#ifdef PRINT_CONFIG
		printf("MCMini config file:\n");
		printf("\tNum bounds (x,y,z): %d, %d, %d\n", (int)*toReturn->num_x_bounds, (int)*toReturn->num_y_bounds, (int)*toReturn->num_z_bounds);

		int j, k, l;
		for (i = 0; i < (int)*toReturn->num_x_bounds; i++) {
			for (j = 0; j < (int)*toReturn->num_y_bounds; j++) {
				for (k = 0; k < (int)*toReturn->num_z_bounds; k++) {
					printf("\t%d %d %d: ", i, j, k);
					if (toReturn->zone_material[index_to_zone(toReturn, i, j, k)] == NULL) {
						printf("NULL\n");
						continue;
					}
					for (l = 0; l < toReturn->zone_material[index_to_zone(toReturn, i, j, k)]->count; l++) {
						printf("%d ", toReturn->zone_material[index_to_zone(toReturn, i, j, k)]->values[l]);
					}

					printf("(");
					for (l = 0; l < toReturn->zone_material[index_to_zone(toReturn, i, j, k)]->count; l++) {
						printf("%f ", toReturn->zone_material[index_to_zone(toReturn, i, j, k)]->weights[l]);
					}
					printf(")\n");
				}
			}
		}
		exit(1);
	#endif 

	toReturn->material_weights = malloc(sizeof(float) * 3);
	toReturn->material_weights[0] = 2.f;
	toReturn->material_weights[1] = 70.f;
	toReturn->material_weights[2] = 200.f;

	return toReturn;

	
}

// parses a bounds string and returns the bounds list, the 1st element of which is the number of bounds
float* parse_bounds(char* bounds) {
	int i;
	float min, max;
	float* toReturn;
	char* stop;
	if (bounds == NULL) return NULL;
	if (bounds[0] == 'r') {
		// it is a range, ex: r0,100
		min = (float)strtol(bounds + 1, &stop, 10);
		max = (float)strtol(stop + 1, NULL, 10);
		
		if (max <= min) return NULL;

		toReturn = (float*) malloc(sizeof(float) * (1 + (max - min)));
		toReturn[0] = max - min;
		for (i = 1; i < (max - min) + 1; i++) toReturn[i] = min + ((float)i - 1);
		return toReturn;
	}

	return NULL;
}


// TODO function is unsafe
// parse a list of comma-seperated integers
int parse_dids(char* dids, int* sto) {
	int i = 0;
	char* c = dids;

	while (c - dids < strlen(dids)) {
		sto[i] = atoi(c);
		i++;
		while (*c != ',' && c - dids < strlen(dids)) {
			c++;
		}
		c++;
	}

	return i;
}

void write_geom_data(struct MCMini_config* c, FILE* f) {
	fprintf(f, "%d, %d, %d\n", (int)*c->num_x_bounds, (int)*c->num_y_bounds, (int)*c->num_z_bounds);
}
