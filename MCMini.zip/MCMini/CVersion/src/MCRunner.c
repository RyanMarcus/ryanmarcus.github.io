#include "opencl.h"
#include "jit.h"
#include "transport.h"
#include "contextFactory.h"
#include "tally.h"
#include <string.h>
#include <omp.h>
#ifdef HASHTABLE_STATS
#include "strstrhashtable.h"
#endif

void add_to_linked_list(void* array, size_t array_size, struct linked_list* ll);


int main(int argc, char** argv) {
	output = stdout;

	if (argc != 2) {
		printf("Usage: %s CONFIG\n", argv[0]);
		listDevices();
		exit(1);
	}
	
	
	status_print("Reading config file...\n");
	// read in the config file
	struct MCMini_config* confg = read_MCMini_config(argv[1]);
	if (confg == NULL) exit(1); // invalid config file
	
	// create a tally to store flux over the whole run
	status_print("Setting up shared tallies...\n");
	struct run_tallies* rt = malloc(sizeof(struct run_tallies));

	rt->flux = create_zone_tally(NUM_ZONES(confg), TALLY_ID_FLUX);
	rt->zone = create_zone_tally(NUM_ZONES(confg), TALLY_ID_ZONE);

	omp_set_num_threads(confg->num_devices);

	#ifdef MPI
		int rank = 0;
		MPI_Init(&argc, &argv);
		MPI_Comm_rank (MPI_COMM_WORLD, &rank);
		if (rank == 0) {
			// we need to be the master and rec'v data from all of the slaves
		} else {
			// we're a slave and we need to send information to the master
	#endif

	#pragma omp parallel shared(rt)
	{
		status_print("Setting up OpenCL...\n");
		struct opencl_runtime* r;

		// make a (thread) local copy of the config, because copyin doesn't do what we thought it did
		struct MCMini_config* config = malloc(sizeof(struct MCMini_config));
		memcpy(config, confg, sizeof(struct MCMini_config));

		#pragma omp critical
		{
			// set up OpenCL, which sets did, ctx, and cdq
			r = setup_opencl(config);
			#ifdef STATUS_PRINT
				printDeviceInfo(r->did);
			#endif
		}
		init_jit();

		do_transport(rt, r, config);

		#pragma omp barrier
		#pragma omp master
		{
		printf("All devices finished calculation.\n");
		}

	}

	#ifdef MPI
	} // ending if statement from above
	#endif

	#ifdef HASHTABLE_STATS
		ssht_print_stats();
	#endif
	#ifdef PROFILE
		printProfileInfo();
	#endif
	exit(0);
}


