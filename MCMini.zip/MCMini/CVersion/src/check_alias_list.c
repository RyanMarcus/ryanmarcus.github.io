#include <stdlib.h>
#include <stdio.h>
#include <check.h>
#include "random.h"
#include "alias_selection.h"

#define CHECK_NUM 1000

START_TEST (test1) {
	int vals[] = {1, 2, 3};
	float weights[] = {0.5f, 0.25f, 0.25f};
	struct alias_list* al = generate_alias_list(3, vals, weights);

	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);
	
	int i;
	int have_1 = 0;
	int have_2 = 0;
	int have_3 = 0;
	for (i=0; i < 100; i++) {
		int j = sample_from_alias_list(al, h_rand(rnc), h_rand(rnc));
		have_1 = (j == 1 ? 1 : have_1);
		have_2 = (j == 2 ? 1 : have_1);
		have_3 = (j == 3 ? 1 : have_1);
	}

	fail_unless(have_1 + have_2 + have_3 == 3);	
} END_TEST

START_TEST (test2) {
	int bins[10];

	int vals[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	float weights[] = {0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f}; 
	struct alias_list* al = generate_alias_list(10, vals, weights);

	struct RandomNumberConfiguration* rnc = getRandomNumberGenerator(1);

	int i;
	for (i = 0; i < 10; i++) bins[i] = 0;

	for (i = 0; i <= CHECK_NUM; i++) {
		bins[(int)sample_from_alias_list(al, h_rand(rnc), h_rand(rnc))]++;
	}

	float p = 0.0;
	float expectedValue = (float)CHECK_NUM / 10.0;

	for (i = 0; i < 10; i++) {
		p += powf((float)bins[i] - expectedValue, 2) / expectedValue;
	}

	fail_if( (p > 16.29 || p < 3.325), "Not within 90%% confidence: %f\n[%d, %d, %d, %d, %d, %d, %d, %d, %d, %d]\n", p, bins[0], bins[1], bins[2], bins[3], bins[4], bins[5], bins[6], bins[7], bins[8], bins[9]);

	free(rnc);

} END_TEST

Suite* alias_suite() {
	Suite* s = suite_create("Alias List Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, test1);
	tcase_add_test (tc_core, test2);
	//tcase_add_test (tc_core, h_mcnp_match);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;

	Suite *s = alias_suite();
	SRunner *sr = srunner_create (s);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
