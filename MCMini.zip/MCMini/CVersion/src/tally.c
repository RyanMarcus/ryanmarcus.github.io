#include "tally.h"

struct zone_tally* create_zone_tally(int num_zones, int tally_id) {
	struct zone_tally* toReturn = malloc(sizeof(struct zone_tally));
	toReturn->tally = calloc(num_zones, sizeof(float));
	toReturn->tally_id = tally_id;
	return toReturn;
}

void add_to_tally(struct zone_tally* zt, int num_zones, int* zone_indexes, float* values) {
	int i;
	#ifdef MPI
		// instead of recording data in a tally, we need to send it to the master
			
	#endif

	#pragma omp critical
	{
		for (i=0; i < num_zones; i++) {
			if(zone_indexes[i] == -1) continue;
			zt->tally[zone_indexes[i]] += values[i];
		}
	}
}


void add_to_tally_inc(struct zone_tally* zt, int num_zones, int* zone_indexes) {
	int i;
	#pragma omp critical
	{
		for (i=0; i < num_zones; i++) {
			if(zone_indexes[i] == -1) continue;
			zt->tally[zone_indexes[i]] += 1.f;
		}
	}
	
}

float get_value_for_zone(struct zone_tally* zt, int zone_index) {
	return zt->tally[zone_index];
}
