# for single-device tests
PARTICLES="500
1000
2000
4000
6000
8000"

HALF_PARTICLES="250
500
1000
2000
3000
4000"

for part in $PARTICLES
do
    sed s/DEVICE/1/g single_cone_template.txt | sed s/PART/$part/g > testConeGPU$part.txt
    #sed s/DEVICE/4/g single_cone_template.txt | sed s/PART/$part/g > testConeCPU$part.txt
done

for part in $HALF_PARTICLES
do
    sed s/DEVICE/1,2/g single_cone_template.txt | sed s/PART/$part/g > testConeTwoGPU$part.txt
done


for part in $PARTICLES
do
    sed s/DEVICE/1,2/g single_cone_template.txt | sed s/PART/$part/g > testConeTwoGPU$part.txt
done
