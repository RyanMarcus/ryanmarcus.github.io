#include <check.h>
#include "config_reader.h"
#include "MCMini_config_read.h"
#include <stdlib.h>

START_TEST (test1) {
	struct strStrHashTable* t = read_config("config_reader_tests/test1.txt");
	fail_if(t == NULL);
	
	fail_unless(strcmp(ssht_lookup(t, "some_variable")->val, "test") == 0);
	fail_unless(strcmp(ssht_lookup(t, "other")->val, "this#included") == 0);
	fail_unless(strcmp(ssht_lookup(t, "this")->val, "is a really really really long string") == 0);

} END_TEST

START_TEST (test2) {
	struct MCMini_config* c = read_MCMini_config("config_reader_tests/test2.txt");
	fail_unless(c->num_particles == 10);

	fail_unless(c->source_x == 50.0f);
	fail_unless(c->source_y == 50.0f);
	fail_unless(c->source_z == 50.0f);

	fail_unless(*c->num_x_bounds == 100.0f);
	fail_unless(*c->num_y_bounds == 100.0f);
	fail_unless(*c->num_z_bounds == 100.0f);

	int i;
	for (i = 0; i < *c->num_x_bounds; i++) {
		fail_unless(c->x_bounds[i] == (float)i, "X[%d] was %f\n", i, c->x_bounds[i]);
		fail_unless(c->y_bounds[i] == (float)i, "Y[%d] was %f\n", i, c->y_bounds[i]);
		fail_unless(c->z_bounds[i] == (float)i, "Z[%d] was %f\n", i, c->z_bounds[i]);
	}

} END_TEST

START_TEST (test3) {
	struct MCMini_config* c = read_MCMini_config("config_reader_tests/test3.txt");
	fail_unless(c == NULL);
} END_TEST


Suite* config_suite() {
	Suite* s = suite_create("Config Reader Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, test1);
	tcase_add_test (tc_core, test2);
	tcase_add_test (tc_core, test3);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;

	Suite *s = config_suite();
	SRunner *sr = srunner_create (s);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

