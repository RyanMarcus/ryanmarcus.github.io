#include <check.h>
#include <stdlib.h>
#include "strstrhashtable.h"

char* itoa(int val, int base);

START_TEST (create_table) {
	struct strStrHashTable* t = ssht_create(5);
	fail_unless(ssht_add(t, ssht_makeKVPair("This", "this")));
	fail_unless(ssht_add(t, ssht_makeKVPair("That", "that")));
} END_TEST

START_TEST (small_check) {
	struct strStrHashTable* t = ssht_create(5);
	fail_unless(ssht_lookup(t, "not in the table") == NULL);
	fail_unless(ssht_add(t, ssht_makeKVPair("This", "this")));
	fail_unless(ssht_add(t, ssht_makeKVPair("That", "that")));

	fail_if(ssht_lookup(t, "This") == NULL);
	fail_if(ssht_lookup(t, "That") == NULL);

	fail_unless(strcmp(ssht_lookup(t, "This")->val, "this") == 0);
	fail_unless(strcmp(ssht_lookup(t, "That")->val, "that") == 0);
	
	fail_unless(ssht_add(t, ssht_makeKVPair("The other", "this")));
	fail_unless(ssht_add(t, ssht_makeKVPair("That one", "this")));
	fail_unless(ssht_add(t, ssht_makeKVPair("But me too", "this")));
	fail_if(ssht_add(t, ssht_makeKVPair("one too many", "this")));

	fail_unless(ssht_lookup(t, "not here!") == NULL);
} END_TEST

START_TEST (large_check) {

	struct strStrHashTable* t = ssht_create(5000);
	int c = 0;
	for (c = 1; c <= 5000; c++) {
		fail_unless(ssht_add(t, ssht_makeKVPair(itoa(c, 10), itoa(2*c, 10))));
	}

	fail_if(ssht_add(t, ssht_makeKVPair("One too many", "nope")));

} END_TEST

// modified from: http://www.jb.man.ac.uk/~slowe/cpp/itoa.html
char* itoa(int val, int base){
	
	char* buf = (char*) calloc(32, sizeof(char));
	
	int i = 30;
	
	for(; val && i ; --i, val /= base)
		buf[i] = "0123456789abcdef"[val % base];
	
	return buf;
	
}



Suite* ssht_suite() {
	Suite* s = suite_create("String -> String Hash Table Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, create_table);
	tcase_add_test (tc_core, small_check);
	tcase_add_test (tc_core, large_check);


	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;
	Suite *s = ssht_suite();
	SRunner *sr = srunner_create (s);
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
