#include <stdlib.h>
#include <check.h>
#include <math.h>
#include <stdio.h>
#include "angle_sample.h"
#include "contextFactory.h"

#define NUM_TO_TEST 20

cl_device_id did;

START_TEST (testAngles) {
	float* vals = generateAngleSamples(NUM_TO_TEST, did);
	int i;
	float sqrSum = 0.0f;
	for (i = 0; i < NUM_TO_TEST*3; i += 3) {
		sqrSum = powf(vals[i], 2);
		sqrSum += powf(vals[i + 1], 2);
		sqrSum += powf(vals[i + 2], 2);

		fail_unless(fabs(sqrSum - 1.0f) < 0.0001f, "Should have been 1: %f. With values(%f, %f, %f)", sqrSum, vals[i], vals[i], vals[i + 1], vals[i + 2]);
	}
} END_TEST

/*START_TEST(RayleighUniformity) {
	float* vals = generateAngleSamples(NUM_TO_TEST, did);
	// data in vals is cosine(x). sin(x) = sqrt(1 - cos(x)^2) = sin(acos(x))
	float C = 0.0; // sum of cosines
	float S = 0.0; // sum of sines

	// test uniformity of x	
	
	float[10] test = {55.f, 60.f, 65.f, 95.f, 100.f, 110.f, 260.f, 275.f, 285.f, 295.f};

	int i;
	for (i = 0; i < NUM_TO_TEST*3; i += 3) {
		printf("%f, ", acosf(vals[i]));
		C += vals[i];
		S += sqrtf(1 - powf(vals[i], 2));
	}

	// normalize C and S
	C /= (float)NUM_TO_TEST;
	S /= (float)NUM_TO_TEST;

	printf("\nAvg S: %f Avg C: %f\n", S, C);

	// calculate R
	float R = sqrtf(powf(C, 2) + powf(S, 2));
	
	printf("2nR: %f\n", 2.0f*(float)NUM_TO_TEST*R);

	// calculate S*, the modified/corrected R statistic (error = O(n^(-2)))
	float Sstar = (1.0f - (1.0f / (2.0f * (float)NUM_TO_TEST))) * 2.0f * (float)NUM_TO_TEST * powf(R, 2);
	Sstar += ((float)NUM_TO_TEST * powf(R, 4))/2.0f;

	printf("S*: %f\n", Sstar);
	
	fail();

} END_TEST*/

Suite* angle_suite() {
	Suite* s = suite_create("Angle Sample Tests");
	TCase *tc_core = tcase_create ("Core");
	tcase_add_test (tc_core, testAngles);
	//tcase_add_test (tc_core, RayleighUniformity);
	suite_add_tcase (s, tc_core);
	
	return s;
}

int main() { 
	int number_failed;
	
	did = getArbitraryDevice();

	Suite *s = angle_suite();
	SRunner *sr = srunner_create (s);
	#ifdef AMDAPP // doesn't like forking
		srunner_set_fork_status (sr, CK_NOFORK);
	#endif 
	srunner_run_all (sr, CK_NORMAL);
	number_failed = srunner_ntests_failed (sr);
	srunner_free (sr);
	return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
