#include "random.h"

#define BUFFER_SIZE 128

struct RandomNumberConfiguration* getRandomNumberGenerator(int generator_id) {
	struct RandomNumberConfiguration* rnc = malloc(sizeof(struct RandomNumberConfiguration));	
	if (rnc == NULL) return NULL;
	if (generator_id == 1) {
		rnc->current = 	1664525;
		rnc->modValue = (int)((1U << 31) - 1);
		rnc->addValue = 1013904223;
		rnc->multiplyValue = 1664525;
		rnc->position = 0;
		rnc->bitmask = (int)((1U << 31) - 1);
		return rnc;
	}

	free(rnc);
	fprintf(stderr, "ERROR: Unknown generator id: %d", generator_id);
	return NULL;
}


float h_rand(struct RandomNumberConfiguration* rnc) {
	return (float)((float)h_rand_nonorm(rnc) * (1.0 / (float)rnc->modValue));
}

int h_rand_nonorm(struct RandomNumberConfiguration* rnc) {
	rnc->current = ((rnc->current * rnc->multiplyValue) + rnc->addValue) & rnc->bitmask;
	rnc->position++;
	return rnc->current;
}

void h_skipAhead(struct RandomNumberConfiguration* rnc, int toSkip) {
	// TODO: replace with skipahead function
	int i;
	for (i=0; i < toSkip; i++) {
		(void)h_rand(rnc);	
	}
}


void createRandomNumberDeviceCode(struct RandomNumberConfiguration* rnc, struct strStrHashTable* t) {
	// %INITSEED% %MULT% %ADD% %MASK% %NORM%

	char initSeed[BUFFER_SIZE];
	char mult[BUFFER_SIZE];
	char add[BUFFER_SIZE];
	char mask[BUFFER_SIZE];
	char norm[BUFFER_SIZE];

	snprintf(initSeed, (size_t) 128, "%d", rnc->current);
	snprintf(mult, (size_t) 128, "%d", rnc->multiplyValue);
	snprintf(add, (size_t) 128, "%d", rnc->addValue);
	snprintf(mask, (size_t) 128, "%d", rnc->bitmask);
	snprintf(norm,(size_t) 128, "%d", rnc->modValue);

	ssht_add(t, ssht_makeKVPair("%INITSEED%", initSeed));
	ssht_add(t, ssht_makeKVPair("%MULT%", mult));
	ssht_add(t, ssht_makeKVPair("%ADD%", add));
	ssht_add(t, ssht_makeKVPair("%MASK%", mask));
	ssht_add(t, ssht_makeKVPair("%NORM%", norm));
}


