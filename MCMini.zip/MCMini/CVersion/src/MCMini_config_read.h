#ifndef MCMINI_CONFIG_H
#define MCMINI_CONFIG_H
#include "config_reader.h"
#include "strstrhashtable.h"
#include <stdio.h>


#define MCMINI_CONFIG_TRUE "true"
#define MCMINI_CONFIG_FALSE "false"


#define MCMINI_CONFIG_KEY_DID "device_id"
#define MCMINI_CONFIG_KEY_DIDS "device_ids"
#define MCMINI_CONFIG_KEY_NUM_PARTICLES "num_particles"
#define MCMINI_CONFIG_KEY_NUM_BATCHES "num_batches"

#define MCMINI_CONFIG_KEY_LNK3DNT "lnk3dnt"

#define MCMINI_CONFIG_KEY_X_BOUNDS "x_bounds"
#define MCMINI_CONFIG_KEY_Y_BOUNDS "y_bounds"
#define MCMINI_CONFIG_KEY_Z_BOUNDS "z_bounds"

#define MCMINI_CONFIG_KEY_PUSH_X "push_x"
#define MCMINI_CONFIG_KEY_PUSH_Y "push_y"
#define MCMINI_CONFIG_KEY_PUSH_Z "push_z"

#define MCMINI_CONFIG_KEY_SOURCE_X "source_x"
#define MCMINI_CONFIG_KEY_SOURCE_Y "source_y"
#define MCMINI_CONFIG_KEY_SOURCE_Z "source_z"

#define MCMINI_CONFIG_KEY_ZONE_HISTORY "zone_history"
#define MCMINI_CONFIG_KEY_ZONE_TALLY "zone_tally"
#define MCMINI_CONFIG_KEY_PARTICLE_TRACK_LENGTH "particle_track_length"
#define MCMINI_CONFIG_KEY_FLUX_TALLY "flux_tally"

#define MCMINI_CONFIG_KEY_IMAGE_AXIS "image_axis"
#define MCMINI_CONFIG_KEY_IMAGE_PLANE "image_plane"
#define MCMINI_CONFIG_KEY_IMAGE_TYPE "image_type"
#define MCMINI_CONFIG_VALUE_IMAGE_TYPE_ZONE "zone"
#define MCMINI_CONFIG_VALUE_IMAGE_TYPE_FLUX "flux"

#define IMAGE_TYPE_ZONE 0
#define IMAGE_TYPE_FLUX 1

#define MCMINI_CONFIG_KEY_DEFAULT_MATERIAL "default_material"

struct MCMini_config {
	int num_devices;
	int* device_ids;

	int num_particles;
	int orig_num_particles;
	int num_materials;
	int num_batches;
	int curr_batch;

	float* num_x_bounds;
	float* x_bounds;

	float* num_y_bounds;
	float* y_bounds;

	float* num_z_bounds;
	float* z_bounds;

	float source_x;
	float source_y;
	float source_z;

	float push_x;
	float push_y;
	float push_z;

	int zone_tally;
	int particle_track_length;
	int zone_history;
	int flux_tally;

	int image_axis;
	int image_plane;
	int image_type;
	
	float* material_weights;
	struct alias_list** zone_material;

	int* mat_map;
};


struct MCMini_config* read_MCMini_config(char* file);
void write_geom_data(struct MCMini_config* c, FILE* f);

#include "lnk3dnt.h"
#endif
