#include "opencl.h"

struct opencl_runtime* setup_opencl(struct MCMini_config* config) {
	struct opencl_runtime* r = malloc(sizeof(struct opencl_runtime));
	
	if (config->device_ids[omp_get_thread_num()] == -1) {
		r->did = promptUserForDevice();
	} else {
		r->did = getDeviceByIndex(config->device_ids[omp_get_thread_num()]);
	}
	r->ctx = createContextFromDevice(r->did);
	r->cdq = createCommandQueue(r->ctx, r->did);
	return r;
}

