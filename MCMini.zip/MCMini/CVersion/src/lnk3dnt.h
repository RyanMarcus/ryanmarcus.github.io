#ifndef LNK3DNT_H
#define LNK3DNT_H
#include <stdio.h>
#include <stdlib.h>
#include "MCMini_config_read.h"
#include "materials.h"
void read_lnk3dnt(FILE* f, struct MCMini_config* c);
#endif
