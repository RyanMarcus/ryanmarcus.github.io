#ifndef MINIOPENCL_H
#define MINIOPENCL_H
#ifdef __APPLE__
	#include <OpenCL/opencl.h>
#else
	#include <CL/cl.h>
	#include <CL/opencl.h>
#endif

#include "contextFactory.h"
#include "MCMini_config_read.h"
#include <omp.h>

struct opencl_runtime {
	cl_device_id did;
	cl_context ctx;
	cl_command_queue cdq;
	size_t opt;
};

struct opencl_runtime* setup_opencl(struct MCMini_config* config);

#endif

