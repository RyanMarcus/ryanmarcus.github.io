#ifndef IMAGE_H
#define IMAGE_H

#include <stdlib.h>
#include <stdio.h>
#include "tally.h"
#include "MCMini_config_read.h"
#include "materials.h"

void create_image(struct zone_tally* t, struct MCMini_config* c, int axis, int plane, FILE* f);

#endif
