#include "libcompat.h"

void
unsetenv (const char *name CK_ATTRIBUTE_UNUSED)
{
  assert (0);
}
