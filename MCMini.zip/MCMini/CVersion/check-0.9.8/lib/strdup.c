#include "libcompat.h"

char *
strdup (const char *str CK_ATTRIBUTE_UNUSED)
{
  assert (0);
  return NULL;
}
