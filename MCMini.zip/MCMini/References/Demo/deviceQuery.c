#include <stdio.h>
#include <stdlib.h>
#include <CL/cl.h>
#include <CL/opencl.h>


void printPlatformInfo(cl_platform_id id);
void printDeviceInfo(cl_device_id id);
void printDevicesForPlatform(cl_platform_id id);
int main(int argc, char** argv);

void printPlatformInfo(cl_platform_id id) {
	size_t bufSize = 1024;
	char buf[1024];
		
	clGetPlatformInfo(id, CL_PLATFORM_PROFILE, bufSize, buf, NULL);
	printf("\tPlatform profile: %s\n", buf);
		
	clGetPlatformInfo(id, CL_PLATFORM_VERSION, bufSize, buf, NULL);
	printf("\tPlatform version: %s\n", buf);
		
	clGetPlatformInfo(id, CL_PLATFORM_NAME, bufSize, buf, NULL);
	printf("\tPlatform name: %s\n", buf);
		
	clGetPlatformInfo(id, CL_PLATFORM_VENDOR, bufSize, buf, NULL);
	printf("\tPlatform vendor: %s\n", buf);
		
	clGetPlatformInfo(id, CL_PLATFORM_EXTENSIONS, bufSize, buf, NULL);
	printf("\tPlatform extensions: %s\n", buf);
	
	printDevicesForPlatform(id);
}

void printDeviceInfo(cl_device_id id) {
	char buf[128];
	size_t bufSize = 128;
	
	
	clGetDeviceInfo(id, CL_DEVICE_NAME, bufSize, buf, NULL);
	printf("\t\t%s\n", buf);
	
	cl_ulong glob_mem;
	clGetDeviceInfo(id, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &glob_mem, NULL);
	printf("\t\tGlobal memory: %lu bytes (%f GB)\n", (unsigned long)glob_mem, (double)glob_mem/1073741824.);

	clGetDeviceInfo(id, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(cl_ulong), &glob_mem, NULL);
	printf("\t\tGlobal memory: %lu bytes (%f KB)\n", (unsigned long)glob_mem, (double)glob_mem/1024);
	
	cl_uint freq;
	clGetDeviceInfo(id, CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof(cl_uint), &freq, NULL);
	printf("\t\tClock speed: %d Mhz (%f Ghz)\n", (unsigned int)freq, (double)freq/1024);
	
	clGetDeviceInfo(id, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(cl_uint), &freq, NULL);
	printf("\t\tCompute units: %d \n", (unsigned int)freq);
}

void printDevicesForPlatform(cl_platform_id id) {
	cl_uint num_devices;
	cl_device_id devices[128];
	clGetDeviceIDs(id, CL_DEVICE_TYPE_ALL, 128, devices, &num_devices);
	printf("\tHas %d device(s)\n", num_devices);
	int i = 0;
	while (i != num_devices) {
		printDeviceInfo(devices[i]);
		i++;
	}
}


int main(int argc, char** argv) {
	cl_int err;
	cl_platform_id ids[128];
	cl_uint plat_aval;
	
	err = clGetPlatformIDs(128, ids, &plat_aval);
	
	if (err == CL_SUCCESS) {
		printf("%d platforms available\n", plat_aval);
		int i = 0;
		while (i != plat_aval) {
			printf("PLATFORM %d\n", i + 1);
			printPlatformInfo(ids[i]);
			i++;
		}
		exit(0);
	}

	printf("An error occured.\n");
	exit(1);
}
