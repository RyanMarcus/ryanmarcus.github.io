# benchmark device 1...
RUNS=100
SETS=800000
RESULT=results.txt
TEMP=`mktemp benchmark.XXXX`

if [ -e results.txt ]
then
	rm results.txt
fi

echo -ne '[            ]\r'

echo "*** DEVICE 1 ***" >> $RESULT
./piCalc $RUNS $SETS 1 > $TEMP
cat $TEMP | grep Using >> $RESULT
cat $TEMP | grep Time >> $RESULT

echo -ne '[##          ]\r'

./piCalc $RUNS $SETS 1 > $TEMP
cat $TEMP | grep Time >> $RESULT

echo -ne '[####        ]\r'

./piCalc $RUNS $SETS 1 > $TEMP
cat $TEMP | grep Time >> $RESULT

echo -ne '[######      ]\r'

echo "*** DEVICE 2 ***" >> $RESULT
./piCalc $RUNS $SETS 2 > $TEMP
cat $TEMP | grep Using >> $RESULT
cat $TEMP | grep Time >> $RESULT

echo -ne '[########    ]\r'


./piCalc $RUNS $SETS 2 > $TEMP
cat $TEMP | grep Time >> $RESULT

echo -ne '[##########  ]\r'

./piCalc $RUNS $SETS 2 > $TEMP
cat $TEMP | grep Time >> $RESULT

echo -ne '[############]\r'

cat results.txt

rm $TEMP

