#include "opencl.h"
#include <stdio.h>
#include <stdlib.h>

void listDevices(void) {
	cl_int err;
	cl_platform_id pids[128];
	cl_uint plat_aval;
	
	char buf[128];
	size_t bufSize = 128;
	
	cl_device_id dids[100];
	int lastDevice = 0;
	
	err = clGetPlatformIDs(128, pids, &plat_aval);
	
	if (err == CL_SUCCESS) {
		int i = 0;
		while (i != plat_aval) {
			printf("Devices availabe on platform %d:\n", i + 1);
		
		
			cl_uint num_devices;
			cl_device_id devices[128];
			clGetDeviceIDs(pids[i], CL_DEVICE_TYPE_ALL, 128, devices, &num_devices);
			int ii = 0;
			while (ii != num_devices) {
				clGetDeviceInfo(devices[ii], CL_DEVICE_NAME, bufSize, buf, NULL);
				dids[lastDevice] = devices[ii];
				printf("\t%d: %s\n", lastDevice + 1, buf);
				lastDevice++;
				ii++;
			}

			i++;
		}
	}

	fprintf(stderr, "An error occured while accessing the OpenCL platform.\n");
	return;
}

cl_device_id promptUserForDevice(void) {
	cl_int err;
	cl_platform_id pids[128];
	cl_uint plat_aval;
	
	char buf[128];
	size_t bufSize = 128;
	
	cl_device_id dids[100];
	int lastDevice = 0;
	
	err = clGetPlatformIDs(128, pids, &plat_aval);
	
	if (err == CL_SUCCESS) {
		int i = 0;
		while (i != plat_aval) {
			printf("Devices availabe on platform %d:\n", i + 1);
		
		
			cl_uint num_devices;
			cl_device_id devices[128];
			clGetDeviceIDs(pids[i], CL_DEVICE_TYPE_ALL, 128, devices, &num_devices);
			int ii = 0;
			while (ii != num_devices) {
				clGetDeviceInfo(devices[ii], CL_DEVICE_NAME, bufSize, buf, NULL);
				dids[lastDevice] = devices[ii];
				printf("\t%d: %s\n", lastDevice + 1, buf);
				lastDevice++;
				ii++;
			}

			i++;
		}

		int choice;
		printf("\nChoose a device: ");
		scanf("%d", &choice);
		if (choice > lastDevice || choice <= 0) {
			fprintf(stderr, "Invalid option for device!\n");
			return NULL;
		}
		
		return dids[choice - 1];
	}

	fprintf(stderr, "An error occured while accessing the OpenCL platform.\n");
	return NULL;
}

cl_device_id getDeviceByIndex(int idx) {
cl_int err;
	cl_platform_id pids[128];
	cl_uint plat_aval;
	
	char buf[128];
	size_t bufSize = 128;
	
	cl_device_id dids[100];
	int lastDevice = 0;
	
	err = clGetPlatformIDs(128, pids, &plat_aval);
	
	if (err == CL_SUCCESS) {
		int i = 0;
		while (i != plat_aval) {
			cl_uint num_devices;
			cl_device_id devices[128];
			clGetDeviceIDs(pids[i], CL_DEVICE_TYPE_ALL, 128, devices, &num_devices);
			int ii = 0;
			while (ii != num_devices) {
				clGetDeviceInfo(devices[ii], CL_DEVICE_NAME, bufSize, buf, NULL);
				dids[lastDevice] = devices[ii];
				if (lastDevice + 1 == idx) {
					return dids[lastDevice];
				}
				lastDevice++;
				ii++;
			}

			i++;
		}
	}

	fprintf(stderr, "An error occured while accessing the OpenCL platform.\n");
	return NULL;
}

void printDeviceInfo(cl_device_id id) {
	char buf[128];
	size_t bufSize = 128;
	
	
	clGetDeviceInfo(id, CL_DEVICE_NAME, bufSize, buf, NULL);
	printf("%s\n", buf);
	
	cl_ulong glob_mem;
	clGetDeviceInfo(id, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &glob_mem, NULL);
	printf("\tGlobal memory: %lu bytes (%f GB)\n", (unsigned long)glob_mem, (double)glob_mem/1073741824.);

	clGetDeviceInfo(id, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(cl_ulong), &glob_mem, NULL);
	printf("\tLocal memory: %lu bytes (%f KB)\n", (unsigned long)glob_mem, (double)glob_mem/1024);
	
	cl_uint freq;
	clGetDeviceInfo(id, CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof(cl_uint), &freq, NULL);
	printf("\tClock speed: %d Mhz (%f Ghz)\n", (unsigned int)freq, (double)freq/1024);
	
	clGetDeviceInfo(id, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(cl_uint), &freq, NULL);
	printf("\tCompute units: %d \n", (unsigned int)freq);
}

cl_device_id getArbitraryDevice(void) {
	cl_int err;
	cl_platform_id pids[128];
	cl_uint plat_aval;
	
	err = clGetPlatformIDs(128, pids, &plat_aval);
	
	if (err == CL_SUCCESS) {
		cl_uint num_devices;
		cl_device_id devices[128];
		clGetDeviceIDs(pids[0], CL_DEVICE_TYPE_ALL, 128, devices, &num_devices);
		return devices[0];
	}
	fprintf(stderr, "An error occured while accessing the OpenCL platform.\n");

	return NULL;
}

cl_context createContextFromDevice(cl_device_id id) {
	cl_int err;
	cl_context ctx = clCreateContext(NULL, 1, &id, NULL, NULL, &err);
	if (err != CL_SUCCESS) {
		fprintf(stderr, "An error occured while creating a device context\n");
		return NULL;
	}
	
	return ctx;
}

cl_command_queue createCommandQueue(cl_context ctx, cl_device_id id) {
	cl_int err;
	cl_command_queue cdq = clCreateCommandQueue(ctx, id, 0, &err);
	if (err != CL_SUCCESS) {
		fprintf(stderr, "An error occurred when creating a command queue\n");
		return NULL;
	}
	
	return cdq;
	
}

void releaseCommandQueue(cl_command_queue cdq) {
	if (clReleaseCommandQueue(cdq) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing a command queue\n");
	}
}

cl_mem createBuffer(cl_context ctx, cl_mem_flags flags, size_t size, void* host) {
	cl_int err;
	cl_mem toR = clCreateBuffer(ctx, flags, size, host, &err);
	if (err != CL_SUCCESS) {
		switch (err) {
			case CL_INVALID_CONTEXT: fprintf(stderr, "An error occurred while creating a buffer: invalid context\n"); break;
			case CL_INVALID_VALUE: fprintf(stderr, "An error occurred while creating a buffer: bad flags\n"); break;
			case CL_INVALID_BUFFER_SIZE: fprintf(stderr, "An error occurred while creating a buffer: invalid buffer size\n"); break;
			case CL_INVALID_HOST_PTR: fprintf(stderr, "An error occurred while creating a buffer: invalid / missing host pointers\n"); break;
			case CL_MEM_OBJECT_ALLOCATION_FAILURE: fprintf(stderr, "An error occurred while creating a buffer: memory allocation error\n"); break;
			case CL_OUT_OF_RESOURCES: fprintf(stderr, "An error occurred while creating a buffer: device failed to allocate memory\n"); break;
			case CL_OUT_OF_HOST_MEMORY: fprintf(stderr, "An error occurred while creating a buffer: out of host memory\n"); break;
			default: fprintf(stderr, "An error occurred while creating a buffer\n");
		}
		return NULL;
	}
	
	return toR;
}

cl_event readFromBuffer(cl_command_queue cdq, cl_mem buffer, size_t size, void* host) {
	cl_event toR;
	if (clEnqueueReadBuffer(cdq, buffer, CL_FALSE, 0, size, host, 0, NULL, &toR) != CL_SUCCESS) {
		fprintf(stderr, "There was an error enqueueing a read from a buffer\n");
		return NULL;
	}
	return toR;
}

cl_event writeToBuffer(cl_command_queue cdq, cl_mem buffer, size_t size, void* ptr) {
	cl_event toR;
	if (clEnqueueWriteBuffer(cdq, buffer, CL_FALSE, 0, size, ptr, 0, NULL, &toR) != CL_SUCCESS) {
		fprintf(stderr, "There was an error enqueueing a write from a buffer\n");
		return NULL;
	}
	
	return toR;
}

void releaseMemObject(cl_mem mem) {
	if (clReleaseMemObject(mem) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing a memory object / buffer\n");
	}
}

cl_program createProgram(cl_context ctx, cl_device_id id, const char* string) {
	cl_int err;
	cl_program toR = clCreateProgramWithSource(ctx, 1, (const char**) &string, NULL, &err);
	if (err != CL_SUCCESS || !toR) {
		fprintf(stderr, "An error occurred while creating a program\n");
		return NULL;
	}
	
	err = clBuildProgram(toR, (cl_uint)1, &id, NULL, NULL, NULL);
	if (err != CL_SUCCESS) {
		size_t len;
        char buffer[2048];

        printf("Error: Failed to build program executable!\n");
        clGetProgramBuildInfo(toR, id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
	
	
		switch (err) {
			case CL_INVALID_PROGRAM: fprintf(stderr, "An error occurred while building the program: invalid program\n"); break;
			case CL_INVALID_VALUE: fprintf(stderr, "An error occurred while building the program: invalid device values or list\n"); break;
			case CL_INVALID_DEVICE: fprintf(stderr, "An error occurred while building the program: invalid device\n"); break;
			case CL_INVALID_BINARY: fprintf(stderr, "An error occurred while building the program: invalid binary\n"); break;
			case CL_INVALID_BUILD_OPTIONS: fprintf(stderr, "An error occurred while building the program: invalid build options\n"); break;
			case CL_INVALID_OPERATION: fprintf(stderr, "An error occurred while building the program: other builds incomplete\n"); break;
			case CL_COMPILER_NOT_AVAILABLE: fprintf(stderr, "An error occurred while building the program: no compiler\n"); break;
			case CL_BUILD_PROGRAM_FAILURE: fprintf(stderr, "An error occurred while building the program: build program failure\n"); break;
			case CL_OUT_OF_RESOURCES: fprintf(stderr, "An error occurred while building the program: out of device resources\n"); break;
			case CL_OUT_OF_HOST_MEMORY: fprintf(stderr, "An error occurred while building the program: out of host resources\n"); break;
			default: fprintf(stderr, "An error occurred while building the program\n");
		}
		return NULL;
	}
	
	return toR;
}

cl_kernel createKernel(cl_program prg, const char* kernel_name) {
	cl_int err;
	cl_kernel ck = clCreateKernel(prg, kernel_name, &err);
	if (err != CL_SUCCESS || !ck ) {
		fprintf(stderr, "An error occurred while creating a kernal\n");
		return NULL;
	}
	return ck;
}

cl_event startKernel(cl_command_queue cdq, cl_kernel ck, size_t globalSize, size_t localSize) { 
	cl_uint err = 0;
	cl_device_id cdq_id;
	
	err = clGetCommandQueueInfo(cdq, CL_QUEUE_DEVICE, sizeof(cdq_id), &cdq_id, NULL);
	if (err != CL_SUCCESS) {
		fprintf(stderr, "Could not find the device ID for the given command queue\n");
		return NULL;
	}
	
	cl_event toR;
	err = clEnqueueNDRangeKernel(cdq, ck, (cl_uint)1, NULL, &globalSize, &localSize, (cl_uint)0, NULL, &toR);
	if (err != CL_SUCCESS) {
		switch (err) {
			case CL_INVALID_PROGRAM_EXECUTABLE: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid program executable\n"); break;
			case CL_INVALID_COMMAND_QUEUE: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid command queue\n"); break;
			case CL_INVALID_KERNEL: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid kernel\n"); break;
			case CL_INVALID_CONTEXT: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid context\n"); break;
			case CL_INVALID_KERNEL_ARGS: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid kernel arguments\n"); break;
			case CL_INVALID_WORK_DIMENSION: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid work dimension\n"); break;
			case CL_INVALID_GLOBAL_WORK_SIZE: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid global work size\n"); break;
			case CL_INVALID_GLOBAL_OFFSET: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid global offset\n"); break;
			case CL_INVALID_WORK_ITEM_SIZE: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid work item size\n"); break;
			case CL_OUT_OF_RESOURCES: fprintf(stderr, "An error occurred while enqueueing a kernel: out of resources\n"); break;
			case CL_MEM_OBJECT_ALLOCATION_FAILURE: fprintf(stderr, "An error occurred while enqueueing a kernel: mem object allocation failure\n"); break;
			case CL_OUT_OF_HOST_MEMORY: fprintf(stderr, "An error occurred while enqueueing a kernel: out of host memory\n"); break;
			case CL_INVALID_WORK_GROUP_SIZE: fprintf(stderr, "An error occurred while enqueueing a kernel: invalid work group size\n"); break;
			default: fprintf(stderr, "An error occurred while enqueueing a kernel: %d\n", err);
		}

		return NULL;
	}
	return toR;
}

void setKernelArg(cl_kernel ck, unsigned int index, size_t arg_size, void* arg_val) {
	cl_uint err = clSetKernelArg(ck, index, arg_size, arg_val);
	if (err != CL_SUCCESS) {
		switch (err) {
			case CL_INVALID_KERNEL: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid kernel\n"); break;
			case CL_INVALID_ARG_INDEX: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid arg index\n"); break;
			case CL_INVALID_ARG_VALUE: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid arg value\n"); break;
			case CL_INVALID_MEM_OBJECT: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid mem object\n"); break;
			case CL_INVALID_SAMPLER: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid sampler\n"); break;
			case CL_INVALID_ARG_SIZE: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: invalid arg size\n"); break;
			case CL_OUT_OF_RESOURCES: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: out of device space\n"); break;
			case CL_OUT_OF_HOST_MEMORY: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel: out of host memory\n"); break;
			default: fprintf(stderr, "An error occurred while trying to set the arguments to a kernel\n");
		}
	}
}

size_t getOptimalMultiple(cl_kernel ck, cl_device_id d) {
	size_t size = 0;
	if (CL_SUCCESS != clGetKernelWorkGroupInfo(ck, d, CL_KERNEL_PREFERRED_WORK_GROUP_SIZE_MULTIPLE, sizeof(size_t), &size, NULL)) {
		fprintf(stderr, "An error occurred while fetching the optimal multiple");
	}

	return size;
}

void waitForEvent(cl_event ce) {
	if (clWaitForEvents(1, &ce) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while waiting for an event to finish\n");
	}
}

void waitForAllEvents(cl_command_queue cdq) {
	if (clFinish(cdq) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred waiting for a command queue to finish\n");
	}
}

void releaseEvent(cl_event ce) {
	if (clReleaseEvent(ce) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing an event\n");
	}
}


void releaseKernel(cl_kernel ck) {
	if (clReleaseKernel(ck) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing a kernel\n");
	}
}


void releaseProgram(cl_program prg) {
	if (clReleaseProgram(prg) != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing a program\n");
	}
}



void releaseContext(cl_context ctx) {
	cl_int err;
	err = clReleaseContext(ctx);
	if (err != CL_SUCCESS) {
		fprintf(stderr, "An error occurred while releasing the context\n");
	}
}
