#ifndef HAS_OPENCL
	#define HAS_OPENCL
	#ifdef __APPLE__
		#include <OpenCL/opencl.h>
	#else
		#include <CL/cl.h>
		#include <CL/opencl.h>
	#endif
#endif