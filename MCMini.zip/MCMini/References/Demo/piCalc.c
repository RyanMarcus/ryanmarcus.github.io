#include "contextFactory.h"
#include "opencl.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <time.h>

int roundToMult(int numToRound, int multiple)  {  
	if(multiple == 0) {  
		return numToRound;  
	}  

	int remainder = numToRound % multiple; 
	if (remainder == 0) {
		return numToRound; 
	}

	return numToRound + multiple - remainder; 
}

char* piCalcKernel =	"int nextRand(int last);\n"
			"int nextRand(int last) {\n"
			"	return abs(((1103515245 * last) + 12345));\n"
			"}\n"
			"\n"
			"__kernel void calcPi(__global float* vals, int runs) {\n"
			"	int first = nextRand(get_global_id(0));\n"
			"	int i;\n"
			"	for (i = 0; i < runs; i++) {\n"
			"		float xVal = (float)(first % 10000) / 10000.0;\n"
			"		first = nextRand(first);\n"
			"		float yVal = (float)(first % 10000) / 10000.0;\n"
			"		xVal = pown(0.5 - xVal, 2);\n"
			"		yVal = pown(0.5 - yVal, 2);\n"
			"		xVal += yVal;\n"
			"		if (xVal <= 0.25) vals[get_global_id(0)] += 1;\n"
			"	}\n"
			"}\n";

int main(int argc, char** argv) {

	if (argc != 4) {
		fprintf(stderr, "Usage: %s RUNS SETS DEV_IDX\n", argv[0]);
		listDevices();
		exit(1);
	}

	int RUNS = atoi(argv[1]);
	int SETS = atoi(argv[2]);

	cl_device_id id = getDeviceByIndex(atoi(argv[3]));
	printf("Using: ");
	printDeviceInfo(id);
		
	printf("\n\n***************************************************\nPi calculator\nAn OpenCL sample\nRyan Marcus <ryan@rmarcus.info>\n***************************************************\n\n");
	
	time_t t0 = time(NULL);

	cl_context ctx = createContextFromDevice(id);
	cl_command_queue cdq = createCommandQueue(ctx, id);
	
	printf("compile and load the program...\n");
	cl_program prg = createProgram(ctx, id, piCalcKernel);
	
	printf("create a kernel from the program...\n");
	cl_kernel ck = createKernel(prg, "calcPi");
	
	printf("finding good run values... ");
	size_t opt = getOptimalMultiple(ck, id);
	SETS = roundToMult(SETS, (int)opt);
	printf (" %d per = %d total\n", (int) opt, SETS);

	printf("create space on the host...\n");
	cl_int arraySize = SETS;
	cl_int runs = RUNS;
	int numWorkers = arraySize;
	size_t sz = arraySize * sizeof(float);
	float* hvals = calloc((int)arraySize, sizeof(float));
	
	printf("create buffers for the device...\n");
	cl_mem dvals = createBuffer(ctx, CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR, sizeof(float) * arraySize, hvals);
	cl_event wce = writeToBuffer(cdq, dvals, sz, hvals);
	waitForEvent(wce);
	releaseEvent(wce);
	
	printf("set the kernel's arguments...\n");
	setKernelArg(ck, 0, sizeof(cl_mem), (void*) &dvals);
	setKernelArg(ck, 1, sizeof(cl_int), &runs);


	printf("run the kernel...\n");
	cl_event ce = startKernel(cdq, ck, numWorkers, opt);
	
	printf("wait for this event...\n");
	waitForEvent(ce);
	releaseEvent(ce);

	
	printf("wait for the kernel to finish...\n");
	waitForAllEvents(cdq);

	printf("read back the data..\n");
	cl_event mre = readFromBuffer(cdq, dvals, sz, hvals); 
	waitForEvent(mre);
	releaseEvent(mre);
	
	
	releaseCommandQueue(cdq);
	releaseContext(ctx);
	
	printf("Time: %ld\n", (time(NULL) - t0));

	int i = 0;
	float calcVal = 0.0;
	for (i=0; i < arraySize; i++) {
		calcVal += hvals[i] / (float)RUNS;
	}
			
	printf("%f\n", 4.0*(calcVal/arraySize));
	exit(0);
}
