#import <Foundation/NSObject.h>

struct linked_list_node {
	void* val;
	struct linked_list_node* next;
};

@interface LinkedList : NSObject {
	@private
	struct linked_list_node* root;
	int count;
}
	- (id)init;
	- (void)add:(void*)toAdd;
	- (void*)pop;
	- (int)length;
@end
