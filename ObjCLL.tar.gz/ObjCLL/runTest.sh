rm results.txt
if [ "$(uname)" != 'Darwin' ]; then
make clean
make ObjC CC=clang
make C CC=clang

SYSINFO=`uname -sr`

echo -n -e "$SYSINFO Clang C size 100: \n" >> results.txt
(time ./C 100) 2>> results.txt

echo -n -e "\n$SYSINFO Clang C size 1000\n" >> results.txt
(time ./C 1000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang C size 10000\n" >> results.txt
(time ./C 10000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang C size 20000\n" >> results.txt
(time ./C 20000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang C size 30000\n" >> results.txt
(time ./C 30000) 2>> results.txt

echo -n -e "\n$SYSINFO Clang C size 50000\n" >> results.txt
(time ./C 50000) 2>> results.txt



echo -n -e "\n$SYSINFO Clang ObjC size 100\n" >> results.txt
(time ./ObjC 100) 2>> results.txt


echo -n -e "\n$SYSINFO Clang ObjC size 1000\n" >> results.txt
(time ./ObjC 1000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang ObjC size 10000\n" >> results.txt
(time ./ObjC 10000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang ObjC size 20000\n" >> results.txt
(time ./ObjC 20000) 2>> results.txt


echo -n -e "\n$SYSINFO Clang ObjC size 30000\n" >> results.txt
(time ./ObjC 30000) 2>> results.txt

echo -n -e "\n$SYSINFO Clang ObjC size 50000\n" >> results.txt
(time ./ObjC 50000) 2>> results.txt


fi

make clean
make ObjC CC=gcc
make C CC=gcc


echo -n -e "\n$SYSINFO GCC C size 100\n" >> results.txt
(time ./C 100) 2>> results.txt


echo -n -e "\n$SYSINFO GCC C size 1000\n" >> results.txt
(time ./C 1000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC C size 10000\n" >> results.txt
(time ./C 10000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC C size 20000\n" >> results.txt
(time ./C 20000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC C size 30000\n" >> results.txt
(time ./C 30000) 2>> results.txt

echo -n -e "\n$SYSINFO GCC C size 50000\n" >> results.txt
(time ./C 50000) 2>> results.txt




echo -n -e "\n$SYSINFO GCC ObjC size 100\n" >> results.txt
(time ./ObjC 100) 2>> results.txt


echo -n -e "\n$SYSINFO GCC ObjC size 1000\n" >> results.txt
(time ./ObjC 1000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC ObjC size 10000\n" >> results.txt
(time ./ObjC 10000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC ObjC size 20000\n" >> results.txt
(time ./ObjC 20000) 2>> results.txt


echo -n -e "\n$SYSINFO GCC ObjC size 30000\n" >> results.txt
(time ./ObjC 30000) 2>> results.txt

echo -n -e "\n$SYSINFO GCC ObjC size 50000\n" >> results.txt
(time ./ObjC 50000) 2>> results.txt


