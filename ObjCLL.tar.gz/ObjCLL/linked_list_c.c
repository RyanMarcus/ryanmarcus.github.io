#include "linked_list_c.h"

struct linked_list* ll_create() {
	return calloc(1, sizeof(struct linked_list));
}

void ll_add(void* toAdd, struct linked_list* root) {
	if (root->root == NULL) {
		root->root = malloc(sizeof(struct int_array_node));
		root->root->val = toAdd;
		root->root->next = NULL;
		root->count++;
		return;
	}

	struct int_array_node* tmp = root->root;
	root->root = malloc(sizeof(struct int_array_node));
	root->root->next = tmp;
	root->root->val = toAdd;
	root->count++;
	return;
}

void* ll_pop(struct linked_list* root) {
	if (root == NULL) return NULL;
	if (root->root == NULL) return NULL;
	struct int_array_node* next = root->root;	
	root->root = root->root->next;

	void* toR = next->val;
	free(next);
	root->count--;
	return toR;
}


int ll_length(struct linked_list* root) {
	if (root == NULL) return 0;
	return root->count;
}
