#include "linked_list.h"
#include <stdlib.h>
#include <stdio.h>



int main(int argc, char** argv) {
	int SIZE = atoi(argv[1]);
	
	// make a new linked list
	LinkedList* ll = [[LinkedList alloc] init];
	
	int* d = calloc(SIZE, sizeof(int));
	int i;
	for (i=0; i < SIZE; i++) {
		d[i] = i;
		[ll add: &(d[i])];
	}
	
	printf("Size of list: %d\n", [ll length]);
	int sum = 0;
	while ([ll length] != 0) {
		sum +=  *(int*)[ll pop];
		LinkedList* lli = [[LinkedList alloc] init];
		for (i=0; i < sum; i++) {
			[lli add: &(d[1])];
		}

		while ([lli length] != 0) {
			sum -= *(int*)[lli pop];
		} 

		[lli release];
	}
	printf("Sum: %d\n", sum);
	
	
	free(d);
	[ll release];
	return 0;
}
