#include "linked_list_c.h"
#include <stdlib.h>
#include <stdio.h>


int main(int argc, char** argv) {
	int SIZE = atoi(argv[1]);

	// make a new linked list
	struct linked_list* ll = ll_create();
	
	int* d = calloc(SIZE, sizeof(int));
	int i;
	for (i=0; i < SIZE; i++) {
		d[i] = i;
		ll_add(&(d[i]), ll);
	}
	
	printf("Size of list: %d\n", ll_length(ll));
	int sum = 0;
	while (ll_length(ll) != 0) {
		sum +=  *(int*)ll_pop(ll);
		struct linked_list* lli = ll_create();
		for (i=0; i < sum; i++) {
			ll_add(&(d[1]), lli);
		}

		while (ll_length(lli) != 0) {
			sum -= *(int*)ll_pop(lli);
		}
		free(lli);
	}
	printf("Sum: %d\n", sum);
	
	
	free(d);
	free(ll);
	return 0;
}
