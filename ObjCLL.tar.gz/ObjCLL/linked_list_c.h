
#ifndef INT_ARRAY_LINKED_LIST
#define INT_ARRAY_LINKED_LIST

#include <stdlib.h>

struct linked_list {
	struct int_array_node* root;
	int count;
};

struct int_array_node {
	void* val;
	struct int_array_node* next;
};

struct linked_list* ll_create();
void ll_add(void* toAdd, struct linked_list* root);
void* ll_pop(struct linked_list* root);
struct linked_list* ll_clone(struct linked_list* root);
int ll_length(struct linked_list* root);

#endif
