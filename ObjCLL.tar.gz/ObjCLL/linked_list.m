#include "linked_list.h"
#include <stdlib.h>

// @interface LinkedList : NSObject {
// 	@private
// 	struct linked_list_node root;
// 	int count;
// }
// 	- (id)init;
// 	- (void)add:(void*)toAdd;
// 	- (void*)pop;
// 	- (int)length;
// @end

@implementation LinkedList
	-(id) init {
		if ((self = [super init])) {
			count = 0;
			root = NULL;
		}
		return self;
	}
	
	-(void)add: (void*) toAdd {
		if (root == NULL) {
				root = malloc(sizeof(struct linked_list_node));
				root->val = toAdd;
				root->next = NULL;
				count++;
				return;
		}
	
		struct linked_list_node* last = root;
		root = malloc(sizeof(struct linked_list_node));
		root->val = toAdd;
		root->next = last;
		count++;
		return;
	}
	
	-(void*)pop {
		if (root == NULL) return NULL;
		struct linked_list_node* next = root;
		root = root->next;

		void* toR = next->val;
		free(next);
		count--;
		return toR;
	}
	
	-(int)length {
		return count;
	}
	
	
@end
